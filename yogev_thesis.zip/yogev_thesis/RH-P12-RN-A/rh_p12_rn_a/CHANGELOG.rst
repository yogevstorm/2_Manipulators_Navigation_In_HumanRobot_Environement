^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rh_p12_rn_a
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2019-10-25)
------------------
* first release
* Contributors: Zerom, Pyo
