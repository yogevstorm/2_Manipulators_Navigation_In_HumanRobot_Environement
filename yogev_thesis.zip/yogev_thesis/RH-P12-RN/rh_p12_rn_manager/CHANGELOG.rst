^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rh_p12_rn_manager
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2018-03-22)
------------------
* fixed dependency problems
* changed package.xml to use format v2
* refactoring to release
* first release
* Contributors: Zerom, Pyo
