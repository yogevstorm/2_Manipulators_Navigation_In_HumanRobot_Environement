^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rh_p12_rn_gui
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2018-03-22)
------------------
* fixed dependency problems
* changed (torque control -> current control, goal torque -> goal current)
* changed RH-P12-RN.png
* changed package.xml to use format v2
* refactoring to release
* first release
* Contributors: Zerom, Pyo
