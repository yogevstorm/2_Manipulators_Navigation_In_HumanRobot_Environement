#include "ros/ros.h"
#include "std_msgs/Float64.h"
#include <sensor_msgs/JointState.h>
#include <tf/transform_broadcaster.h>
#include <sstream>


geometry_msgs::TransformStamped odom_trans;
sensor_msgs::JointState joint_state;
ros::Publisher joint_pub;
double joint1_state=-1.57;
double joint2_state=0;
double joint3_state=0;
double joint4_state=0;
double joint5_state=0;
double joint6_state=0;






void joint1_data(const std_msgs::Float64::ConstPtr& msg)
{
  joint1_state=msg->data;
}

void joint2_data(const std_msgs::Float64::ConstPtr& msg)
{
  joint2_state=msg->data;
}

void joint3_data(const std_msgs::Float64::ConstPtr& msg)
{
  joint3_state=msg->data;
}

void joint4_data(const std_msgs::Float64::ConstPtr& msg)
{
  joint4_state=msg->data;
}

void joint5_data(const std_msgs::Float64::ConstPtr& msg)
{
  joint5_state=msg->data;
}


void joint6_data(const std_msgs::Float64::ConstPtr& msg)
{
  joint6_state=msg->data;
}



int main(int argc, char **argv)
{

  ros::init(argc, argv, "robotic_hand_publisher");
  
  ros::NodeHandle n;
  tf::TransformBroadcaster broadcaster;
  ros::Subscriber joint1 = n.subscribe("robotis_manipulator_h/joint1_position/command", 1000, joint1_data);
  ros::Subscriber joint2 = n.subscribe("robotis_manipulator_h/joint2_position/command", 1000, joint2_data);
  ros::Subscriber joint3 = n.subscribe("robotis_manipulator_h/joint3_position/command", 1000, joint3_data);
  ros::Subscriber joint4 = n.subscribe("robotis_manipulator_h/joint4_position/command", 1000, joint4_data);
  ros::Subscriber joint5 = n.subscribe("robotis_manipulator_h/joint5_position/command", 1000, joint5_data);
  ros::Subscriber joint6 = n.subscribe("robotis_manipulator_h/joint6_position/command", 1000, joint6_data);
  ros::Publisher joint_pub = n.advertise<sensor_msgs::JointState>("joint_states", 7);
  ros::Rate loop_rate(20);
  
  joint_state.name.resize(7);
  joint_state.position.resize(7);



  joint_state.name[0] ="joint1";
  joint_state.name[1] ="joint2";
  joint_state.name[2] ="joint3";
  joint_state.name[3] ="joint4";
  joint_state.name[4] ="joint5";
  joint_state.name[5] ="joint6";
 
  
  

  while (ros::ok())
  {
   joint_state.header.stamp = ros::Time::now();
   joint_state.position[0] =joint1_state;
   joint_state.position[1] =joint2_state;
   joint_state.position[2] =joint3_state;
   joint_state.position[3] =joint4_state;
   joint_state.position[4] =joint5_state;
   joint_state.position[5] =joint6_state;

   joint_pub.publish(joint_state);
   ros::spinOnce();
   loop_rate.sleep();
  }


  



  return 0;
}


