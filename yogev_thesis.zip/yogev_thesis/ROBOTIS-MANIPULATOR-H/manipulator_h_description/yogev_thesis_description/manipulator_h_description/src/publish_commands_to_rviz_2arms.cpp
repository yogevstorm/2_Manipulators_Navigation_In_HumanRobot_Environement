#include "ros/ros.h"
#include "std_msgs/Float64.h"
#include <sensor_msgs/JointState.h>
#include <tf/transform_broadcaster.h>
#include <sstream>


geometry_msgs::TransformStamped odom_trans;
sensor_msgs::JointState joints_h1_state_data;
ros::Publisher joint_pub;
sensor_msgs::JointState joints_h2_state_data;
ros::Publisher joint_pub2;
sensor_msgs::JointState joints_h2_state;
sensor_msgs::JointState joints_h1_state;
double joint1_h1_state_data=-1.57;
double joint2_h1_state_data=0;
double joint3_h1_state_data=0;
double joint4_h1_state_data=0;
double joint5_h1_state_data=0;
double joint6_h1_state_data=0;


double joint1_h2_state_data=-1.57;
double joint2_h2_state_data=0;
double joint3_h2_state_data=0;
double joint4_h2_state_data=0;
double joint5_h2_state_data=0;
double joint6_h2_state_data=0;






void joints_h1_data(const sensor_msgs::JointState& msg)
{
  joint1_h1_state_data=msg.position[0];
  joint2_h1_state_data=msg.position[1];
  joint3_h1_state_data=msg.position[2];
  joint4_h1_state_data=msg.position[3];
  joint5_h1_state_data=msg.position[4];
  joint6_h1_state_data=msg.position[5];
}






void joints_h2_data(const sensor_msgs::JointState& msg)
{
  joint1_h2_state_data=msg.position[0];
  joint2_h2_state_data=msg.position[1];
  joint3_h2_state_data=msg.position[2];
  joint4_h2_state_data=msg.position[3];
  joint5_h2_state_data=msg.position[4];
  joint6_h2_state_data=msg.position[5];
}














int main(int argc, char **argv)
{

  ros::init(argc, argv, "robotic_hand_publisher");
  
  ros::NodeHandle n;
  tf::TransformBroadcaster broadcaster;
  ros::Subscriber joint1_h1 = n.subscribe("/arm_left/robotis/present_joint_states", 1000, joints_h1_data);

  ros::Subscriber joint1_h2 = n.subscribe("/arm_right/robotis/present_joint_states", 1000, joints_h2_data);

  ros::Publisher joint_pub = n.advertise<sensor_msgs::JointState>("joint_states", 7);
  ros::Publisher joint_pub2 = n.advertise<sensor_msgs::JointState>("joint_states2", 7);
  ros::Rate loop_rate(20);
  
  joints_h1_state.name.resize(7);
  joints_h1_state.position.resize(7);



  joints_h1_state.name[0] ="joint1";
  joints_h1_state.name[1] ="joint2";
  joints_h1_state.name[2] ="joint3";
  joints_h1_state.name[3] ="joint4";
  joints_h1_state.name[4] ="joint5";
  joints_h1_state.name[5] ="joint6";





  joints_h2_state.name.resize(7);
  joints_h2_state.position.resize(7);



  joints_h2_state.name[0] ="joint1";
  joints_h2_state.name[1] ="joint2";
  joints_h2_state.name[2] ="joint3";
  joints_h2_state.name[3] ="joint4";
  joints_h2_state.name[4] ="joint5";
  joints_h2_state.name[5] ="joint6";
 
  
  

  while (ros::ok())
  {
   joints_h1_state.header.stamp = ros::Time::now();
   joints_h1_state.position[0] = joint1_h1_state_data;
   joints_h1_state.position[1] = joint2_h1_state_data;
   joints_h1_state.position[2] = joint3_h1_state_data;
   joints_h1_state.position[3] = joint4_h1_state_data;
   joints_h1_state.position[4] = joint5_h1_state_data;
   joints_h1_state.position[5] = joint6_h1_state_data;




   joints_h2_state.header.stamp = ros::Time::now();
   joints_h2_state.position[0] = joint1_h2_state_data;
   joints_h2_state.position[1] = joint2_h2_state_data;
   joints_h2_state.position[2] = joint3_h2_state_data;
   joints_h2_state.position[3] = joint4_h2_state_data;
   joints_h2_state.position[4] = joint5_h2_state_data;
   joints_h2_state.position[5] = joint6_h2_state_data;

   joint_pub.publish(joints_h1_state);
   joint_pub2.publish(joints_h2_state);
   ros::spinOnce();
   loop_rate.sleep();
  }


  



  return 0;
}


