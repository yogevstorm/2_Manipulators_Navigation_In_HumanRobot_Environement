#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
import numpy as np
import math
global joint_state_data

joint_state_data=JointState()
joint_state_data.position=np.zeros(6)


def from_transition_matrix_to_pose(T):
    return [T[0][3],T[1][3],T[2][3]]



def forward_kinematics(joint_ID):
    global joint_state_data
    j_pos=joint_state_data.position
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data





def publish_forward_kinematics():
    rospy.init_node('forward_kinematics', anonymous=True)
    #pub = rospy.Publisher('chatter', String, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    
    rate = rospy.Rate(10) # 10hz

    while not rospy.is_shutdown():

        print forward_kinematics(4)

        rate.sleep()




if __name__ == '__main__':
    try:
       publish_forward_kinematics()
    except rospy.ROSInterruptException:
        pass