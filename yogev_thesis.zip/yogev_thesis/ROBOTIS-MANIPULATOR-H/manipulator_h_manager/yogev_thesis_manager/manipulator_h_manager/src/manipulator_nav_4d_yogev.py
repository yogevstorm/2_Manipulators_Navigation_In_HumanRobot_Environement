#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time


global joint_state_data

global delta,x,start_button

global occupied_cells

delta=0.04
x,start_button=0,0
joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)


def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)


def distance_between_2_points(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)


def vector_normalize(vector,vector_size):

    magnitude=np.linalg.norm(vector)

    if(vector_size==2):

        return (vector[0]/magnitude,vector[1]/magnitude)

    if(vector_size==3):

        return (vector[0]/magnitude,vector[1]/magnitude,vector[2]/magnitude)

    if(vector_size==4):

        return (vector[0]/magnitude,vector[1]/magnitude,vector[2]/magnitude,vector[3]/magnitude)





def attraction_vector(current_state,goal_state):
    attraction_vector_1=goal_state[0]-current_state[0]
    attraction_vector_2=goal_state[1]-current_state[1]
    attraction_vector_3=goal_state[2]-current_state[2]
    attraction_vector_4=goal_state[3]-current_state[3]
    attraction_vector=(attraction_vector_1,attraction_vector_2,attraction_vector_3,attraction_vector_4)
    return vector_normalize(attraction_vector,4)
    


def repulsive_vector(joint_point,obstacles_array):

    repulsive_vec_x=0
    repulsive_vec_y=0
    repulsive_vec_z=0
    repulsive_vec=(0,0,0)
    Fmax=0.001


    for obstacle in obstacles_array:

        obstacle_point=(obstacle.x,obstacle.y,obstacle.z) 

        repulsive_vec_x+=(joint_point[0]-obstacle_point[0])/(((joint_point[0]-obstacle_point[0])**2 + (joint_point[1]-obstacle_point[1])**2 + (joint_point[2]-obstacle_point[2])**2)**2)

        repulsive_vec_y+=(joint_point[1]-obstacle_point[1])/(((joint_point[0]-obstacle_point[0])**2 + (joint_point[1]-obstacle_point[1])**2 + (joint_point[2]-obstacle_point[2])**2)**2)

        repulsive_vec_z+=(joint_point[2]-obstacle_point[2])/(((joint_point[0]-obstacle_point[0])**2 + (joint_point[1]-obstacle_point[1])**2 + (joint_point[2]-obstacle_point[2])**2)**2)

    repulsive_vec=(repulsive_vec_x,repulsive_vec_y,repulsive_vec_z)

    return repulsive_vec





def repulsive(joint_point,obstacles_array):
    
    obstacle = obstacles_array[55]
    obstacle_point=(obstacle.x,obstacle.y,obstacle.z) 
    Fmax=0.001

    repulsive_vec_x=Fmax*np.sign(joint_point[0]-obstacle_point[0])/((joint_point[0]-obstacle_point[0])**2)

    repulsive_vec_y=Fmax*np.sign(joint_point[0]-obstacle_point[0])/((joint_point[1]-obstacle_point[1])**2)

    repulsive_vec_z=-Fmax*np.sign(joint_point[0]-obstacle_point[0])/((joint_point[2]-obstacle_point[2])**2)

    repulsive_vec=(repulsive_vec_x,repulsive_vec_y,repulsive_vec_z)
    print repulsive_vec,"       obstacle    ",obstacle_point,"       joint   ",joint_point







def normal_vector_to_repulsive_vector(repulsive_vector):
    normal_vec_z=np.sqrt(repulsive_vector[0]**2 + repulsive_vector[1]**2)
    normal_vec_x=-repulsive_vector[2]*repulsive_vector[0]/normal_vec_z
    normal_vec_y=repulsive_vector[1]*normal_vec_x/repulsive_vector[0]
    magnitude_repulsive_vec=np.sqrt(repulsive_vector[0]**2 + repulsive_vector[1]**2 + repulsive_vector[2]**2)
    magnitude_normal_vector=np.sqrt(normal_vec_x**2 + normal_vec_y**2 + normal_vec_z**2)

    return (normal_vec_x*magnitude_repulsive_vec/magnitude_normal_vector,normal_vec_y*magnitude_repulsive_vec/magnitude_normal_vector,normal_vec_z*magnitude_repulsive_vec/magnitude_normal_vector)

    
def repulsive_moments(repulsive_vec,joint_point,current_state):
    vec_1=-np.sqrt(repulsive_vec[0]**2 + repulsive_vec[1]**2)*(np.sqrt(joint_point[0]**2 + joint_point[1]**2))
    ###print repulsive_vec[2]
    #vec_2=np.sign(repulsive_vec[1])*repulsive_vec[2]
    vec_2=-repulsive_vec[2]
    vec_3=-repulsive_vec[2]
    vec_4=np.sqrt(repulsive_vec[0]**2 + repulsive_vec[1]**2)*np.sign(repulsive_vec[1])
    

    return (vec_1,vec_2,vec_3,vec_4)
       



def potential_field(start_state,goal_state,attraction_weight,repulsive_weight,delta,obstacles_array,set_joints_msg,pub_set_joints):

    current_state=start_state
    route=[]
    

    while distance_between_2_poses(current_state,goal_state)>0.2:

        repulsive_moment_1=0
        repulsive_moment_2=0
        repulsive_moment_3=0
        repulsive_moment_4=0
    

        attraction_vec=attraction_vector(current_state,goal_state)

        joint1_point=forward_kinematics(1,[current_state[0],current_state[1]])

        joint2_point=forward_kinematics(3,[current_state[0],current_state[1],current_state[2],current_state[3]])

        joints_points=[joint1_point,joint2_point]

        for joint_point in joints_points:

            repulsive_vec=repulsive_vector(joint_point,obstacles_array)

            normal_vector_to_repulsive_vec=normal_vector_to_repulsive_vector(repulsive_vec)

            final_repulsive_vec_x=repulsive_vec[0]+normal_vector_to_repulsive_vec[0]

            final_repulsive_vec_y=repulsive_vec[1]+normal_vector_to_repulsive_vec[1]

            final_repulsive_vec_z=repulsive_vec[2]+normal_vector_to_repulsive_vec[2]

            final_repulsive_vec=(final_repulsive_vec_x,final_repulsive_vec_y,final_repulsive_vec_z)

        
            repulsive_moment_for_each_joint=repulsive_moments(final_repulsive_vec,joint_point,current_state)

            repulsive_moment_1+=repulsive_moment_for_each_joint[0]

            repulsive_moment_2+=repulsive_moment_for_each_joint[1]

            repulsive_moment_3+=repulsive_moment_for_each_joint[2]

            repulsive_moment_4+=repulsive_moment_for_each_joint[3]

        repulsive_moment=(repulsive_moment_1,repulsive_moment_2,repulsive_moment_3,repulsive_moment_4)
        
        att_vec_1=attraction_weight*attraction_vec[0]
        att_vec_2=attraction_weight*attraction_vec[1]
        att_vec_3=attraction_weight*attraction_vec[2]
        att_vec_4=attraction_weight*attraction_vec[3]
        att_vec=(att_vec_1,att_vec_2,att_vec_3,att_vec_4)

        rep_vec_1=repulsive_weight*repulsive_moment[0]
        rep_vec_2=repulsive_weight*repulsive_moment[1]
        rep_vec_3=repulsive_weight*repulsive_moment[2]
        rep_vec_4=repulsive_weight*repulsive_moment[3]
        rep_vec=(rep_vec_1,rep_vec_2,rep_vec_3,rep_vec_4)
        

        print "   rep   ",rep_vec,"  att  ",att_vec
        #print attraction_vec,"      ",repulsive_moment
        F_1=attraction_weight*attraction_vec[0]+repulsive_weight*repulsive_moment[0]
        F_2=attraction_weight*attraction_vec[1]+repulsive_weight*repulsive_moment[1]
        F_3=attraction_weight*attraction_vec[2]+repulsive_weight*repulsive_moment[2]
        F_4=attraction_weight*attraction_vec[3]+repulsive_weight*repulsive_moment[3]



       
        F=(F_1,F_2,F_3,F_4)
        F=vector_normalize(F,4)
        
        current_state[0]+=F[0]*delta
        current_state[1]+=F[1]*delta
        current_state[2]+=F[2]*delta
        current_state[3]+=F[3]*delta

        joints_state_array=[current_state[0],current_state[1],current_state[2],current_state[3]]
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(0.2)

        point_in_route=(current_state[0],current_state[1],current_state[2])
        route.append(point_in_route)
      

    return (route,current_state)


        
def A_star(start_state,goal_state,obstacles_array):
    global delta

    start=(start_state[0],start_state[1])

    goal=(goal_state[0],goal_state[1])

    neighbors = [(0,delta),(0,-delta),(delta,0),(-delta,0),(delta,delta),(delta,-delta),(-delta,delta),(-delta,-delta)]

    close_set = set()  # close list

    came_from = {}
    

    gscore = {start:0} # score from start to current pose

    fscore = {start:distance_between_2_poses(start,goal)}  # score from current pose to goal pose

    open_set = [] #  open list

    heapq.heappush(open_set, (fscore[start], start)) #  add to the open list the fscore of the start and the start pose

    while open_set:

        current = heapq.heappop(open_set)[1] # current pose
     
 
        if distance_between_2_poses(current,goal)<0.1:  # if we reached the goal
             
            data = []
            
            while current in came_from:  # all this gives me the optimal route
                data.append(current)

                current = came_from[current]

            return data

        close_set.add(current)  # add the current pose to the close list

        #print close_set

        for i, j in neighbors:

            neighbor = current[0] + i, current[1] + j   #give the neighbors to the current pose

            tentative_g_score = gscore[current] + distance_between_2_poses(current, neighbor) # gives the gscore of the neighbor through the current pose

            neighbor_joints_points_array= [forward_kinematics(1,[neighbor[0],neighbor[1]])]

            if -1.57 <= neighbor[0] < 1.57:
                

                if -1.57<= neighbor[1] < 1.57:

                    skip=False

                    for joint_pose in neighbor_joints_points_array:

                        for obstacle in obstacles_array:

                            obstacle_point=(obstacle.x,obstacle.y,obstacle.z)   


                            if distance_between_2_points(joint_pose,obstacle_point)<0.1:
                                skip=True
                                break
                    
                    if(skip):
                        continue
                                             
                                
                else:
                    continue   

            else:

                continue


            if neighbor in close_set and tentative_g_score >= gscore.get(neighbor, 0): # if neighbor is already in close list and has less gscore then dont add that neighbor

                continue


            if  tentative_g_score < gscore.get(neighbor, 0) or neighbor not in [i[1]for i in open_set]: # if you found the same neighbor but with less g score or its the first time you see that neighbot then add him to the open lise

                came_from[neighbor] = current


                gscore[neighbor] = tentative_g_score

                fscore[neighbor] = tentative_g_score + distance_between_2_poses(neighbor, goal)

                heapq.heappush(open_set, (fscore[neighbor], neighbor))
    

    return False




def get_route(start_pose,goal_pose,obstacles_array):

    route = A_star(start_pose,goal_pose,obstacles_array)

    route = route + [start_pose]

    route = route[::-1]

    return route





def joy_data(data):
    global x,start_button
    x=data.buttons[1]
    start_button=data.buttons[9]
    back=data.buttons[6]

  

    


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)




def navigation(start_pose,goal_pose,attraction_weight,repulsive_weight,delta,set_joints_msg,pub_set_joints,obstacles_array):
    final_path=[]
    print "planning path A star"
    route=get_route(start_pose,goal_pose,obstacles_array)
    print "planning potential field"
    current_pose=np.array(start_pose)
    #print route
    for target in route:
        target=(target[0],target[1],goal_pose[2],goal_pose[3])
        #print target,"      ",current_pose
        (path,current_state)=potential_field(current_pose,target,attraction_weight,repulsive_weight,delta,obstacles_array,set_joints_msg,pub_set_joints)
        #print path
        for point in path:
            final_path.append(point)
        current_pose=current_state
        
    print "successss"
    final_path.append(goal_pose)
    print final_path
    
    #for pose in final_path:
        #joints_state_array=[pose[0],pose[1],pose[2],0,0,0]
        #set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        #time.sleep(0.1)
       # if(pose[0]==goal_pose[0] and pose[1]==goal_pose[1]):
          #  time.sleep(3)
           # print "yay"
            #joints_state_array=[pose[0],pose[1],pose[2],0,0,0]
            #set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
           # time.sleep(3)



    #print final_path

    print " start navigating"
    



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


        







def starting():
    global x,start_button
    global joint_state_data
    global occupied_cells

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    #print get_route()

    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            #set_mode(pub_set_mode)
            current_state=(j_pos[0],j_pos[1],j_pos[2],j_pos[3])
            obstacles_array=create_obstacles_array(occupied_cells)
            repulsive_moment_1=0
            repulsive_moment_2=0
            repulsive_moment_3=0
            repulsive_moment_4=0

            joint1_point=forward_kinematics(1,[current_state[0],current_state[1]])

            joint2_point=forward_kinematics(3,[current_state[0],current_state[1],current_state[2],current_state[3]])

            joints_points=[joint1_point,joint2_point]

            for joint_point in joints_points:

                repulsive_vec=repulsive_vector(joint_point,obstacles_array)

                normal_vector_to_repulsive_vec=normal_vector_to_repulsive_vector(repulsive_vec)

                final_repulsive_vec_x=repulsive_vec[0]+normal_vector_to_repulsive_vec[0]

                final_repulsive_vec_y=repulsive_vec[1]+normal_vector_to_repulsive_vec[1]

                final_repulsive_vec_z=repulsive_vec[2]+normal_vector_to_repulsive_vec[2]

                final_repulsive_vec=(final_repulsive_vec_x,final_repulsive_vec_y,final_repulsive_vec_z)

        
                repulsive_moment_for_each_joint=repulsive_moments(final_repulsive_vec,joint_point,current_state)

                repulsive_moment_1+=repulsive_moment_for_each_joint[0]

                repulsive_moment_2+=repulsive_moment_for_each_joint[1]

                repulsive_moment_3+=repulsive_moment_for_each_joint[2]

                repulsive_moment_4+=repulsive_moment_for_each_joint[3]

            repulsive_moment=(repulsive_moment_1,repulsive_moment_2,repulsive_moment_3,repulsive_moment_4)

            #print np.linalg.norm(repulsive_moment)

            print "   repulsive   ",repulsive_moment
            

        if(start_button==1):
            
            start=(j_pos[0],j_pos[1],j_pos[2],j_pos[3])
            obstacles_array=create_obstacles_array(occupied_cells)
            #print obstacles_array[5].x

            #print get_route(start,(1.5,1.5),obstacles_array)
            #route=potential_field(start,(1.5,1.5),1,0.01)
            #print route
            
            navigation(start,(1.5,1,-0.5,-0.5),20000,1,0.01,set_joints_msg,pub_set_joints,obstacles_array)
            

        

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass