#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time


global joint_state_data

global delta,x,start_button

global occupied_cells

delta=0.08
x,start_button=0,0
joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)


def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)


def distance_between_2_points(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)


def vector_normalize(vector,vector_size):

    if(vector_size==2):

        return (vector[0]/np.sqrt(vector[0]**2+vector[1]**2),vector[1]/np.sqrt(vector[0]**2+vector[1]**2))

    if(vector_size==3):

        return (vector[0]/np.sqrt(vector[0]**2+vector[1]**2+vector[2]**2),vector[1]/np.sqrt(vector[0]**2+vector[1]**2+vector[2]**2),vector[2]/np.sqrt(vector[0]**2+vector[1]**2+vector[2]**2))



def attraction_vector(current_state,goal_state):
    attraction_vector_1=goal_state[0]-current_state[0]
    attraction_vector_2=goal_state[1]-current_state[1]
    attraction_vector=(attraction_vector_1,attraction_vector_2)
    return vector_normalize(attraction_vector,2)
    


def repulsive_vector(joint_point,obstacles_array):

    repulsive_vec_x=0
    repulsive_vec_y=0
    repulsive_vec_z=0
    repulsive_vec=(0,0,0)

    for obstacle in obstacles_array:

        obstacle_point=(obstacle.x,obstacle.y,obstacle.z) 

        repulsive_vec_x+=1/((joint_point[0]-obstacle_point[0])**2)/10000

        repulsive_vec_y+=1/((joint_point[1]-obstacle_point[1])**2)/10000

        repulsive_vec_z+=1/((joint_point[2]-obstacle_point[2])**2)/10000

        repulsive_vec=(repulsive_vec_x,repulsive_vec_y,repulsive_vec_z)
    
    return repulsive_vec



def normal_vector_to_repulsive_vector(repulsive_vector):
    normal_vec_z=np.sqrt(repulsive_vector[0]**2 + repulsive_vector[1]**2)
    normal_vec_x=-repulsive_vector[2]*repulsive_vector[0]/normal_vec_z
    normal_vec_y=repulsive_vector[1]*normal_vec_x/repulsive_vector[0]
    magnitude_repulsive_vec=np.sqrt(repulsive_vector[0]**2 + repulsive_vector[1]**2 + repulsive_vector[2]**2)
    magnitude_normal_vector=np.sqrt(normal_vec_x**2 + normal_vec_y**2 + normal_vec_z**2)

    return (normal_vec_x*magnitude_repulsive_vec/magnitude_normal_vector,normal_vec_y*magnitude_repulsive_vec/magnitude_normal_vector,normal_vec_z*magnitude_repulsive_vec/magnitude_normal_vector)

    
def repulsive_moments(repulsive_vec,joint1_point,current_state):
    vec_1=-np.sqrt(repulsive_vec[0]**2 + repulsive_vec[1]**2)*(np.sqrt(joint1_point[0]**2 + joint1_point[1]**2))
    print repulsive_vec[2]
    vec_2=-np.sign(repulsive_vec[1])*repulsive_vec[2]

    return (vec_1,vec_2)
       



def potential_field(start_state,goal_state,attraction_weight,repulsive_weight,delta,obstacles_array,set_joints_msg,pub_set_joints):

    current_state=start_state
    route=[]
    k=0

    while distance_between_2_poses(current_state,goal_state)>0.3:
    #while k<1:

        attraction_vec=attraction_vector(current_state,goal_state)

        joint1_point=forward_kinematics(1,[current_state[0],current_state[1]])

        joints_points=[joint1_point]

        for joint_point in joints_points:

            repulsive_vec=repulsive_vector(joint1_point,obstacles_array)
            normal_vector_to_repulsive_vec=normal_vector_to_repulsive_vector(repulsive_vec)
            final_repulsive_vec_x=repulsive_vec[0]+2*normal_vector_to_repulsive_vec[0]
            final_repulsive_vec_y=repulsive_vec[1]+2*normal_vector_to_repulsive_vec[1]
            final_repulsive_vec_z=repulsive_vec[2]+2*normal_vector_to_repulsive_vec[2]
            final_repulsive_vec=(final_repulsive_vec_x,final_repulsive_vec_y,final_repulsive_vec_z)

        #print final_repulsive_vec
        repulsive_moment=repulsive_moments(final_repulsive_vec,joint1_point,current_state)
        #print repulsive_moment,"            ",attraction_vec

        F_1=attraction_weight*attraction_vec[0]+repulsive_weight*repulsive_moment[0]
        #F_2=attraction_weight*attraction_vec[1]+repulsive_weight*repulsive_moment[1]
        F_2=repulsive_weight*repulsive_moment[1]
        F=(F_1,F_2)
        F=vector_normalize(F,2)
        #print F
        #print F
        #if(F[0]>=0):
        current_state[0]+=F[0]*delta
        current_state[1]+=F[1]*delta

        joints_state_array=[current_state[0],current_state[1],-1.55]
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(0.2)

        #point_in_route=(current_state[0],current_state[1])
        #route.append(point_in_route)
        #k+=1

    #return route


        






def joy_data(data):
    global x,start_button
    x=data.buttons[0]
    start_button=data.buttons[7]
    back=data.buttons[6]

  

    


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)




def navigation(start_pose,goal_pose,attraction_weight,repulsive_weight,delta,set_joints_msg,pub_set_joints,obstacles_array):
    
    print "planning path"
    route=potential_field(start_pose,goal_pose,attraction_weight,repulsive_weight,delta,obstacles_array,set_joints_msg,pub_set_joints)
    print " start navigating"
    print route

    #for pose in route:
        #print pose
        #joints_state_array=[pose[0],pose[1],-1.55]
        #set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        #time.sleep(0.2)



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


        







def starting():
    global x,start_button
    global joint_state_data
    global occupied_cells

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    #print get_route()

    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            set_mode(pub_set_mode)

        if(start_button==1):
            
            start=[j_pos[0],j_pos[1]]
            obstacles_array=create_obstacles_array(occupied_cells)
            #print obstacles_array[5].x

            #print get_route(start,(1.5,1.5),obstacles_array)
            #route=potential_field(start,(1.5,1.5),1,0.01)
            #print route
            
            navigation(start,(1.5,1.5),40,1,0.04,set_joints_msg,pub_set_joints,obstacles_array)
            

        

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass