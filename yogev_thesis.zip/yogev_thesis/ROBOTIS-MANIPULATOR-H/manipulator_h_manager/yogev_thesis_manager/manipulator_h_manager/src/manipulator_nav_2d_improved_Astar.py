#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time


global joint_state_data

global delta,x,start_button

global occupied_cells

delta=0.01
x,start_button=0,0
joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)


def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)


def inverse_kinematics(joint_ID,desired_point):
    L1=0.159
    L2=0.2659
    
    if(joint_ID==1):
        angle1=np.arctan2(desired_point[1],desired_point[0])
        angle2=np.arccos((desired_point[2]-L1)/L2)
        return(angle1,angle2)

def z_constrain(joint_ID,point):
    L1=0.159
    L2=0.2659
    
    if(joint_ID==1):
        return np.sqrt(L2**2-point[0]**2-point[1]**2)+L1

    


def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)


def distance_between_2_points(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)



def A_star(start,goal,obstacles_array):
    global delta

    neighbors = [(0,delta,0),(0,-delta,0),(delta,0,0),(-delta,0,0),(delta,delta,0),(delta,-delta,0),(-delta,delta,0),(-delta,-delta,0)]

    #neighbors = [(0,delta,0),(0,-delta,0),(delta,0,0),(-delta,0,0),(delta,delta,0),(delta,-delta,0),(-delta,delta,0),(-delta,-delta,-delta),(0,delta,-delta),(0,-delta,-delta),(delta,0,-delta),(-delta,0,-delta),(delta,delta,-delta),(delta,-delta,-delta),(-delta,delta,-delta),(-delta,-delta,-delta),(0,delta,delta),(0,-delta,delta),(delta,0,delta),(-delta,0,delta),(delta,delta,delta),(delta,-delta,delta),(-delta,delta,delta),(-delta,-delta,delta)]

    close_set = set()  # close list

    came_from = {}

    gscore = {start:0} # score from start to current pose

    fscore = {start:distance_between_2_poses(start,goal)}  # score from current pose to goal pose

    open_set = [] #  open list

    heapq.heappush(open_set, (fscore[start], start)) #  add to the open list the fscore of the start and the start pose

    while open_set:

        current = heapq.heappop(open_set)[1] # current pose
     
 
        if distance_between_2_points(current,goal)<0.03:  # if we reached the goal
             
            data = []
            
            while current in came_from:  # all this gives me the optimal route
                data.append(current)

                current = came_from[current]

            return data

        close_set.add(current)  # add the current pose to the close list

        #print close_set

        for i, j, k in neighbors:

            point=current[0] + i, current[1] + j,  k

            #print point

            z=z_constrain(1,point)

            neighbor = current[0] + i, current[1] + j, z   #give the neighbors to the current pose

            #print neighbor

            #z=z_constrain(1,neighbor)

            #neighbor[2]=z

            #print neighbor

            tentative_g_score = gscore[current] + distance_between_2_poses(current, neighbor) # gives the gscore of the neighbor through the current pose

            joints_poses=inverse_kinematics(1,(neighbor))

            joint1_point=forward_kinematics(1,[joints_poses[0],joints_poses[1]])

            neighbor_joints_points_array= [joint1_point]

            if -1.57<joints_poses[0]<1.57:

                if -1.57<joints_poses[1]<1.57:

                    skip=False

                    for joint_point in neighbor_joints_points_array:

                        for obstacle in obstacles_array:

                            obstacle_point=(obstacle.x,obstacle.y,obstacle.z)   

                            if distance_between_2_points(joint_point,obstacle_point)<0.12:
                                skip=True
                                break
                    
                    if(skip):
                        continue
                                             
                                
                else:
                    continue   

            else:

                continue


            if neighbor in close_set and tentative_g_score >= gscore.get(neighbor, 0): # if neighbor is already in close list and has less gscore then dont add that neighbor

                continue


            if  tentative_g_score < gscore.get(neighbor, 0) or neighbor not in [i[1]for i in open_set]: # if you found the same neighbor but with less g score or its the first time you see that neighbot then add him to the open lise

                came_from[neighbor] = current


                gscore[neighbor] = tentative_g_score

                fscore[neighbor] = tentative_g_score + distance_between_2_poses(neighbor, goal)

                heapq.heappush(open_set, (fscore[neighbor], neighbor))
    

    return False




def get_route(start_pose,goal_pose,obstacles_array):

    route = A_star(start_pose,goal_pose,obstacles_array)

    print route

    route = route + [start_pose]

    route = route[::-1]

    return route



def joy_data(data):
    global x,start_button
    x=data.buttons[0]
    start_button=data.buttons[7]
    back=data.buttons[6]

  

    


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)




def navigation(start_pose,goal_pose,set_joints_msg,pub_set_joints,obstacles_array):
    print "planning path"
    route=get_route(start_pose,goal_pose,obstacles_array)
    print " start navigating"

    for point in route:
        joint_state=inverse_kinematics(1,point)
        joints_state_array=[joint_state[0],joint_state[1],-1.57,0,0,0]
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(0.5)
    
    
    



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


        







def starting():
    global x,start_button
    global joint_state_data
    global occupied_cells

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    #print get_route()

    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            set_mode(pub_set_mode)
            print inverse_kinematics(1,(0.2659,0.5,0.159))
            

        if(start_button==1):
            
            #start_pose=(j_pos[0],j_pos[1])

            start=forward_kinematics(1,[j_pos[0],j_pos[1]])
            
            obstacles_array=create_obstacles_array(occupied_cells)
            #print obstacles_array[5].x

            #print get_route(start,(1.5,1.5),obstacles_array)
            
            navigation(start,(0,0.2659,0.159),set_joints_msg,pub_set_joints,obstacles_array)

        

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass