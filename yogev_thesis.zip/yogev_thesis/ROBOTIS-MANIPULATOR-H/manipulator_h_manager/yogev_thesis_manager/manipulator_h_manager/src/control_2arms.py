#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time








def joy_data(data):
    global x,start_button
    x=data.buttons[0]
    start_button=data.buttons[7]
    back=data.buttons[6]






def starting():
    global x,start_button
    

    

    rospy.init_node('2arms_nav', anonymous=True)

    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    




    while not rospy.is_shutdown():

        

        if(x==1):
            

        if(start_button==1):
            
            start=(j_pos[0],j_pos[1])
            

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass