#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time


global joint_state_data

global delta,x,start_button

global occupied_cells

delta=0.1
x,start_button=0,0
joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)


def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)


def distance_between_2_points(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)



def A_star(start,goal,obstacles_array):
    global delta

    Astar_Mode=True

    #neighbors = [(0,delta),(0,-delta),(delta,0),(delta,delta),(delta,-delta)]

    neighbors=[(0,delta,0),(0,-delta,0),(delta,0,0),(delta,delta,0),(delta,-delta,0),(0,delta,delta),(0,-delta,delta),(delta,0,delta),(delta,delta,-delta),(delta,-delta,delta),(0,delta,-delta),(0,-delta,-delta),(delta,0,-delta),(delta,delta,-delta),(delta,-delta,-delta)]

    close_set = set()  # close list

    came_from = {}

    gscore = {start:0} # score from start to current pose

    fscore = {start:distance_between_2_poses(start,goal)}  # score from current pose to goal pose

    open_set = [] #  open list

    heapq.heappush(open_set, (fscore[start], start)) #  add to the open list the fscore of the start and the start pose

    while open_set:

        current = heapq.heappop(open_set)[1] # current pose
     

        close_set.add(current)  # add the current pose to the close list

        #print close_set


        if distance_between_2_poses(current,goal)<0.08 or Astar_Mode==False:  # if we reached the goal
             
            data = []

            current_pose=current
            
            while current in came_from:  # all this gives me the optimal route
                data.append(current)

                current = came_from[current]

            return (data,Astar_Mode,current_pose)

        for i, j, k in neighbors:

            neighbor = current[0] + i, current[1] + j, current[2] + k   #give the neighbors to the current pose

            tentative_g_score = gscore[current] + distance_between_2_poses(current, neighbor) # gives the gscore of the neighbor through the current pose

            neighbor_joints_points_array= [forward_kinematics(1,[neighbor[0],neighbor[1]]),forward_kinematics(2,[neighbor[0],neighbor[1],neighbor[2]])]

            if -1.57 <= neighbor[0] < 1.57:
                

                if -1.57<= neighbor[1] < 1.57:

                    if -1.57<= neighbor[2] < 1.57:

                        skip=False

                        n=0

                        for joint_pose in neighbor_joints_points_array:

                            for obstacle in obstacles_array:

                                obstacle_point=(obstacle.x,obstacle.y,obstacle.z)   


                                if distance_between_2_points(joint_pose,obstacle_point)<0.1:
                                    skip=True
                                    break

                                if distance_between_2_points(joint_pose,obstacle_point)>0.4:

                                    n+=1

                                    if(n==2):
                                        #print "falseeee"
                                        Astar_Mode=False
                                        break
                    
                            #if(Astar_Mode==False or skip==True):
                                #break
                            

                        #if(Astar_Mode==False):
                           #break
                    
                        if(skip):
                            continue
                                             
                                
                    else:
                        continue   

                else:

                    continue

            else:
                continue

        


            if neighbor in close_set and tentative_g_score >= gscore.get(neighbor, 0): # if neighbor is already in close list and has less gscore then dont add that neighbor

                continue


            if  tentative_g_score < gscore.get(neighbor, 0) or neighbor not in [i[1]for i in open_set]: # if you found the same neighbor but with less g score or its the first time you see that neighbot then add him to the open lise

                came_from[neighbor] = current


                gscore[neighbor] = tentative_g_score

                fscore[neighbor] = tentative_g_score + distance_between_2_poses(neighbor, goal)

                heapq.heappush(open_set, (fscore[neighbor], neighbor))
    

    return False




def get_route(start_pose,goal_pose,obstacles_array):

    (route,Astar_Mode,current_pose) = A_star(start_pose,goal_pose,obstacles_array)

    print route

    route = route + [start_pose]

    route = route[::-1]

    return (route,Astar_Mode,current_pose)



def joy_data(data):
    global x,start_button
    x=data.buttons[0]
    start_button=data.buttons[7]
    back=data.buttons[6]

  

    


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)




def navigation(start_pose,goal_pose,set_joints_msg,pub_set_joints,obstacles_array):
    route=get_route(start_pose,goal_pose,obstacles_array)
    #print "start_navigating"
    
    for pose in route:
        joints_state_array=[pose[0],pose[1],-1.57,0,0,0]
        print forward_kinematics(1,joints_state_array)
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(1)



def linear_route(start_pose,goal_pose,delta,obstacles_array):

    current=start_pose
    np.sign
    route=[start_pose]
    Astar_Mode=False
    

    while distance_between_2_poses(current,goal_pose)>0.1:
        joints_points=[forward_kinematics(1,[current[0],current[1]]),forward_kinematics(2,[current[0],current[1],current[2]])]
        
        for joint_point in joints_points:
            for obstacle in obstacles_array:
                obstacle_point=(obstacle.x,obstacle.y,obstacle.z)
                if distance_between_2_points(joint_point,obstacle_point)<0.4:
                    Astar_Mode=True
                    return (route,Astar_Mode,current)

        current_0=current[0]+delta*np.sign(goal_pose[0]-current[0])
        current_1=current[1]+delta*np.sign(goal_pose[1]-current[1])
        current_2=current[2]+delta*np.sign(goal_pose[2]-current[2])
        current=(current_0,current_1,current_2)
        route.append(current)

    return (route,Astar_Mode,current)





def navigation_2(start_pose,goal_pose,set_joints_msg,pub_set_joints,obstacles_array):
    Astar_Mode=False

    current=start_pose

    total_route=[]
    

    while distance_between_2_poses(current,goal_pose)>0.1: 
        
        

        if(Astar_Mode):
            (A_star_route,Astar_Mode,current)=get_route(current,goal_pose,obstacles_array)
            for point in A_star_route:
                total_route.append(point)

    

        else:
            (route,Astar_Mode,current)=linear_route(current,goal_pose,0.02,obstacles_array)
            #print route
            for point in route:
                total_route.append(point)

    print total_route

    
    for pose in total_route:
        joints_state_array=[pose[0],pose[1],pose[2],0,0,0]
        #print forward_kinematics(1,joints_state_array)
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(0.2)





def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


        







def starting():
    global x,start_button
    global joint_state_data
    global occupied_cells

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    #print get_route()

    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            set_mode(pub_set_mode)

        if(start_button==1):
            
            start=(j_pos[0],j_pos[1],j_pos[2])
            obstacles_array=create_obstacles_array(occupied_cells)
            #print obstacles_array[5].x

            #print get_route(start,(1.5,1.5),obstacles_array)

            navigation_2(start,(1.5,1,-1.5),set_joints_msg,pub_set_joints,obstacles_array)
            
            #navigation(start,(1.5,1.5),set_joints_msg,pub_set_joints,obstacles_array)

        

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass