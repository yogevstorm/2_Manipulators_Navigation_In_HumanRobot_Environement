#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time




global joint_state_data,joint_state_data_arm2

global x,start_button

global occupied_cells


x,start_button=0,0
joint_state_data=JointState()
joint_state_data_arm2=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)



class Kinematics:

    def __init__(self):

        self.arm1_init_point = (0.3,0,0)

        self.arm2_init_point = (-0.3,0,0)

        self.arm1_init_pose=(math.pi,0,0,0,0,0)

        self.arm2_init_pose=(0,0,0,0,0,0)


    def from_transition_matrix_to_pose(self,arm_ID,T):

        if(arm_ID==2):

             return (T[0][3]+self.arm2_init_point[0],T[1][3]+self.arm2_init_point[1],T[2][3]+self.arm2_init_point[2])


        return (T[0][3]+self.arm1_init_point[0],T[1][3]+self.arm1_init_point[1],T[2][3]+self.arm1_init_point[2])




    def forward_kinematics(self,arm_ID,joint_ID,joints_state_array):
        j_pos=joints_state_array
        d1=0.159
        a1=0.2659
        a2=0.03
        a3=0.134
        d3=0.258
        joint2_offset=-1.57+0.113
        joint3_offset=-0.113
        joint4_offset=1.57

        if(arm_ID==2):
            j_pos[0]+=self.arm2_init_pose[0]
        
        else:
            j_pos[0]+=self.arm1_init_pose[0]

        T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

        if(joint_ID==0):
            return self.from_transition_matrix_to_pose(arm_ID,T_01)

        T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
        if(joint_ID==1):

            T_02=np.linalg.multi_dot([T_01,T_12])
            return self.from_transition_matrix_to_pose(arm_ID,T_02)

        T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

        if(joint_ID==2):

            T_03=np.linalg.multi_dot([T_01,T_12,T_23])
            return self.from_transition_matrix_to_pose(arm_ID,T_03)

        T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

        if(joint_ID==3):

            T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
            return self.from_transition_matrix_to_pose(arm_ID,T_04)

        T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
        if(joint_ID==4):

            T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
            return self.from_transition_matrix_to_pose(arm_ID,T_05)


def joint_state(data):
    global joint_state_data
    joint_state_data=data



def joint_state_arm2(data):
    global joint_state_data_arm2
    joint_state_data_arm2=data


def distance_between_2_poses(a, b):

    return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)

def distance(a, b):

    return np.sqrt((b[0] - a[0]) ** 2)


def distance_between_2_points(a, b):

    return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)


def vector_normalize(vector,vector_size):

    magnitude=np.linalg.norm(vector)

    if(vector_size==2):

        return (vector[0]/magnitude,vector[1]/magnitude)

    if(vector_size==3):

        return (vector[0]/magnitude,vector[1]/magnitude,vector[2]/magnitude)

    if(vector_size==4):

        return (vector[0]/magnitude,vector[1]/magnitude,vector[2]/magnitude,vector[3]/magnitude)

    if(vector_size==5):

        return (vector[0]/magnitude,vector[1]/magnitude,vector[2]/magnitude,vector[3]/magnitude,vector[4]/magnitude)


class Potential_Field:

    def __init__(self,start_state_arm1,goal_state_arm1,start_state_arm2,goal_state_arm2,attraction_weight,repulsive_weight,delta,obstacles_array,set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2,waypoint_arm1,waypoint_arm2):
        self.start_state_arm1=start_state_arm1
        self.start_state_arm2=start_state_arm2
        self.goal_state_arm1=goal_state_arm1
        self.goal_state_arm2=goal_state_arm2
        self.attraction_weight=attraction_weight
        self.repulsive_weight=repulsive_weight
        self.delta=delta
        self.obstacles_array=obstacles_array
        self.set_joints_msg=set_joints_msg
        self.pub_set_joints_arm1=pub_set_joints_arm1
        self.pub_set_joints_arm2=pub_set_joints_arm2
        self.waypoint_arm1=waypoint_arm1
        self.waypoint_arm2=waypoint_arm2









    def attraction_vector(self,current_state,goal_state):
        attraction_vector_1=goal_state[0]-current_state[0]
        attraction_vector_2=goal_state[1]-current_state[1]
        attraction_vector_3=goal_state[2]-current_state[2]
        attraction_vector_4=goal_state[3]-current_state[3]
        attraction_vector_5=goal_state[4]-current_state[4]
        attraction_vector=(attraction_vector_1,attraction_vector_2,attraction_vector_3,attraction_vector_4,attraction_vector_5)
        return vector_normalize(attraction_vector,5)
    


    def repulsive_vector(self,joint_point,obstacles_array,joints_points_other_arm):

        repulsive_vec_x=0
        repulsive_vec_y=0
        repulsive_vec_z=0
        repulsive_vec=(0,0,0)
        Fmax=0.001

        obstacles=obstacles_array
   


        for obstacle in obstacles_array:

            obstacle_point=(obstacle.x,obstacle.y,obstacle.z) 

            repulsive_vec_x+=(joint_point[0]-obstacle_point[0])/(((joint_point[0]-obstacle_point[0])**2 + (joint_point[1]-obstacle_point[1])**2 + (joint_point[2]-obstacle_point[2])**2)**2)

            repulsive_vec_y+=(joint_point[1]-obstacle_point[1])/(((joint_point[0]-obstacle_point[0])**2 + (joint_point[1]-obstacle_point[1])**2 + (joint_point[2]-obstacle_point[2])**2)**2)

            repulsive_vec_z+=(joint_point[2]-obstacle_point[2])/(((joint_point[0]-obstacle_point[0])**2 + (joint_point[1]-obstacle_point[1])**2 + (joint_point[2]-obstacle_point[2])**2)**2)



        

        for joint_obstacle in joints_points_other_arm: 

           repulsive_vec_x+=20*(joint_point[0]-joint_obstacle[0])/(((joint_point[0]-joint_obstacle[0])**2 + (joint_point[1]-joint_obstacle[1])**2 + (joint_point[2]-joint_obstacle[2])**2)**2)

           repulsive_vec_y+=20*(joint_point[1]-joint_obstacle[1])/(((joint_point[0]-joint_obstacle[0])**2 + (joint_point[1]-joint_obstacle[1])**2 + (joint_point[2]-joint_obstacle[2])**2)**2)

           repulsive_vec_z+=20*(joint_point[2]-joint_obstacle[2])/(((joint_point[0]-joint_obstacle[0])**2 + (joint_point[1]-joint_obstacle[1])**2 + (joint_point[2]-joint_obstacle[2])**2)**2)

        repulsive_vec=(repulsive_vec_x,repulsive_vec_y,repulsive_vec_z)

        return repulsive_vec







    def normal_vector_to_repulsive_vector(self,repulsive_vector):
        normal_vec_z=np.sqrt(repulsive_vector[0]**2 + repulsive_vector[1]**2) * np.sign(repulsive_vector[2])
        normal_vec_x=-repulsive_vector[2]*repulsive_vector[0]/normal_vec_z
        normal_vec_y=repulsive_vector[1]*normal_vec_x/repulsive_vector[0]
        magnitude_repulsive_vec=np.sqrt(repulsive_vector[0]**2 + repulsive_vector[1]**2 + repulsive_vector[2]**2)
        magnitude_normal_vector=np.sqrt(normal_vec_x**2 + normal_vec_y**2 + normal_vec_z**2)

        return (normal_vec_x*magnitude_repulsive_vec/magnitude_normal_vector,normal_vec_y*magnitude_repulsive_vec/magnitude_normal_vector,normal_vec_z*magnitude_repulsive_vec/magnitude_normal_vector)

    
    def repulsive_moments(self,repulsive_vec,joint_point,joint_id,arm_ID):
        moment_dir=self.moment_direction(repulsive_vec,joint_point,arm_ID)

        if(joint_id<3):
            vec_1=-moment_dir*np.sqrt(repulsive_vec[0]**2+repulsive_vec[1]**2)*np.sqrt(joint_point[0]**2+joint_point[1]**2)
            vec_2=-repulsive_vec[2]#*np.sqrt(joint_point[0]**2+joint_point[1]**2)
            vec_3=-repulsive_vec[2]#*np.sqrt(joint_point[0]**2+joint_point[1]**2)
            vec_4=0
            vec_5=0
    
        else:
            vec_1=0#-moment_dir*np.sqrt(repulsive_vec[0]**2+repulsive_vec[1]**2)
            vec_2=0#-repulsive_vec[2]
            vec_3=0
            vec_4=-np.sqrt(repulsive_vec[0]**2 + repulsive_vec[1]**2)*np.sign(repulsive_vec[1])
            vec_5=-np.sqrt(repulsive_vec[0]**2 + repulsive_vec[1]**2)*np.sign(repulsive_vec[1])
    

        return (vec_1,vec_2,vec_3,vec_4,vec_5)




    def moment_direction(self,vector_force,joint_point,arm_ID):
        kinematics=Kinematics()
        if(arm_ID==2):
            init_point=kinematics.arm2_init_point
        else:
            init_point=kinematics.arm1_init_point
        u=(init_point[0]-joint_point[0],init_point[1]-joint_point[1])
        cross=np.cross(vector_force,u)
        return -np.sign(cross[2])



    def potential_field(self):

        current_state_arm1=self.start_state_arm1

        current_state_arm2=self.start_state_arm2

        route=[]

        kinematics=Kinematics()

       

        #max_distance_to_target_between_arms=10


        while True:

            

            

            #max_distance_to_target_between_arms=max(distance(current_state_arm1,self.goal_state_arm1),(distance(current_state_arm2,self.goal_state_arm2)))

            #print max_distance_to_target_between_arms

            repulsive_moment_1_arm1=0
            repulsive_moment_2_arm1=0
            repulsive_moment_3_arm1=0
            repulsive_moment_4_arm1=0
            repulsive_moment_5_arm1=0

            repulsive_moment_1_arm2=0
            repulsive_moment_2_arm2=0
            repulsive_moment_3_arm2=0
            repulsive_moment_4_arm2=0
            repulsive_moment_5_arm2=0
    

            attraction_vec_arm1=self.attraction_vector(current_state_arm1,self.goal_state_arm1)

            #print current_state_arm1,"    goal  ",self.goal_state_arm1

            attraction_vec_arm2=self.attraction_vector(current_state_arm2,self.goal_state_arm2)

            joint1_point_arm1=kinematics.forward_kinematics(1,1,[current_state_arm1[0],current_state_arm1[1]])

            joint2_point_arm1=kinematics.forward_kinematics(1,3,[current_state_arm1[0],current_state_arm1[1],current_state_arm1[2],current_state_arm1[3]])

            joint3_point_arm1=kinematics.forward_kinematics(1,4,[current_state_arm1[0],current_state_arm1[1],current_state_arm1[2],current_state_arm1[3],current_state_arm1[4]])

            joint_23_middle_arm1=((joint2_point_arm1[0]+joint3_point_arm1[0]/2),(joint2_point_arm1[1]+joint3_point_arm1[1]/2),(joint2_point_arm1[2]+joint3_point_arm1[2]/2))

            joints_points_arm1=[joint1_point_arm1,joint2_point_arm1,joint_23_middle_arm1,joint3_point_arm1]



            joint1_point_arm2=kinematics.forward_kinematics(2,1,[current_state_arm2[0],current_state_arm2[1]])

            joint2_point_arm2=kinematics.forward_kinematics(2,3,[current_state_arm2[0],current_state_arm2[1],current_state_arm2[2],current_state_arm2[3]])

            joint3_point_arm2=kinematics.forward_kinematics(2,4,[current_state_arm2[0],current_state_arm2[1],current_state_arm2[2],current_state_arm2[3],current_state_arm2[4]])

            joint_23_middle_arm2=((joint2_point_arm2[0]+joint3_point_arm2[0]/2),(joint2_point_arm2[1]+joint3_point_arm2[1]/2),(joint2_point_arm2[2]+joint3_point_arm2[2]/2))

            joints_points_arm2=[joint1_point_arm2,joint2_point_arm2,joint_23_middle_arm2,joint3_point_arm2]


            j=0

            for joint_point_int in range(0,len(joints_points_arm1)):

                joint_point_arm1=joints_points_arm1[joint_point_int]

                joint_point_arm2=joints_points_arm2[joint_point_int]

                repulsive_vec_arm1=self.repulsive_vector(joint_point_arm1,self.obstacles_array,joints_points_arm2)

                repulsive_vec_arm2=self.repulsive_vector(joint_point_arm2,self.obstacles_array,joints_points_arm1)

                normal_vector_to_repulsive_vec_arm1=self.normal_vector_to_repulsive_vector(repulsive_vec_arm1)

                normal_vector_to_repulsive_vec_arm2=self.normal_vector_to_repulsive_vector(repulsive_vec_arm2)
                
                
                    

                final_repulsive_vec_x_arm1=repulsive_vec_arm1[0]+normal_vector_to_repulsive_vec_arm1[0]

                final_repulsive_vec_y_arm1=repulsive_vec_arm1[1]+normal_vector_to_repulsive_vec_arm1[1]

                final_repulsive_vec_z_arm1=repulsive_vec_arm1[2]+normal_vector_to_repulsive_vec_arm1[2]

                final_repulsive_vec_arm1=(final_repulsive_vec_x_arm1,final_repulsive_vec_y_arm1,final_repulsive_vec_z_arm1)



                final_repulsive_vec_x_arm2=repulsive_vec_arm2[0]+normal_vector_to_repulsive_vec_arm2[0]

                final_repulsive_vec_y_arm2=repulsive_vec_arm2[1]+normal_vector_to_repulsive_vec_arm2[1]

                final_repulsive_vec_z_arm2=repulsive_vec_arm2[2]+normal_vector_to_repulsive_vec_arm2[2]

                final_repulsive_vec_arm2=(final_repulsive_vec_x_arm2,final_repulsive_vec_y_arm2,final_repulsive_vec_z_arm2)



        
                repulsive_moment_for_each_joint_arm1=self.repulsive_moments(final_repulsive_vec_arm1,joint_point_arm1,j,1)

                repulsive_moment_for_each_joint_arm2=self.repulsive_moments(final_repulsive_vec_arm2,joint_point_arm2,j,2)

                repulsive_moment_1_arm1+=repulsive_moment_for_each_joint_arm1[0]

                repulsive_moment_2_arm1+=repulsive_moment_for_each_joint_arm1[1]

                repulsive_moment_3_arm1+=repulsive_moment_for_each_joint_arm1[2]

                repulsive_moment_4_arm1+=repulsive_moment_for_each_joint_arm1[3]

                repulsive_moment_5_arm1+=repulsive_moment_for_each_joint_arm1[4]


                repulsive_moment_1_arm2+=repulsive_moment_for_each_joint_arm2[0]

                repulsive_moment_2_arm2+=repulsive_moment_for_each_joint_arm2[1]

                repulsive_moment_3_arm2+=repulsive_moment_for_each_joint_arm2[2]

                repulsive_moment_4_arm2+=repulsive_moment_for_each_joint_arm2[3]

                repulsive_moment_5_arm2+=repulsive_moment_for_each_joint_arm2[4]


                j+=1

            repulsive_moment_arm1=(repulsive_moment_1_arm1,repulsive_moment_2_arm1,repulsive_moment_3_arm1,repulsive_moment_4_arm1,repulsive_moment_5_arm1)

            repulsive_moment_arm2=(repulsive_moment_1_arm2,repulsive_moment_2_arm2,repulsive_moment_3_arm2,repulsive_moment_4_arm2,repulsive_moment_5_arm2)
        
        
            att_vec_1_arm1=self.attraction_weight*attraction_vec_arm1[0]
            att_vec_2_arm1=self.attraction_weight*attraction_vec_arm1[1]
            att_vec_3_arm1=self.attraction_weight*attraction_vec_arm1[2]
            att_vec_4_arm1=self.attraction_weight*attraction_vec_arm1[3]
            att_vec_5_arm1=self.attraction_weight*attraction_vec_arm1[4]
            att_vec_arm1=(att_vec_1_arm1,att_vec_2_arm1,att_vec_3_arm1)

            rep_vec_1_arm1=self.repulsive_weight*repulsive_moment_arm1[0]
            rep_vec_2_arm1=self.repulsive_weight*repulsive_moment_arm1[1]
            rep_vec_3_arm1=self.repulsive_weight*repulsive_moment_arm1[2]
            rep_vec_4_arm1=self.repulsive_weight*repulsive_moment_arm1[3]
            rep_vec_5_arm1=self.repulsive_weight*repulsive_moment_arm1[4]
            rep_vec_arm1=(rep_vec_1_arm1,rep_vec_2_arm1,rep_vec_3_arm1)


            #print "   att   ",att_vec_1_arm1,"  rep  ",rep_vec_1_arm1

            #print "   sum_forces   ",att_vec_1_arm1+att_vec_2_arm1+att_vec_3_arm1+rep_vec_1_arm1+rep_vec_2_arm1+rep_vec_3_arm1


            att_vec_1_arm2=self.attraction_weight*attraction_vec_arm2[0]
            att_vec_2_arm2=self.attraction_weight*attraction_vec_arm2[1]
            att_vec_3_arm2=self.attraction_weight*attraction_vec_arm2[2]
            att_vec_4_arm2=self.attraction_weight*attraction_vec_arm2[3]
            att_vec_5_arm2=self.attraction_weight*attraction_vec_arm2[4]
            att_vec_arm2=(att_vec_1_arm2,att_vec_2_arm2,att_vec_3_arm2)

            

            rep_vec_1_arm2=self.repulsive_weight*repulsive_moment_arm2[0]
            rep_vec_2_arm2=self.repulsive_weight*repulsive_moment_arm2[1]
            rep_vec_3_arm2=self.repulsive_weight*repulsive_moment_arm2[2]
            rep_vec_4_arm2=self.repulsive_weight*repulsive_moment_arm2[3]
            rep_vec_5_arm2=self.repulsive_weight*repulsive_moment_arm2[4]
            rep_vec_arm2=(rep_vec_1_arm2,rep_vec_2_arm2,rep_vec_3_arm2)

            

            #print sum_forces_arm1

            
        
            
            #print "   rep   ",rep_vec_1_arm1,"  att  ",att_vec_1_arm1
            #print attraction_vec,"      ",repulsive_moment
            M_1_arm1=self.attraction_weight*attraction_vec_arm1[0]+self.repulsive_weight*repulsive_moment_arm1[0]
            M_2_arm1=self.attraction_weight*attraction_vec_arm1[1]+self.repulsive_weight*repulsive_moment_arm1[1]
            M_3_arm1=self.attraction_weight*attraction_vec_arm1[2]+self.repulsive_weight*repulsive_moment_arm1[2]
            M_4_arm1=self.attraction_weight*attraction_vec_arm1[3]+self.repulsive_weight*repulsive_moment_arm1[3]
            M_5_arm1=self.attraction_weight*attraction_vec_arm1[4]+self.repulsive_weight*repulsive_moment_arm1[4]

            M_1_arm2=self.attraction_weight*attraction_vec_arm2[0]+self.repulsive_weight*repulsive_moment_arm2[0]
            M_2_arm2=self.attraction_weight*attraction_vec_arm2[1]+self.repulsive_weight*repulsive_moment_arm2[1]
            M_3_arm2=self.attraction_weight*attraction_vec_arm2[2]+self.repulsive_weight*repulsive_moment_arm2[2]
            M_4_arm2=self.attraction_weight*attraction_vec_arm2[3]+self.repulsive_weight*repulsive_moment_arm2[3]
            M_5_arm2=self.attraction_weight*attraction_vec_arm2[4]+self.repulsive_weight*repulsive_moment_arm2[4]
       
            M_arm1=(M_1_arm1,M_2_arm1,M_3_arm1,M_4_arm1,M_5_arm1)
            M_arm2=(M_1_arm2,M_2_arm2,M_3_arm2,M_4_arm2,M_5_arm2)

            M_arm1=vector_normalize(M_arm1,5)
            M_arm2=vector_normalize(M_arm2,5)

            sum_moments_arm1=M_1_arm1+M_2_arm1+M_3_arm1

            sum_moments_arm2=M_1_arm2+M_2_arm2+M_3_arm2

            print abs(sum_moments_arm1)
            
            current_state_arm1[0]+=M_arm1[0]*self.delta
            current_state_arm1[1]+=M_arm1[1]*self.delta
            current_state_arm1[2]+=M_arm1[2]*self.delta
            current_state_arm1[3]+=M_arm1[3]*2*self.delta
            current_state_arm1[4]+=M_arm1[4]*2*self.delta

            current_state_arm2[0]+=M_arm2[0]*self.delta
            current_state_arm2[1]+=M_arm2[1]*self.delta
            current_state_arm2[2]+=M_arm2[2]*self.delta
            current_state_arm2[3]+=M_arm2[3]*2*self.delta
            current_state_arm2[4]+=M_arm2[4]*2*self.delta




            joints_state_array_arm1=[current_state_arm1[0],current_state_arm1[1],current_state_arm1[2],current_state_arm1[3],current_state_arm1[4],self.goal_state_arm1[5]]
            joints_state_array_arm2=[current_state_arm2[0],current_state_arm2[1],current_state_arm2[2],current_state_arm2[3],current_state_arm2[4],self.goal_state_arm2[5]]
            set_joints_state(self.set_joints_msg,joints_state_array_arm1,self.pub_set_joints_arm1)
            set_joints_state(self.set_joints_msg,joints_state_array_arm2,self.pub_set_joints_arm2)

            time.sleep(0.1)


            if(distance_between_2_poses(current_state_arm1,self.goal_state_arm1)<0.2 or abs(sum_moments_arm1)<300):
                self.waypoint_arm1+=1
                return (current_state_arm1,current_state_arm2,self.waypoint_arm1,self.waypoint_arm2)
                

            if(distance_between_2_poses(current_state_arm2,self.goal_state_arm2)<0.2 or abs(sum_moments_arm2)<300):
                self.waypoint_arm2+=1
                return (current_state_arm1,current_state_arm2,self.waypoint_arm1,self.waypoint_arm2)


            

            #point_in_route=(current_state[0],current_state[1],current_state[2],current_state[3],current_state[4],self.goal_state[5])
            #route.append(point_in_route)
      

        #return (current_state_arm1,current_state_arm2)


class A_star():

    def __init__(self,arm_ID,start_pose,goal_pose,obstacles_array, delta):
        self.delta=delta
        self.start_pose=start_pose
        self.goal_pose=goal_pose
        self.obstacles_array=obstacles_array
        self.arm_ID=arm_ID

        
    def A_star_algo(self,start_state,goal_state,obstacles_array,delta):
        

        kinematics=Kinematics()

        start=(start_state[0],start_state[1],start_state[2])

        goal=(goal_state[0],goal_state[1],goal_state[2])

        neighbors = [(0,delta,0),(0,-delta,0),(delta,0,0),(-delta,0,0),(delta,delta,0),(delta,-delta,0),(-delta,delta,0),(-delta,-delta,-delta),(0,delta,-delta),(0,-delta,-delta),(delta,0,-delta),(-delta,0,-delta),(delta,delta,-delta),(delta,-delta,-delta),(-delta,delta,-delta),(-delta,-delta,-delta),(0,delta,delta),(0,-delta,delta),(delta,0,delta),(-delta,0,delta),(delta,delta,delta),(delta,-delta,delta),(-delta,delta,delta),(-delta,-delta,delta)]

        close_set = set()  # close list

        came_from = {}
    

        gscore = {start:0} # score from start to current pose

        fscore = {start:distance_between_2_poses(start,goal)}  # score from current pose to goal pose

        open_set = [] #  open list

        heapq.heappush(open_set, (fscore[start], start)) #  add to the open list the fscore of the start and the start pose

        while open_set:

            current = heapq.heappop(open_set)[1] # current pose
     
 
            if distance_between_2_poses(current,goal)<0.2:  # if we reached the goal
             
                data = []
            
                while current in came_from:  # all this gives me the optimal route
                    data.append(current)

                    current = came_from[current]

                return data

            close_set.add(current)  # add the current pose to the close list

        #print close_set

            for i, j, k in neighbors:

                neighbor = current[0] + i, current[1] + j, current[2] + k   #give the neighbors to the current pose

                tentative_g_score = gscore[current] + distance_between_2_poses(current, neighbor) # gives the gscore of the neighbor through the current pose

                joint1_point=kinematics.forward_kinematics(self.arm_ID,1,[neighbor[0],neighbor[1]])

                joint2_point=kinematics.forward_kinematics(self.arm_ID,3,[neighbor[0],neighbor[1],neighbor[2],0])

                joint_12_middle=((joint1_point[0]+joint2_point[0]/2),(joint1_point[1]+joint2_point[1]/2),(joint1_point[2]+joint2_point[2]/2))

                neighbor_joints_points_array= [joint1_point,joint_12_middle,joint2_point]

                if -1.57 <= neighbor[0] < 1.57:
                

                    if -1.57<= neighbor[1] < 1.57:


                        if -1.57<= neighbor[2] < 1.57:

                            skip=False

                            for joint_pose in neighbor_joints_points_array:

                                for obstacle in obstacles_array:

                                    obstacle_point=(obstacle.x,obstacle.y,obstacle.z)   


                                    if distance_between_2_points(joint_pose,obstacle_point)<0.1:
                                        skip=True
                                        break
                    
                            if(skip):
                                continue
                                             
                                
                        else:
                            continue   

                    else:

                        continue
                else:
                    continue


                if neighbor in close_set and tentative_g_score >= gscore.get(neighbor, 0): # if neighbor is already in close list and has less gscore then dont add that neighbor

                    continue


                if  tentative_g_score < gscore.get(neighbor, 0) or neighbor not in [i[1]for i in open_set]: # if you found the same neighbor but with less g score or its the first time you see that neighbot then add him to the open lise

                    came_from[neighbor] = current


                    gscore[neighbor] = tentative_g_score

                    fscore[neighbor] = tentative_g_score + distance_between_2_poses(neighbor, goal)

                    heapq.heappush(open_set, (fscore[neighbor], neighbor))
    

        return False



    def get_route(self):


        route = self.A_star_algo(self.start_pose,self.goal_pose,self.obstacles_array,self.delta)
        

        route = route + [self.start_pose]

        route = route[::-1]

        return route









def joy_data(data):
    global x,start_button
    x=data.buttons[1]
    start_button=data.buttons[9]
    back=data.buttons[6]

  

    


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)
    




def navigation(start_pose_arm1,goal_pose_arm1,start_pose_arm2,goal_pose_arm2,attraction_weight,repulsive_weight,delta,set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2,obstacles_array):
    final_path=[]

    waypoint_arm1=0

    waypoint_arm2=0
    
    astar_arm1=A_star(1,start_pose_arm1,goal_pose_arm1,obstacles_array,0.2)

    print "planning path A star for arm 1"

    route_arm1=astar_arm1.get_route()

    astar_arm2=A_star(2,start_pose_arm2,goal_pose_arm2,obstacles_array,0.2)

    print "planning path A star for arm 2"

    route_arm2=astar_arm2.get_route()

    print "planning potential field"

    current_pose_arm1=np.array(start_pose_arm1)

    current_pose_arm2=np.array(start_pose_arm2)
   


    while(waypoint_arm1<len(route_arm1)-1 or waypoint_arm2<len(route_arm2)-1):

        print waypoint_arm1,"  ",waypoint_arm2

        if(waypoint_arm1<len(route_arm1)-1):

            target_num_arm1=route_arm1[waypoint_arm1]
        else:
            target_num_arm1=route_arm1[len(route_arm1)-1]

        target_arm1=(target_num_arm1[0],target_num_arm1[1],target_num_arm1[2],goal_pose_arm1[3],goal_pose_arm1[4],goal_pose_arm1[5])

        if(waypoint_arm2<len(route_arm2)-1):

            target_num_arm2=route_arm2[waypoint_arm2]
        else:
            target_num_arm2=route_arm2[len(route_arm2)-1]

        

        target_arm2=(target_num_arm2[0],target_num_arm2[1],target_num_arm2[2],goal_pose_arm2[3],goal_pose_arm2[4],goal_pose_arm2[5])

        P=Potential_Field(current_pose_arm1,target_arm1,current_pose_arm2,target_arm2,attraction_weight,repulsive_weight,delta,obstacles_array,set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2,waypoint_arm1,waypoint_arm2)
        
        (current_pose_arm1,current_pose_arm2,waypoint_arm1,waypoint_arm2)=P.potential_field()
        #print current_pose_arm1
        #print path
        #for point in path:
            #final_path.append(point)
        #current_pose=current_state
        
    print "successss"
    #final_path.append(goal_pose)
    #print final_path
    
    #for pose in final_path:
        #joints_state_array=[pose[0],pose[1],pose[2],pose[3],pose[4],pose[5]]
        #set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        #time.sleep(0.1)
        #if(pose[0]==goal_pose[0] and pose[1]==goal_pose[1]):
            #time.sleep(3)
    joints_state_array_arm1=[goal_pose_arm1[0],goal_pose_arm1[1],goal_pose_arm1[2],goal_pose_arm1[3],goal_pose_arm1[4],goal_pose_arm1[5]]
    joints_state_array_arm2=[goal_pose_arm2[0],goal_pose_arm2[1],goal_pose_arm2[2],goal_pose_arm2[3],goal_pose_arm2[4],goal_pose_arm2[5]]
    set_joints_state(set_joints_msg,joints_state_array_arm1,pub_set_joints_arm1)
    time.sleep(3)
    print joints_state_array_arm2
    set_joints_state(set_joints_msg,joints_state_array_arm2,pub_set_joints_arm2)
    time.sleep(3)



    #print final_path

    #print " start navigating"
    



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


        







def starting():
    global x,start_button
    global joint_state_data,joint_state_data_arm2
    global occupied_cells

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints_arm1 = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    pub_set_joints_arm2 = rospy.Publisher('/robotis/base/joint_pose_msg_arm2',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/robotis/present_joint_states_arm2", JointState, joint_state_arm2)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    #print get_route()

    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        j_pos_arm2=joint_state_data_arm2.position

        #set_joints_msg=JointPose()

        #set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            print "set mode"
            set_mode(pub_set_mode)
            #kinematics=Kinematics()
            #joints_state_array=[j_pos[0],j_pos[1],j_pos[2],j_pos[3],j_pos[4],j_pos[5]]
            #print kinematics.forward_kinematics(1,1,joints_state_array)


            


        if(start_button==1):
            
            start_arm1=(j_pos[0],j_pos[1],j_pos[2],j_pos[3],j_pos[4],j_pos[5])
            start_arm2=(j_pos_arm2[0],j_pos_arm2[1],j_pos_arm2[2],j_pos_arm2[3],j_pos_arm2[4],j_pos_arm2[5])
            obstacles_array=create_obstacles_array(occupied_cells)
            
            
            navigation(start_arm1,(1.5,1.5,-1.5,0.5,0.4,0),start_arm2,(1.5,1.5,-1.5,0.5,0.4,0),23000,1,0.01,set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2,obstacles_array)
            

        

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass