#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import numpy as np
import math
import heapq
from visualization_msgs.msg import MarkerArray
import time
#from random import random
from collections import deque
import matplotlib.pyplot as plt
from matplotlib import collections  as mc
import random


global joint_state_data

global delta,x,start_button

global occupied_cells

delta=0.08
x,start_button=0,0
joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)


class Graph:
# Define graph '''
    def __init__(self, startpos, endpos):
        self.startpos = startpos
        self.endpos = endpos

        self.vertices = [startpos]
        self.edges = []
        self.success = False

        self.vex2idx = {startpos:0}
        self.neighbors = {0:[]}
        self.distances = {0:0.}

        self.sx = endpos[0] - startpos[0]
        self.sy = endpos[1] - startpos[1]

    def add_vex(self, pos):
        try:
            idx = self.vex2idx[pos]
        except:
            idx = len(self.vertices)
            self.vertices.append(pos)
            self.vex2idx[pos] = idx
            self.neighbors[idx] = []
        return idx

    def add_edge(self, idx1, idx2, cost):
        self.edges.append((idx1, idx2))
        self.neighbors[idx1].append((idx2, cost))
        self.neighbors[idx2].append((idx1, cost))


    def randomPosition(self):
        rx=(random.randint(-157, 157)/100.0)
        ry=(random.randint(-157, 157)/100.0)
        #print rx
        #rx = random()
        #ry = random()

        pos1=rx
        pos2=ry

        #pos1 = self.startpos[0] - (self.sx / 2.) + rx * self.sx * 2
        #pos2 = self.startpos[1] - (self.sy / 2.) + ry * self.sy * 2
        

        #if pos1>1.57 or pos1<-1.57:
           # continue
       # if pos2>1.57 or pos2<-1.57:
            #continue

        return pos1, pos2

class Line():
  
    def __init__(self, p0, p1):
        self.p = np.array(p0)
        self.dirn = np.array(p1) - np.array(p0)
        self.dir = np.array(p1) - np.array(p0)
        self.dist = np.linalg.norm(self.dirn)
        self.dirn /= self.dist # normalize

    def path(self, t):
        return self.p + t * self.dirn

def distance(x, y):
    return np.linalg.norm(np.array(x) - np.array(y))


def isInObstacle(vex, obstacles, radius):
    joint1_point=forward_kinematics(1,[vex[0],vex[1]])
    joints_points=[joint1_point]
    for obs in obstacles:
        obs_point=(obs.x,obs.y,obs.z)
        if distance(obs_point, joint1_point) < radius:
            return True
    return False


def isThruObstacle(line, obstacles, radius):
    for obs in obstacles:
        obs_point=(obs.x,obs.y,obs.z)
        if Intersection(line, obs_point, radius):
        #if  intersection_y(line, obs_point , radius):
            #print "noooooo"
            return True
    return False


def nearest(G, vex, obstacles, radius):
    Nvex = None
    Nidx = None
    minDist = float("inf")

    for idx, v in enumerate(G.vertices):
        #print v
        v_cartesian=forward_kinematics(1,[v[0],v[1]])
        vex_cartesian=forward_kinematics(1,[vex[0],vex[1]])
        line = Line(v_cartesian, vex_cartesian)
        if isThruObstacle(line, obstacles, radius):
           #print " v ",v,"   vex   ",vex
            continue

        dist = distance(v, vex)
        if dist < minDist:
            minDist = dist
            Nidx = idx
            Nvex = v

    return Nvex, Nidx


def newVertex(randvex, nearvex, stepSize):
    dirn = np.array(randvex) - np.array(nearvex)
    length = np.linalg.norm(dirn)
    dirn = (dirn / length) * min (stepSize, length)

    newvex = (nearvex[0]+dirn[0], nearvex[1]+dirn[1])
    return newvex






def Intersection(line, center, radius):

    #print "   line    ",line.p,"    center    ",center,"     radius      ",radius
  
    a = np.dot(line.dirn, line.dirn)
    b = 2 * np.dot(line.dirn, line.p - center)
    c = np.dot(line.p - center, line.p - center) - radius * radius

    discriminant = b * b - 4 * a * c
    if discriminant < 0:
        return False

    t1 = (-b + np.sqrt(discriminant)) / (2 * a)
    t2 = (-b - np.sqrt(discriminant)) / (2 * a)

    if (t1 < 0 and t2 < 0) or (t1 > line.dist and t2 > line.dist):
        return False

    

    return True



def Intersection_y(line, center, radius,vex_cartesian):
    obs=[center[0],center[1],center[2]]

    a=np.cross(np.array(center)-np.array(line.p),np.array(center)-np.array(vex_cartesian))
    b=np.linalg.norm(vex_cartesian-line.p)
    d_min=a/b
    dmin=np.linalg.norm(d_min)
    if(dmin>radius):
        return False

    t_min=-(np.dot((line.p-center),(line.dir))/(np.linalg.norm(line.dir)**2))
    if(abs(t_min)<1):
        return True
    return False

    


def dijkstra(G):
  
 # Dijkstra algorithm for finding shortest path from start position to end.
  
    srcIdx = G.vex2idx[G.startpos]
    dstIdx = G.vex2idx[G.endpos]

    # build dijkstra
    nodes = list(G.neighbors.keys())
    dist = {node: float('inf') for node in nodes}
    prev = {node: None for node in nodes}
    dist[srcIdx] = 0

    while nodes:
        curNode = min(nodes, key=lambda node: dist[node])
        nodes.remove(curNode)
        if dist[curNode] == float('inf'):
            break

        for neighbor, cost in G.neighbors[curNode]:
            newCost = dist[curNode] + cost
            if newCost < dist[neighbor]:
                dist[neighbor] = newCost
                prev[neighbor] = curNode

    # retrieve path
    path = deque()
    curNode = dstIdx
    while prev[curNode] is not None:
        path.appendleft(G.vertices[curNode])
        curNode = prev[curNode]
    path.appendleft(G.vertices[curNode])
    return list(path)


def plot(G, radius, path=None):
  
  #Plot RRT, obstacles and shortest path
  
    px = [x for x, y in G.vertices]
    py = [y for x, y in G.vertices]
    fig, ax = plt.subplots()

    #for obs in obstacles:
        
        #circle = plt.Circle(obs, radius, color='red')
        #ax.add_artist(circle)

    ax.scatter(px, py, c='cyan')
    ax.scatter(G.startpos[0], G.startpos[1], c='black')
    ax.scatter(G.endpos[0], G.endpos[1], c='black')

    lines = [(G.vertices[edge[0]], G.vertices[edge[1]]) for edge in G.edges]
    lc = mc.LineCollection(lines, colors='green', linewidths=2)
    ax.add_collection(lc)

    if path is not None:
        paths = [(path[i], path[i+1]) for i in range(len(path)-1)]
        lc2 = mc.LineCollection(paths, colors='blue', linewidths=3)
        ax.add_collection(lc2)

    ax.autoscale()
    ax.margins(0.1)
    plt.show()





def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)


def distance_between_2_points(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)





def RRT(startpos, endpos, obstacles, n_iter, radius, stepSize):
 # RRT algorithm '''
    G = Graph(startpos, endpos)
    i=0
    

    for _ in range(n_iter):
        i+=1
        #print i
        
        randvex = G.randomPosition()
        if( -1.57<randvex[0]<1.57):
            if(1.57<randvex[1] or randvex[1] <-1.57):
                continue
        else:
            continue

        if isInObstacle(randvex, obstacles, radius):
            #print i
            continue
        
        nearvex, nearidx = nearest(G, randvex, obstacles, radius)
        if nearvex is None:
            continue
        
        #print "hi"
        newvex = newVertex(randvex, nearvex, stepSize)
        #print newvex

        newidx = G.add_vex(newvex)
        
        dist = distance(newvex, nearvex)
        G.add_edge(newidx, nearidx, dist)

        dist = distance(newvex, G.endpos)
        #print dist
        
        if dist < 2 * radius:
            endidx = G.add_vex(G.endpos)
            G.add_edge(newidx, endidx, dist)
            #print "hii"
            G.success = True
            #print "yay"
            print('success')
            break

    plot(G, radius)
    return G

















def joy_data(data):
    global x,start_button
    x=data.buttons[1]
    start_button=data.buttons[9]
    back=data.buttons[6]

  

    


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)




def navigation(start_pose,goal_pose,set_joints_msg,pub_set_joints,obstacles_array):
    print " starttt"
    G=RRT(start_pose,goal_pose,obstacles_array,4000,0.15,0.2)
    if G.success:
        path = dijkstra(G)
        print " start navigate "
        print(path)
        for pose in path:
            print pose
            joints_state_array=[pose[0],pose[1],-1.57,0,0,0]
            set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
            time.sleep(3)

        #plot(G, obstacles, radius, path)
    #print G



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


        







def starting():
    global x,start_button
    global joint_state_data
    global occupied_cells

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    
    rate = rospy.Rate(10) # 10hz

    #print get_route()

    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            set_mode(pub_set_mode)

        if(start_button==1):
            
            start=(j_pos[0],j_pos[1])
            obstacles_array=create_obstacles_array(occupied_cells)
            #print obstacles_array[5].x

            #print get_route(start,(1.5,1.5),obstacles_array)
            
            navigation(start,(1.5,1.5),set_joints_msg,pub_set_joints,obstacles_array)

        

        rate.sleep()




if __name__ == '__main__':
    try:
       starting()
    except rospy.ROSInterruptException:
        pass