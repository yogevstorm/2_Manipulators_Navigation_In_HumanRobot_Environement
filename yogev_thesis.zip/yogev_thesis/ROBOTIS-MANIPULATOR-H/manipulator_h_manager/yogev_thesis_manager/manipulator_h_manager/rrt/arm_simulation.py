#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np
from trajectory_factory import TrajectoryFactory
import matplotlib.animation as animation
from arm_kinematic import ArmKinematic
from Inserting_gasket.micro_action_factory import MicroActionFactory


def update_frames(frame_num, ax, joints_positions_1, joints_positions_2):
    ax.clear()
    ax.set_xlim3d(-1000, 1000)
    ax.set_ylim3d(-1000, 1000)
    ax.set_zlim3d(0, 1000)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    all_joint_1 = joints_positions_1[frame_num]
    all_joint_2 = joints_positions_2[frame_num]
    ax.plot(all_joint_1[:, 0], all_joint_1[:, 1], all_joint_1[:, 2], linewidth=10)
    ax.plot(all_joint_2[:, 0], all_joint_2[:, 1], all_joint_2[:, 2], linewidth=10)


def run_simulation(forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2):
    joints_positions_1 = []
    joints_positions_2 = []
    for ii in range(0, forward_kinematic_trajectory_arm_1.shape[0]):
        joints_positions_1.append(
            ArmKinematic.transform_points_arm_to_world(ArmKinematic.forward(forward_kinematic_trajectory_arm_1[ii]),
                                                       ArmKinematic.transform_matrix_arm_1))
        joints_positions_2.append(
            ArmKinematic.transform_points_arm_to_world(ArmKinematic.forward(forward_kinematic_trajectory_arm_2[ii]),
                                                       ArmKinematic.transform_matrix_arm_2))

    fig = plt.figure(1)
    ax = fig.add_subplot(111, projection='3d')
    frame_number = forward_kinematic_trajectory_arm_1.shape[0]
    ani = animation.FuncAnimation(fig, update_frames, frame_number, fargs=(ax, joints_positions_1, joints_positions_2),
                                  interval=100, blit=False)
    plt.show()


def simulate_insert_gasket():
    m = TrajectoryFactory.get_insert_gasket_fk_trajectory_as_matrix()
    run_simulation(m[:, 0:6], m[:, 6:12])


def simulate_insert_gasket_kc():
    insert_arm_fk_trajectory, forward_kinematic_trajectory_arm_guid, \
           gripper_command_of_the_insert_arm, gripper_command_of_the_guid_arm, jig = TrajectoryFactory.get_insert_gasket_kc_fk_trajectory()
    run_simulation(insert_arm_fk_trajectory, forward_kinematic_trajectory_arm_guid)


def simulate_home():
    m = TrajectoryFactory.get_home_fk_trajectory()
    run_simulation(m[:, 0:6], m[:, 6:12])


def simulate_LDO():
    m = TrajectoryFactory.get_LDO_trajectory()
    run_simulation(m[:, 0:6], m[:, 6:12])


def simulate_initial_insert_gasket():
    m = TrajectoryFactory.get_initial_insert_gasket_fk_trajectory()
    run_simulation(m[:, 0:6], m[:, 6:12])


def simulate_full_path_insert_gasket():
    m = TrajectoryFactory.get_initial_insert_gasket_fk_trajectory()
    n = TrajectoryFactory.get_insert_gasket_fk_trajectory_as_matrix()
    m = np.vstack((m, n))
    run_simulation(m[:, 0:6], m[:, 6:12])


def simulate_calibration_trajectory():
    m = TrajectoryFactory.get_calibration_fk_trajectory()
    run_simulation(m[:, 0:6], m[:, 6:12])


def simulate_joint_movement():
    m_1 = np.linspace(np.array([0, 0, 0, 0, np.pi/2, 0]), np.array([0, 0, 0, np.pi, np.pi/2, 0]), 100)

    run_simulation(m_1, m_1)


def test_init_arms_config():
    fig = plt.figure(1)
    thetas = np.zeros(6)

    all_joint_1 = ArmKinematic.transform_points_arm_to_world(ArmKinematic.forward(thetas), ArmKinematic.transform_matrix_arm_1)
    all_joint_2 = ArmKinematic.transform_points_arm_to_world(ArmKinematic.forward(thetas),
                                                             ArmKinematic.transform_matrix_arm_2)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlim3d(-400, 400)
    ax.set_ylim3d(-400, 400)
    ax.set_zlim3d(-50, 500)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.plot3D(all_joint_1[:, 0], all_joint_1[:, 1], all_joint_1[:, 2], color="red")
    ax.plot3D(all_joint_2[:, 0], all_joint_2[:, 1], all_joint_2[:, 2])

    plt.draw()
    plt.pause(60)


def plot_insert_gasket_trajectory():
    fig = plt.figure(1)
    micro_action_factory = MicroActionFactory()
    micro_action = micro_action_factory.get_micro_action()

    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.plot3D(micro_action.P_RH_P[:, 0], micro_action.P_RH_P[:, 1], micro_action.P_RH_P[:, 2], color="red")
    ax.plot3D(micro_action.P_LH_P[:, 0], micro_action.P_LH_P[:, 1], micro_action.P_LH_P[:, 2])

    plt.draw()
    plt.pause(60)


def test_arms_config_space():
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    config_space_1, forbidden_1 = get_config_space(ArmKinematic.transform_matrix_arm_1)
    config_space_2, forbidden_2 = get_config_space(ArmKinematic.transform_matrix_arm_2)
    ax.scatter(config_space_1[1:, 0], config_space_1[1:, 1], config_space_1[1:, 2])
    #ax.scatter(forbidden_1[1:, 0], forbidden_1[1:, 1], forbidden_1[1:, 2], color="red")
    ax.scatter(config_space_2[1:, 0], config_space_2[1:, 1], config_space_2[1:, 2])
    #ax.scatter(forbidden_2[1:, 0], forbidden_2[1:, 1], forbidden_2[1:, 2], color="red")

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    plt.show()


def get_config_space(transform_matrix):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    space = get_discrete_space()
    space = ArmKinematic.transform_points_arm_to_world(space.T, transform_matrix)
    config_space = np.zeros(3)
    forbidden = np.zeros(3)
    for row in space:
        for index in range(8):
            try:
                t = ArmKinematic.inverse(row, np.array([0, 0, 0]), index)
                #ax.scatter(t)
                #plt.draw()
                config_space = np.vstack((config_space, row))
                break
            except:
                if index == 7:
                    forbidden = np.vstack((forbidden, row))
    return config_space, forbidden


def get_discrete_space():
    delta = 15
    limit = 1000
    x_0 = np.array([np.linspace(limit, 0, delta), np.linspace(0, -limit, delta), np.zeros([delta])])
    y_0 = np.array([np.linspace(0, -limit, delta), np.linspace(limit, 0, delta), np.zeros([delta])])
    xy_0 = np.linspace(x_0, y_0, delta)
    flat_xy_0 = xy_0.transpose(1, 2, 0).reshape(3, -1)

    x_600 = np.array([np.linspace(limit, 0, delta), np.linspace(0, -limit, delta), np.ones([delta])*limit])
    y_600 = np.array([np.linspace(0, -limit, delta), np.linspace(limit, 0, delta), np.ones([delta])*limit])
    xy_600 = np.linspace(x_600, y_600, delta)
    flat_xy_600 = xy_600.transpose(1, 2, 0).reshape(3, -1)

    space = np.linspace(flat_xy_0, flat_xy_600, delta)
    flat_space = space.transpose(1, 2, 0).reshape(3, -1)
    return flat_space


if __name__ == "__main__":
    # simulate_LDO()
    # plot_insert_gasket_trajectory()
    # simulate_initial_insert_gasket()
    # simulate_full_path_insert_gasket()
    # test_init_arms_config()
    simulate_insert_gasket_kc()
    # simulate_calibration_trajectory()
    # simulate_home()
