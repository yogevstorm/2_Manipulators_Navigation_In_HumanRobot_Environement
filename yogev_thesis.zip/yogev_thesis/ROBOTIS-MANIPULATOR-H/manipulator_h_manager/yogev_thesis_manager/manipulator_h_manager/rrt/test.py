import datetime
import pickle

a = pickle.load(open("matrices/2020-12-27 14:58:28.088110max_delta_angles_error_matrix.pkl",'rb'))
# b = pickle.load(open("matrices/2020-12-27 11:53:20.699901euclidean_dist_delta_angles_error_matrix.pkl",'rb'))
# c = pickle.load(open("matrices/euclidean_dist_delta_tool_error_matrix.pkl2020-12-27 09:37:32.462107",'rb'))
# e = pickle.load(open("matrices/2020-12-27 11:53:20.699901max_delta_tool_error_matrix.pkl",'rb'))
print(a)