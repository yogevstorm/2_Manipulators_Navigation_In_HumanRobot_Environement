#!/usr/bin/env python3

import rospy  # Import the Python library for ROS
from std_msgs.msg import Float64
from time import time, sleep
import numpy as np
from gazebo_msgs.srv import *
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from numpy import sin, cos, pi


class ROS_god:

    def __init__(self):
        #rospy.init_node('ROS_arms', anonymous=True)
        self.pub1 = rospy.Publisher('/arm_left/robotis/base/joint_pose_msg', JointPose, queue_size=0)
        self.pub2 = rospy.Publisher('/arm_right/robotis/base/joint_pose_msg', JointPose, queue_size=0)

        self.rate = rospy.Rate(50)

        self.kp1 = JointPose()
        self.kp2 = JointPose()

        self.kp1.name = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']
        self.kp1.value = [0, 0, 0, 0, 0, 0]

        self.kp2.name = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']
        self.kp2.value = [0, 0, 0, 0, 0, 0]

        self.present_right = [0, 0, 0, 0, 0, 0]
        self.present_left = [0, 0, 0, 0, 0, 0]


    def send_to_arm(self, pos1, pos2):
        error1 = np.max(np.abs(pos1[:-1] - self.present_right[:-1]))
        error2 = np.max(np.abs(pos2[:-1] - self.present_left[:-1]))

        if error1 > np.deg2rad(10):
            raise ValueError(f'Arm left error: {np.rad2deg(error1)}')
        if error2 > np.deg2rad(10):
            raise ValueError(f'Arm right error: {np.rad2deg(error2)}')

        self.kp1.value = pos1
        self.kp2.value = pos2

        self.pub1.publish(self.kp1)
        self.pub2.publish(self.kp2)
        self.rate.sleep()

    def send_to_arm1(self, pos1):
        self.kp1.value = pos1
        self.pub1.publish(self.kp1)
        self.rate.sleep()

    def send_to_arm2(self, pos2):
        self.kp2.value = pos2
        self.pub2.publish(self.kp2)
        self.rate.sleep()

    def read_arm_pos(self):
        rospy.Subscriber("/arm_right/robotis/present_joint_states", JointState, self.callback_left, queue_size=1)
        rospy.Subscriber("/arm_left/robotis/present_joint_states", JointState, self.callback_right, queue_size=1)
        # rospy.spin()

    def callback_right(self, data):
        self.present_right = data.position
        # rospy.loginfo("present_right {} ".format(data.position))
        #self.rate.sleep()

    def callback_left(self, data):
        # rospy.loginfo("present_left {} ".format(data.position))
        self.present_left = data.position;
        #self.rate.sleep()


class kinmatics:
    def __init__(self, gripper):
        self.l = [159, 265.6991, 259.7383, 123]
        self.fas = [1.4576, 1.3419]
        self.gripper = gripper;

    def invers(self, pos, ori, i=0, t6=0, t1=0):
        ori = ori * np.pi / 180
        s = np.array(
            [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1]])

        # R06=self.Ax(ori[0])*self.Ay(ori[1])*self.Az(ori[2])*self.Ay(pi/2)
        R06 = np.array([[-sin(ori[1]), -sin(ori[2]) * cos(ori[1]), cos(ori[1]) * cos(ori[2]), 0],
                        [sin(ori[0]) * cos(ori[1]),
                         -sin(ori[0]) * sin(ori[1]) * sin(ori[2]) + cos(ori[0]) * cos(ori[2]),
                         sin(ori[0]) * sin(ori[1]) * cos(ori[2]) + sin(ori[2]) * cos(ori[0]), 0],
                        [-cos(ori[0]) * cos(ori[1]),
                         sin(ori[0]) * cos(ori[2]) + sin(ori[1]) * sin(ori[2]) * cos(ori[0]),
                         sin(ori[0]) * sin(ori[2]) - sin(ori[1]) * cos(ori[0]) * cos(ori[2]), 0], [0, 0, 0, 1]])

        # pc=self.Ad([pos[0],pos[1],pos[2]])*np.dot(R06,np.array([[0],[0],[-l[3]],[1]])))
        pc = np.array([[pos[0, 0] - (self.gripper + self.l[3]) * cos(ori[1]) * cos(ori[2])],
                       [pos[0, 1] - (self.gripper + self.l[3]) * (
                                   (sin(ori[0])) * sin(ori[1]) * cos(ori[2]) + sin(ori[2]) * cos(ori[0]))],
                       [pos[0, 2] - (self.gripper + self.l[3]) * (
                                   (sin(ori[0])) * sin(ori[2]) - sin(ori[1]) * cos(ori[0]) * cos(ori[2]))]])

        R06 = R06[:3, :3]
        gova = pc[2, 0] - self.l[0]
        yeter = s[i, 0] * (pc[0, 0] ** 2 + pc[1, 0] ** 2) ** 0.5
        D = ((yeter ** 2 + gova ** 2 - self.l[1] ** 2 - self.l[2] ** 2) / (2 * self.l[1] * self.l[2]))

        if (pc[0, 0] == 0 and pc[1, 0] == 0):
            t1 = t1
        else:
            t1 = np.arctan2(pc[1, 0] / (yeter), pc[0, 0] / (yeter))
        t3 = np.arctan2(s[i, 1] * (1 - D ** 2) ** 0.5, D)
        t2 = -(np.arctan2(gova, yeter) - np.arctan2(self.l[2] * sin(-t3), self.l[1] + self.l[2] * cos(-t3)))
        t3 = t3 - self.fas[1]
        t2 = t2 + self.fas[0]

        R03 = np.array([[-sin(t2 + t3) * cos(t1), -sin(t1), cos(t1) * cos(t2 + t3)],
                        [-sin(t1) * sin(t2 + t3), cos(t1), sin(t1) * cos(t2 + t3)],
                        [-cos(t2 + t3), 0, -sin(t2 + t3)]])

        # http://aranne5.bgu.ac.il/Free_publications/mavo-lerobotica.pdf
        R36 = np.dot(R03.T, R06)

        st5 = -s[i, 2] * (R36[0, 2] ** 2 + R36[1, 2] ** 2) ** 0.5
        if abs(st5) < 1e-4:
            t5 = 0
            t6 = t6
            t4 = np.arctan2(R36[1, 0], R36[0, 0]) + t6
        else:
            t5 = np.arctan2(st5, R36[2, 2])
            t4 = np.arctan2(R36[1, 2] / st5, R36[0, 2] / st5)
            t6 = np.arctan2(R36[2, 1] / st5, -R36[2, 0] / st5)

        return (np.array([[t1, t2, t3, t4, t5, t6]]))
    @staticmethod
    def forward(t):
        l_f = [159, 234, 42.4264, 228, 123, 0]
        points = np.array([[l_f[4] * (
                -1.0 * (sin(t[0]) * sin(t[3]) + sin(t[1] + t[2]) * cos(t[0]) * cos(t[3])) * sin(t[4]) + 1.0 * cos(
            t[0]) * cos(t[4]) * cos(t[1] + t[2])) + (
                                    1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * cos(t[0]),
                            l_f[4] * ((-1.0 * sin(t[0]) * sin(t[1] + t[2]) * cos(t[3]) + sin(t[3]) * cos(t[0])) * sin(
                                t[4]) + 1.0 * sin(t[0]) * cos(t[4]) * cos(t[1] + t[2])) + (
                                    1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * sin(t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                        -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(
                                    t[1])) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * cos(t[1] + t[2] + pi / 4) - 1.0 *
                            l_f[
                                3] * sin(t[1] + t[2]) - 1.0 * l_f[4] * (
                                    sin(t[4]) * cos(t[3]) * cos(t[1] + t[2]) + sin(t[1] + t[2]) * cos(t[4]))],

                           [(1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * cos(t[0]),
                            (1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * sin(t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                        -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(
                                    t[1])) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * cos(t[1] + t[2] + pi / 4) - 1.0 *
                            l_f[
                                3] * sin(t[1] + t[2])],

                           [(1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + t[2] + pi / 4)) * cos(t[0]),
                            (1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4)) * sin(t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                        -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(
                                    t[1])) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * cos(t[1] + t[2] + pi / 4)],

                           [(1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + pi / 4)) * cos(
                               t[0]),
                            (1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4)) * sin(
                                t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                    -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(t[1]))],

                           [l_f[1] * sin(t[1]) * cos(t[0]),
                            l_f[1] * sin(t[0]) * sin(t[1]),
                            l_f[0] + l_f[1] * cos(t[1])],

                           [0, 0, l_f[0]],

                           [0, 0, 0]])

        return points
#
# if __name__ == '__main__':
#      arms = ROS_god()
#      arms.read_arm_pos()
#
#     # while 1:
#     #
#     #     # sleep(0.01)
#     #     kin = kinmatics(145)
#     #     a = np.array([[0, 0, 0, 0, 0, 0]])
#     #     for i in range(8):
#     #         a = np.append(a, (kin.invers(np.array([[30 + 258 + 123 + 145, 0, 159 + 264 + 30]]), np.array([0, 0, 0]), i)),
#     #                       axis=0)
#     #     a = a[1:]
#     #
#      #pos1 = np.array([np.deg2rad(179), 0, 0, 0, 0, 0])
#      for i in (range(100)):
#         arms.send_to_arm([np.pi*0.5, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0])
#      #
#      # while 1:
#      #     for i in (range(400)):
#      #         print(0.2 + i)
#      #         pos1 = np.array([0.2, 0, 0, 0, 0, i / 100])
#      #         pos2 = np.array([0.2, 0, 0, 0, 0, -i / 100])
#      #         arms.send_to_arm(pos1, pos2)
#      #         print("\t\t", np.round(np.array(arms.present_right), 3), "_\t\t", np.round(np.array(arms.present_left), 3))
#      #         sleep(0.01)
#      #
#      #     for i in (range(400)):
#      #         print(0.2 + i)
#      #         pos1 = np.array([0.2, 0, 0, 0, 0, (400 - i) / 100])
#      #         pos2 = np.array([0.2, 0, 0, 0, 0, -(400 - i) / 100])
#      #         arms.send_to_arm(pos1, pos2)
#      #         print("\t\t", np.round(np.array(arms.present_right), 3), "_\t\t", np.round(np.array(arms.present_left), 3))
#      #         sleep(0.01)
#
