#!/usr/bin/env python3
import numpy as np
from trajectory_convertor import TrajectoryConvertor
from arm_kinematic import ArmKinematic
from gripper import Gripper


class TrajectoryBuilder:
    """ This class help to build trajectory for robotic arm in terms of positions and orientation. """

    LINEAR_STEP = 5  # [mm]
    ANGULAR_STEP = np.deg2rad(2)

    def __init__(self, init_position_arm_1, init_orientation_arm_1, init_position_arm_2, init_orientation_arm_2, init_angle_jig):
        self.trajectory_arm_1 = init_position_arm_1
        self.orientation_arm_1 = init_orientation_arm_1
        self.gripper_1 = np.array([[Gripper.OPEN_STATE]], dtype=np.float32)
        self.trajectory_arm_2 = init_position_arm_2
        self.orientation_arm_2 = init_orientation_arm_2
        self.gripper_2 = np.array([[Gripper.OPEN_STATE]], dtype=np.float32)
        self.theta_jig = init_angle_jig

    def linspace(self, matrix, v_target, slice_number=0):
        v_current_state = matrix[-1, :]
        if not slice_number:
            slice_number = self.get_slice_number(v_current_state, v_target)
        m_steps = np.linspace(v_current_state, v_target, slice_number)
        if slice_number == 1:
            return np.append(matrix, np.array([v_target]), axis=0), slice_number
        else:
            # Remove the current position from the trajectory matrix.
            return np.append(matrix, m_steps[1:, :], axis=0), slice_number

    def move_arm_1(self, v_target, slice_number=0):
        self.trajectory_arm_1, slice_number = self.linspace(self.trajectory_arm_1, v_target, slice_number)
        return slice_number

    def move_arm_2(self, v_target, slice_number=0):
        self.trajectory_arm_2, slice_number = self.linspace(self.trajectory_arm_2, v_target, slice_number)
        return slice_number

    def move_both_arms(self, v_target_1, v_target_2):
        slice_number_1 = self.get_slice_number(self.trajectory_arm_1[-1, :], v_target_1)
        slice_number_2 = self.get_slice_number(self.trajectory_arm_2[-1, :], v_target_2)
        max_slice_number = np.max([slice_number_1, slice_number_2])
        self.move_arm_1(v_target_1, max_slice_number)
        self.move_arm_2(v_target_2, max_slice_number)
        self.freeze_orientation_arm_1_and_2(max_slice_number - 1)
        self.freeze_gripper_1_and_2(max_slice_number - 1)
        return max_slice_number

    def rotate_arm_1(self, v_target_orientation, slice_number=0):
        self.orientation_arm_1, slice_number = self.linspace(self.orientation_arm_1, v_target_orientation, slice_number)
        return slice_number

    def rotate_arm_2(self, v_target_orientation, slice_number=0):
        self.orientation_arm_2, slice_number = self.linspace(self.orientation_arm_2, v_target_orientation, slice_number)
        return slice_number

    def rotate_both_arms(self, v_target_orientation_1, v_target_orientation_2):
        slice_number_1 = self.get_slice_number(self.orientation_arm_1[-1, :], v_target_orientation_1, self.ANGULAR_STEP)
        slice_number_2 = self.get_slice_number(self.orientation_arm_2[-1, :], v_target_orientation_2, self.ANGULAR_STEP)
        max_slice_number = np.max([slice_number_1, slice_number_2])
        self.rotate_arm_1(v_target_orientation_1, max_slice_number)
        self.rotate_arm_2(v_target_orientation_2, max_slice_number)
        self.freeze_position_arm_1_2(max_slice_number - 1)
        self.freeze_gripper_1_and_2(max_slice_number - 1)
        return max_slice_number

    def move_and_rotate_both_arms(self, v_target_1, v_target_orientation_1, v_target_2, v_target_orientation_2):
        slice_number_1_0 = self.get_slice_number(self.orientation_arm_1[-1, :], v_target_orientation_1, self.ANGULAR_STEP)
        slice_number_1 = self.get_slice_number(self.trajectory_arm_1[-1, :], v_target_1, self.LINEAR_STEP)
        slice_number_2_0 = self.get_slice_number(self.orientation_arm_2[-1, :], v_target_orientation_2, self.ANGULAR_STEP)
        slice_number_2 = self.get_slice_number(self.trajectory_arm_2[-1, :], v_target_2, self.LINEAR_STEP)
        max_slice_number = np.max([slice_number_1, slice_number_2, slice_number_1_0, slice_number_2_0])
        self.rotate_arm_1(v_target_orientation_1, max_slice_number)
        self.rotate_arm_2(v_target_orientation_2, max_slice_number)
        self.move_arm_1(v_target_1, max_slice_number)
        self.move_arm_2(v_target_2, max_slice_number)
        self.freeze_gripper_1_and_2(max_slice_number - 1)
        return max_slice_number

    def set_gripper_1_state(self, state):
        self.gripper_1[-1] = state

    def set_gripper_2_state(self, state):
        self.gripper_2[-1] = state

    def freeze_position_arm_1(self, freeze_number):
        repeats = np.zeros([self.trajectory_arm_1.shape[0]])
        repeats[-1] = freeze_number
        self.trajectory_arm_1 = np.append(self.trajectory_arm_1, np.repeat(self.trajectory_arm_1, repeats=list(repeats), axis=0), axis=0)

    def freeze_position_arm_2(self, freeze_number):
        repeats = np.zeros([self.trajectory_arm_2.shape[0]])
        repeats[-1] = freeze_number
        self.trajectory_arm_2 = np.append(self.trajectory_arm_2, np.repeat(self.trajectory_arm_2, repeats=list(repeats), axis=0), axis=0)

    def freeze_position_arm_1_2(self, freeze_number):
        self.freeze_position_arm_1(freeze_number)
        self.freeze_position_arm_2(freeze_number)

    def freeze_orientation_arm_1(self, freeze_number):
        repeats = np.zeros([self.orientation_arm_1.shape[0]])
        repeats[-1] = freeze_number
        self.orientation_arm_1 = np.append(self.orientation_arm_1, np.repeat(self.orientation_arm_1, repeats=list(repeats), axis=0), axis=0)

    def freeze_orientation_arm_2(self, freeze_number):
        repeats = np.zeros([self.orientation_arm_2.shape[0]])
        repeats[-1] = freeze_number
        self.orientation_arm_2 = np.append(self.orientation_arm_2, np.repeat(self.orientation_arm_2, repeats=list(repeats), axis=0), axis=0)

    def freeze_orientation_arm_1_and_2(self, freeze_number):
        self.freeze_orientation_arm_1(freeze_number)
        self.freeze_orientation_arm_2(freeze_number)

    def freeze_gripper_1(self, freeze_number):
        repeats = np.zeros([self.gripper_1.shape[0]])
        repeats[-1] = freeze_number
        self.gripper_1 = np.append(self.gripper_1, np.repeat(self.gripper_1, repeats=list(repeats), axis=0), axis=0)

    def freeze_gripper_2(self, freeze_number):
        repeats = np.zeros([self.gripper_2.shape[0]])
        repeats[-1] = freeze_number
        self.gripper_2 = np.append(self.gripper_2, np.repeat(self.gripper_2, repeats=list(repeats), axis=0), axis=0)

    def freeze_gripper_1_and_2(self, freeze_number):
        self.freeze_gripper_1(freeze_number)
        self.freeze_gripper_2(freeze_number)

    def freeze_all(self, freeze_number):
        self.freeze_position_arm_1_2(freeze_number)
        self.freeze_orientation_arm_1_and_2(freeze_number)
        self.freeze_gripper_1_and_2(freeze_number)

    def get_slice_number(self, v_current, v_target, step=LINEAR_STEP):
        distance = np.linalg.norm(v_target - v_current)
        slice_number = int(np.ceil(distance / step))
        return slice_number

    def get_fk_trajectory(self):
        trajectory_arm_1 = TrajectoryConvertor.format_positions_and_orientation(self.trajectory_arm_1, self.orientation_arm_1, ArmKinematic.transform_matrix_arm_1)
        trajectory_arm_2 = TrajectoryConvertor.format_positions_and_orientation(self.trajectory_arm_2, self.orientation_arm_2, ArmKinematic.transform_matrix_arm_2)

        forward_kinematic_trajectory_arm_1 = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_1)
        forward_kinematic_trajectory_arm_2 = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_2)
        return forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2

    def clean(self):
        self.trajectory_arm_1 = self.trajectory_arm_1[-2:-1]
        self.trajectory_arm_2 = self.trajectory_arm_2[-2:-1]
        self.orientation_arm_1 = self.orientation_arm_1[-2:-1]
        self.orientation_arm_2 = self.orientation_arm_2[-2:-1]
