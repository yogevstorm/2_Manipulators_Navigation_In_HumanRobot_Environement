#!/usr/bin/env python3
from trajectory_builder import TrajectoryBuilder
from trajectory_convertor import TrajectoryConvertor
from Inserting_gasket.micro_action_factory import MicroActionFactory
from arm_kinematic import ArmKinematic
import numpy as np
from gripper import Gripper
from ldo_trajectory_builder import LDO_trajectpry


class TrajectoryFactory:
    """ This class responsible to to build and serve different trajectories for the robotic arms. """

    @staticmethod
    def get_initial_insert_gasket_fk_trajectory():
        micro_action_factory = MicroActionFactory()
        micro_action = micro_action_factory.get_micro_action()
        target_position_arm_1 = micro_action.P_LH_P[0]  # Insert arm
        target_position_arm_2 = micro_action.P_RH_P[0]  # Guide arm

        init_position_arm_1 = np.array([[-200, -600, 690]])
        init_orientation_arm_1 = np.array([[np.pi*0.25, np.pi*0.5, 0]])
        init_position_arm_2 = np.array([[200, -600, 690]])
        init_orientation_arm_2 = np.array([[-np.pi*0.25, np.pi*0.5, 0]])
        trajectory_builder = TrajectoryBuilder(init_position_arm_1, init_orientation_arm_1, init_position_arm_2, init_orientation_arm_2, 0)
        # Open the grippers.
        trajectory_builder.set_gripper_2_state(Gripper.OPEN_STATE)
        trajectory_builder.set_gripper_1_state(Gripper.OPEN_STATE)
        # Move the arms up grab the gasket.
        trajectory_builder.move_both_arms(np.array([-200, -960, 730]), np.array([200, -960, 750]))
        # Close the grippers on the gasket.
        trajectory_builder.set_gripper_2_state(Gripper.GRIP_STATE)
        trajectory_builder.set_gripper_1_state(Gripper.GRIP_STATE)
        # Pull down the arms after grabbing the gasket.
        trajectory_builder.move_both_arms(np.array([-200, -950, 610]), np.array([200, -950, 610]))
        # Rotate the grippers to face down.
        trajectory_builder.move_and_rotate_both_arms(np.array([-200, -700, 300]), np.array([np.pi*0.5, np.pi*0.5, 0]), np.array([200, -700, 300]), np.array([-np.pi*0.5, np.pi*0.5, 0]))
        # trajectory_builder.move_and_rotate_both_arms(np.array([-190, -650, 100]), np.array([np.pi*0.95, np.pi*0.5, 0]), np.array([190, -650, 100]), np.array([-np.pi*0.95, np.pi*0.5, 0]))
        # trajectory_builder.move_both_arms(np.array([-190, -300, 50]), np.array([190, -300, 50]))
        # trajectory_builder.move_and_rotate_both_arms(np.array([-190, -170, 50]), np.array([np.pi, np.pi * 0.5, 0]), np.array([190, -170, 50]), np.array([-np.pi, np.pi * 0.5, 0]))
        # # Insert the gasket
        # trajectory_builder.freeze_all(20)
        # trajectory_builder.move_both_arms(np.array([-190, -170, 20]), np.array([190, -170, 20]))
        # # Change the inserting gripper to open mode and freeze the arms for a moment.
        # trajectory_builder.freeze_all(10)
        # trajectory_builder.set_gripper_1_state(Gripper.OPEN_STATE)
        # trajectory_builder.freeze_all(10)
        # # Lift the inserting arm to change the gripper edge.
        # trajectory_builder.move_both_arms(np.array([-190, -170, 50]), np.array([190, -170, 10]))
        # # Change the grippers states.
        # trajectory_builder.set_gripper_1_state(Gripper.INSERT_STATE)  # Change the inserting arm to insert state.
        # trajectory_builder.set_gripper_2_state(Gripper.CAGE_STATE)  # Change the guiding arm to cage state.
        # trajectory_builder.freeze_all(10)
        # # Move the inserting arm and the guid arm to the initial position for inserting the gasket
        # trajectory_builder.move_both_arms(np.array([target_position_arm_1[0], target_position_arm_1[1], 75]), np.array(target_position_arm_2))
        # trajectory_builder.move_both_arms(np.array(target_position_arm_1), np.array(target_position_arm_2))
        # Freeze the end of the trajectory.
        trajectory_builder.freeze_all(100)
        forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2 = trajectory_builder.get_fk_trajectory()
        jig = 0 * np.ones((forward_kinematic_trajectory_arm_1.shape[0], 1))
        return np.concatenate((forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2,
                               trajectory_builder.gripper_1, trajectory_builder.gripper_2, jig), axis=1)

    @staticmethod
    def get_home_fk_trajectory():
        init_position_arm_1 = np.array([[0, 0, 20]])
        init_orientation_arm_1 = np.array([[np.pi, np.pi * 0.5, 0]])
        init_position_arm_2 = np.array([[100, -100, 20]])
        init_orientation_arm_2 = np.array([[np.pi, np.pi * 0.5, 0]])
        trajectory_builder = TrajectoryBuilder(init_position_arm_1, init_orientation_arm_1, init_position_arm_2,
                                               init_orientation_arm_2, 0)
        trajectory_builder.set_gripper_2_state(Gripper.CAGE_STATE)
        trajectory_builder.set_gripper_1_state(Gripper.CAGE_STATE)
        trajectory_builder.freeze_all(100)
        forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2 = trajectory_builder.get_fk_trajectory()
        jig = - np.pi * 0 * np.ones((forward_kinematic_trajectory_arm_1.shape[0], 1))
        return np.concatenate((forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2,
                               trajectory_builder.gripper_1, trajectory_builder.gripper_2, jig), axis=1)

    @staticmethod
    def get_calibration_fk_trajectory():

        y = 250
        z = 450
        wait = 150

        init_position_arm_1 = np.array([[0, y, z]])
        init_orientation_arm_1 = np.array([[0, 0, np.pi*0.5]])
        init_position_arm_2 = np.array([[0, y, z]])
        init_orientation_arm_2 = np.array([[0, 0, np.pi*0.5]])
        trajectory_builder = TrajectoryBuilder(init_position_arm_1, init_orientation_arm_1, init_position_arm_2, init_orientation_arm_2, 0)
        trajectory_builder.set_gripper_2_state(Gripper.INSERT_STATE)
        trajectory_builder.set_gripper_1_state(Gripper.INSERT_STATE)
        trajectory_builder.freeze_all(wait)
        # Move on z axis
        trajectory_builder.move_both_arms(np.array([0, y, z + 200]), np.array([0, y, z + 200]))
        trajectory_builder.freeze_all(wait)
        trajectory_builder.move_both_arms(np.array([0, y, z]), np.array([0, y, z]))
        trajectory_builder.freeze_all(wait)
        # Move on y axis
        trajectory_builder.move_both_arms(np.array([0, y + 200, z]), np.array([0, y + 200, z]))
        trajectory_builder.freeze_all(wait)
        trajectory_builder.move_both_arms(np.array([0, y, z]), np.array([0, y, z]))
        trajectory_builder.freeze_all(wait)
        # Move on x axis
        trajectory_builder.move_both_arms(np.array([-200, y, z]), np.array([-200, y, z]))
        trajectory_builder.freeze_all(wait)
        trajectory_builder.move_both_arms(np.array([0, y, z]), np.array([0, y, z]))
        trajectory_builder.freeze_all(wait)
        forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2 = trajectory_builder.get_fk_trajectory()
        jig = np.pi * 0 * np.ones((forward_kinematic_trajectory_arm_1.shape[0], 1))
        return np.concatenate((forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2,
                               trajectory_builder.gripper_1, trajectory_builder.gripper_2, jig), axis=1)

    @staticmethod
    def get_insert_gasket_fk_trajectory():
        print("Calc trajectory path for both arms.")
        micro_action_factory = MicroActionFactory()
        micro_action = micro_action_factory.get_micro_action()

        # Rotate the arms so the gripper will be perpendicular to xy plane.
        orientation = np.zeros(micro_action.P_RH_P.shape) + np.array([0, -np.pi*0.5, 0])
        # Format data to [x, y, z, roll, pitch, yaw]
        trajectory_arm_1 = TrajectoryConvertor.format_positions_and_orientation(micro_action.P_LH_P, orientation, ArmKinematic.transform_matrix_arm_1)
        trajectory_arm_2 = TrajectoryConvertor.format_positions_and_orientation(micro_action.P_RH_P, orientation, ArmKinematic.transform_matrix_arm_2)

        print("Calc trajectory path in forward kinematic for arm 1 - Guid(B).")
        forward_kinematic_trajectory_arm_1 = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_1)
        print("Calc trajectory path in forward kinematic for arm 2 - Insert(O).")
        forward_kinematic_trajectory_arm_2 = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_2)

        # Rotate the gripper system along z axis.
        forward_kinematic_trajectory_arm_1[:, 5] += micro_action.roll_pich_yaw_pol[:, 2]
        forward_kinematic_trajectory_arm_2[:, 5] += micro_action.roll_pich_yaw_pol[:, 2]

        TrajectoryConvertor.convert_angle_abs_value_to_less_than_pi(forward_kinematic_trajectory_arm_1)
        TrajectoryConvertor.convert_angle_abs_value_to_less_than_pi(forward_kinematic_trajectory_arm_2)
        jig = np.array([micro_action.theta_jig]).transpose()
        
        return forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2, jig

    @staticmethod
    def get_insert_gasket_kc_fk_trajectory():
        data = TrajectoryFactory.get_trajectory_from_record('trajectories/kc_insert_trajectory_04-29-2021_half-path-demo.csv')
        theta6 = data[:, -1]
        jig = np.array([data[:, -2]]).T
        insert_arm_fk_trajectory = data[:, :6]
        insert_arm_ik_trajectory = np.zeros((1, 3))
        for step in insert_arm_fk_trajectory:
            temp = ArmKinematic.forward(step)[0, :]
            insert_arm_ik_trajectory = np.vstack((insert_arm_ik_trajectory, temp))
        insert_arm_ik_trajectory = insert_arm_ik_trajectory[1:]

        guid_arm_ik_trajectory = np.zeros((1, 3))
        length = 200
        for index, step in enumerate(insert_arm_ik_trajectory):
            guid_step_x = step[0] + length * np.cos(insert_arm_fk_trajectory[index, -1])
            guid_step_y = step[1] + length * np.sin(insert_arm_fk_trajectory[index, -1])
            guid_step_z = step[2] - 20
            guid_arm_ik_trajectory = np.vstack(
                (guid_arm_ik_trajectory, np.array([guid_step_x, guid_step_y, guid_step_z])))
        guid_arm_ik_trajectory = guid_arm_ik_trajectory[1:]

        orientation = np.zeros(guid_arm_ik_trajectory.shape) + np.array([0, -np.pi * 0.5, 0])
        trajectory_arm_2 = TrajectoryConvertor.format_positions_and_orientation(guid_arm_ik_trajectory, orientation, ArmKinematic.transform_matrix_arm_2)
        forward_kinematic_trajectory_arm_guid = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_2)
        forward_kinematic_trajectory_arm_guid[:, -1] += theta6  # Add theta6 shift

        steps_number = forward_kinematic_trajectory_arm_guid.shape[0]
        gripper_command_of_the_guid_arm = np.ones((steps_number, 1)) * Gripper.INSERT_STATE
        gripper_command_of_the_insert_arm = np.ones((steps_number, 1)) * Gripper.CAGE_STATE

        return insert_arm_fk_trajectory, forward_kinematic_trajectory_arm_guid, \
               gripper_command_of_the_insert_arm, gripper_command_of_the_guid_arm, jig

    @staticmethod
    def get_insert_gasket_fk_trajectory_as_matrix(flip_arms=False):
        forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2, theta_jig = \
            TrajectoryFactory.get_insert_gasket_fk_trajectory()

        gripper_command_of_the_guid_arm = np.ones((forward_kinematic_trajectory_arm_1.shape[0], 1)) * Gripper.INSERT_STATE
        gripper_command_of_the_insert_arm = np.ones((forward_kinematic_trajectory_arm_1.shape[0], 1)) * Gripper.CAGE_STATE
        if flip_arms:
            temp_matrix = np.concatenate((forward_kinematic_trajectory_arm_2, forward_kinematic_trajectory_arm_1,
                                          gripper_command_of_the_guid_arm, gripper_command_of_the_insert_arm), axis=1)
        else:
            temp_matrix = np.concatenate((forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2,
                                          gripper_command_of_the_insert_arm, gripper_command_of_the_guid_arm), axis=1)
        return np.concatenate((temp_matrix, theta_jig), axis=1)

    @staticmethod
    def get_LDO_trajectory():
        LDO = LDO_trajectpry()
        LDO.ldo_trajectory()
        trajectory_arm_1 = TrajectoryConvertor.format_positions_and_orientation(LDO.p_left, LDO.roll_pitch_yaw_left, ArmKinematic.transform_matrix_arm_1)
        trajectory_arm_2 = TrajectoryConvertor.format_positions_and_orientation(LDO.p_right, LDO.roll_pitch_yaw_right, ArmKinematic.transform_matrix_arm_2)
        forward_kinematic_trajectory_arm_1 = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_1)
        forward_kinematic_trajectory_arm_2 = TrajectoryConvertor.convert_trajectory_to_forward_kinematic(trajectory_arm_2)

        zeros = np.zeros((forward_kinematic_trajectory_arm_1.shape[0], 1))
        return np.concatenate((forward_kinematic_trajectory_arm_1, forward_kinematic_trajectory_arm_2, zeros, zeros, zeros), axis=1)

    @staticmethod
    def get_trajectory_from_record(filename):
        my_data = np.genfromtxt(filename, delimiter=',')
        return my_data

if __name__ == '__main__':
    TrajectoryFactory.get_initial_insert_gasket_fk_trajectory()
