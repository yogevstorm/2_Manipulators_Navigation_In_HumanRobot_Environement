#!/usr/bin/env python3
import numpy as np
import ground_control


if __name__ == '__main__':
    # LDO madgim
    #pos_matrix=TrajectoryFactory.get_LDO_trajectory()
    g_control = ground_control([[-1.57,0.05,0.05,0.05,0.05,0.05,-1.57,0.05,0.05,0.05,0.05,0.05,0,0,0],
[-1.57,0.05,0.05,0.05,0.05,0.05,-1.57,0.05,0.05,0.05,0.05,0.05,0,0,0]], resolution=0.01, with_jig=False, with_gripper=False)
    sleep(1)
    g_control.run()
