#!/usr/bin/env python3
import numpy as np
from numpy import sin, cos, pi


# https://emanual.robotis.com/docs/en/platform/manipulator_h/introduction/#introduction


class ArmKinematic:
    gripper_length = 178.61 + 50
    #gripper_LDO_length = 25 + 50
    gripper_LDO_length = 12 + 25

    # transform_matrix_arm_1 = np.array([[1, 0, 0, 0],
    #                                    [0, 1, 0, 0],
    #                                    [0, 0, 1, 0],
    #                                    [0, 0, 0, 1]])
    #
    # transform_matrix_arm_2 = np.array([[-1, 0, 0, 595],
    #                                    [0, -1, 0, 0],
    #                                    [0, 0, 1, 0],
    #                                    [0, 0, 0, 1]])

    # # for LDO madgim
    gripper_length = gripper_LDO_length  # for LDO madgim
    transform_matrix_arm_1 = np.array([[1, 0, 0, 300],
                                       [0, -1, 0, -300],
                                       [0, 0, -1, 900],
                                       [0, 0, 0, 1]])

    transform_matrix_arm_2 = np.array([[-1, 0, 0, 300],
                                       [0, 1, 0, 300],
                                       [0, 0, -1, 900],
                                       [0, 0, 0, 1]])

    @staticmethod
    def forward(t):
        l_f = [159, 234, 42.4264, 228, 123 + ArmKinematic.gripper_length, 0]
        points = np.array([[l_f[4] * (
                -1.0 * (sin(t[0]) * sin(t[3]) + sin(t[1] + t[2]) * cos(t[0]) * cos(t[3])) * sin(t[4]) + 1.0 * cos(
            t[0]) * cos(t[4]) * cos(t[1] + t[2])) + (
                                    1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * cos(t[0]),
                            l_f[4] * ((-1.0 * sin(t[0]) * sin(t[1] + t[2]) * cos(t[3]) + sin(t[3]) * cos(t[0])) * sin(
                                t[4]) + 1.0 * sin(t[0]) * cos(t[4]) * cos(t[1] + t[2])) + (
                                    1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * sin(t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                    -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(
                                t[1])) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * cos(t[1] + t[2] + pi / 4) - 1.0 *
                            l_f[
                                3] * sin(t[1] + t[2]) - 1.0 * l_f[4] * (
                                    sin(t[4]) * cos(t[3]) * cos(t[1] + t[2]) + sin(t[1] + t[2]) * cos(t[4]))],

                           [(1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * cos(t[0]),
                            (1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4) + 1.0 * l_f[3] * cos(t[1] + t[2])) * sin(t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                    -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(
                                t[1])) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * cos(t[1] + t[2] + pi / 4) - 1.0 *
                            l_f[
                                3] * sin(t[1] + t[2])],

                           [(1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + t[2] + pi / 4)) * cos(t[0]),
                            (1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + t[2] + pi / 4)) * sin(t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                    -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(
                                t[1])) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * cos(t[1] + t[2] + pi / 4)],

                           [(1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                               t[1] + pi / 4)) * cos(
                               t[0]),
                            (1.0 * l_f[1] * sin(t[1]) + 0.707106781186548 * (2 ** 0.5) * l_f[2] * sin(
                                t[1] + pi / 4)) * sin(
                                t[0]),
                            l_f[0] + l_f[1] * cos(t[1]) + l_f[2] * (
                                    -0.707106781186547 * sin(t[1]) + 0.707106781186548 * cos(t[1]))],

                           [l_f[1] * sin(t[1]) * cos(t[0]),
                            l_f[1] * sin(t[0]) * sin(t[1]),
                            l_f[0] + l_f[1] * cos(t[1])],

                           [0, 0, l_f[0]],

                           [0, 0, 0]])

        return points

    @staticmethod
    def inverse(pos, ori, i=0, t6=0, t1=0):
        fas = [1.4576, 1.3419]
        #l_i = [159, 265.6991, 259.7383, 123 + ArmKinematic.gripper_length]
        l_i = [159, 265.6991, 259.7383, 123]
        s = np.array(
            [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1]])

        R06 = np.array([[-sin(ori[1]), -sin(ori[2]) * cos(ori[1]), cos(ori[1]) * cos(ori[2]), 0],
                        [sin(ori[0]) * cos(ori[1]),
                         -sin(ori[0]) * sin(ori[1]) * sin(ori[2]) + cos(ori[0]) * cos(ori[2]),
                         sin(ori[0]) * sin(ori[1]) * cos(ori[2]) + sin(ori[2]) * cos(ori[0]), 0],
                        [-cos(ori[0]) * cos(ori[1]),
                         sin(ori[0]) * cos(ori[2]) + sin(ori[1]) * sin(ori[2]) * cos(ori[0]),
                         sin(ori[0]) * sin(ori[2]) - sin(ori[1]) * cos(ori[0]) * cos(ori[2]), 0], [0, 0, 0, 1]])

        pc = np.array([[pos[0] - (l_i[3]) * cos(ori[1]) * cos(ori[2])],
                       [pos[1] - (l_i[3]) * (
                               (sin(ori[0])) * sin(ori[1]) * cos(ori[2]) + sin(ori[2]) * cos(ori[0]))],
                       [pos[2] - (l_i[3]) * (
                               (sin(ori[0])) * sin(ori[2]) - sin(ori[1]) * cos(ori[0]) * cos(ori[2]))]])

        R06 = R06[:3, :3]
        gova = pc[2, 0] - l_i[0]
        yeter = s[i, 0] * (pc[0, 0] ** 2 + pc[1, 0] ** 2) ** 0.5
        D = ((yeter ** 2 + gova ** 2 - l_i[1] ** 2 - l_i[2] ** 2) / (2 * l_i[1] * l_i[2]))

        if pc[0, 0] == 0 and pc[1, 0] == 0:
            t1 = t1
        else:
            t1 = np.arctan2(pc[1, 0] / (yeter), pc[0, 0] / (yeter))

        if D > 1:
            raise ArmCannotReachPosition('Arm cannot reach position')
        t3 = np.arctan2(s[i, 1] * (1 - D ** 2) ** 0.5, D)
        t2 = -(np.arctan2(gova, yeter) - np.arctan2(l_i[2] * sin(-t3), l_i[1] + l_i[2] * cos(-t3)))
        t3 = t3 - fas[1]
        t2 = t2 + fas[0]

        R03 = np.array([[-sin(t2 + t3) * cos(t1), -sin(t1), cos(t1) * cos(t2 + t3)],
                        [-sin(t1) * sin(t2 + t3), cos(t1), sin(t1) * cos(t2 + t3)],
                        [-cos(t2 + t3), 0, -sin(t2 + t3)]])

        # http://aranne5.bgu.ac.il/Free_publications/mavo-lerobotica.pdf
        R36 = np.dot(R03.T, R06)

        st5 = -s[i, 2] * (R36[0, 2] ** 2 + R36[1, 2] ** 2) ** 0.5
        if abs(st5) < 1e-4:
            t5 = 0
            t6 = t6
            t4 = np.arctan2(R36[1, 0], R36[0, 0]) + t6
        else:
            t5 = np.arctan2(st5, R36[2, 2])
            t4 = np.arctan2(R36[1, 2] / st5, R36[0, 2] / st5)
            t6 = np.arctan2(R36[2, 1] / st5, -R36[2, 0] / st5)

        theta_values = np.array([[t1, t2, t3, t4, t5, t6]])
        if np.isnan(np.sum(theta_values)):
            raise ArmCannotReachPosition('Arm cannot reach position')
        return theta_values

    @staticmethod
    def transform_points(points, transform_matrix):
        #  transform_matrix = | 0R1 : d1|
        #                     |0 0 0 : 1| (4x4)
        #  Format points matrix to allow matrix product with the transform matrix.
        #  temp_point_matrix = |V1   V2 .. Vn|
        #                      |1    1  .. 1 | (4xn)
        points_t = points.transpose()
        #  Add row of ones in the end of the matrix.
        temp_point_matrix = np.concatenate((points_t, np.ones([1, points_t.shape[1]])))
        result_matrix = np.matmul(transform_matrix, temp_point_matrix)
        return result_matrix[0:-1, :].transpose()

    @staticmethod
    def transform_points_world_to_arm(points, transform_matrix):
        return ArmKinematic.transform_points(points, transform_matrix)

    @staticmethod
    def transform_points_arm_to_world(points, transform_matrix):
        return ArmKinematic.transform_points(points, np.linalg.inv(transform_matrix))

    @staticmethod
    def is_motors_angles_in_range(motors_angles):
        max_angles_range = np.array([np.pi, np.pi * 0.5, np.pi * 0.75, np.pi, np.pi * 0.5, np.pi])
        min_angles_range = np.array([-np.pi, -np.pi * 0.5, -np.pi * 0.5, -np.pi, -np.pi * 0.5, -np.pi])
        is_motors_angle_lower_than_max = max_angles_range >= motors_angles
        is_motors_angle_bigger_than_min = motors_angles >= min_angles_range
        return is_motors_angle_lower_than_max & is_motors_angle_bigger_than_min

    @staticmethod
    def get_initial_arm_position(arm_1=True):
        return ArmKinematic.transform_points_arm_to_world(ArmKinematic.forward(np.zeros([6, 1])),
                                                          ArmKinematic.transform_matrix_arm_1)


class ArmCannotReachPosition(Exception):
    """Raised when the arm cannot reach the position target"""
    pass
