#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import heapq
from visualization_msgs.msg import MarkerArray
import time
#from random import random
from collections import deque
from matplotlib import collections  as mc
import random
import os
import sys
import math
import copy
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import env, plotting, utils
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from std_srvs.srv import Empty


global joint_state_data

global occupied_cells

global x,start_button

joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)
x,start_button=0,0

class Node:
    def __init__(self, n):
        self.pos = n
        self.parent = None
        self.flag = "VALID"


class Edge:
    def __init__(self, n_p, n_c):
        self.parent = n_p
        self.child = n_c
        self.flag = "VALID"


class DynamicRrt:
    def __init__(self, s_start, s_goal, step_len, goal_sample_rate, waypoint_sample_rate, iter_max,obstacles_array):
        self.s_start = Node(s_start)
        self.s_goal = Node(s_goal)
        self.step_len = step_len
        self.goal_sample_rate = goal_sample_rate
        self.waypoint_sample_rate = waypoint_sample_rate
        self.iter_max = iter_max
        self.vertex = [self.s_start]
        self.vertex_old = []
        self.vertex_new = []
        self.edges = []

        self.env = env.Env()
        self.plotting = plotting.Plotting(s_start, s_goal)
        self.utils = utils.Utils()
        self.fig, self.ax = plt.subplots()

        #self.x_range = self.env.x_range
        #self.y_range = self.env.y_range
        self.range_1 = (-3.14,3.14)
        self.range_2 = (-1.57,1.57)
        self.range_3 = (-1.57,1.57)
        self.range_4 = (-1.57,1.57)
        self.range_5 = (-1.57,1.57)
        self.obs_circle = self.env.obs_circle
        self.obs_rectangle = self.env.obs_rectangle
        self.obs_boundary = self.env.obs_boundary
        self.obs_add = [0, 0, 0]

        self.path = []
        self.waypoint = []
        self.collision_dist=0.13
        self.obstacles_array=obstacles_array

    def planning(self):
        for i in range(self.iter_max):
            node_rand = self.generate_random_node(self.goal_sample_rate)
            node_near = self.nearest_neighbor(self.vertex, node_rand)
            node_new = self.new_state(node_near, node_rand)

            

            if node_new and not self.is_collision(node_new,self.obstacles_array):
                self.vertex.append(node_new)
                self.edges.append(Edge(node_near, node_new))
                dist, _ = self.get_distance_and_direction(node_new, self.s_goal)

                if dist <= self.step_len:
                    self.new_state(node_new, self.s_goal)

                    

                    path = self.extract_path(node_new)
                    #self.plot_grid("Dynamic_RRT")
                    #self.plot_visited()
                    #self.plot_path(path)
                    self.path = path
                    self.waypoint = self.extract_waypoint(node_new)
                    #plt.show()
                    print('finished')

                    return path

        return None

    

    def InvalidateNodes(self):
        for edge in self.edges:
            if self.is_collision(edge.parent, self.obstacles_array):
                edge.child.flag = "INVALID"

    
    def is_collision(self,node,obstacles_array):
        joint1_point=forward_kinematics(1,[node.pos[0],node.pos[1]])
        joint2_point=forward_kinematics(2,[node.pos[0],node.pos[1],node.pos[2]])
        joint3_point=forward_kinematics(3,[node.pos[0],node.pos[1],node.pos[2],node.pos[3]])
        joint4_point=forward_kinematics(4,[node.pos[0],node.pos[1],node.pos[2],node.pos[3],node.pos[4]])
        joint_points_array=[joint1_point,joint2_point,joint3_point,joint4_point]
        for joint_point in joint_points_array:
            for obs in obstacles_array:
                obs_point=[obs.x,obs.y,obs.z]
                if(distance_between_2_points(obs_point,joint_point)<self.collision_dist):
                    return True
        return False
            


    def is_path_invalid(self):
        for node in self.waypoint:
            if node.flag == "INVALID":
                return True

        return False

    def replanning(self):
        global occupied_cells,joint_state_data
        self.TrimRRT()
        i=0
        while i<self.iter_max:
        #for i in range(self.iter_max):
            node_rand = self.generate_random_node_replanning(self.goal_sample_rate, self.waypoint_sample_rate)
            #node_rand = self.generate_random_node2()
            node_near = self.nearest_neighbor(self.vertex, node_rand)
            node_new = self.new_state(node_near, node_rand)

            if(i==self.iter_max/5):
                rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
                clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
                clear_octomap()
                self.obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
                print(i)
                #self.replanning()
                i=0

            if node_new and not self.is_collision(node_new,self.obstacles_array):
                self.vertex.append(node_new)
                self.vertex_new.append(node_new)
                self.edges.append(Edge(node_near, node_new))
                dist, _ = self.get_distance_and_direction(node_new, self.s_goal)

                if dist <= self.step_len:
                    self.new_state(node_new, self.s_goal)
                    path = self.extract_path(node_new)
                    waypoint = self.extract_waypoint(node_new)
                    print("path: ", len(path))
                    print("waypoint: ", len(waypoint))

                    return path, waypoint

            i+=1

        return None

    def TrimRRT(self):
        for i in range(1, len(self.vertex)):
            node = self.vertex[i]
            node_p = node.parent
            if node_p.flag == "INVALID":
                node.flag = "INVALID"

        self.vertex = [node for node in self.vertex if node.flag == "VALID"]
        self.vertex_old = copy.deepcopy(self.vertex)
        self.edges = [Edge(node.parent, node) for node in self.vertex[1:len(self.vertex)]]

    def generate_random_node(self, goal_sample_rate):
        #delta = self.utils.delta
        delta=0.1

        if np.random.random() > goal_sample_rate:
            return Node((np.random.uniform(self.range_1[0] + delta, self.range_1[1] - delta),
                         np.random.uniform(self.range_2[0] + delta, self.range_2[1] - delta),
                         np.random.uniform(self.range_3[0] + delta, self.range_3[1] - delta),
                         np.random.uniform(self.range_4[0] + delta, self.range_4[1] - delta),
                         np.random.uniform(self.range_5[0] + delta, self.range_5[1] - delta)))

        return self.s_goal


    def generate_random_node2(self):
        rx=(random.randint(-314, 314)/100.0)
        ry=(random.randint(-157, 157)/100.0)
      
        return Node((rx,ry))

    def generate_random_node_replanning(self, goal_sample_rate, waypoint_sample_rate):
        #delta = self.utils.delta
        delta=0.1
        p = np.random.random()
        if p < goal_sample_rate:
            return self.s_goal
        elif goal_sample_rate < p < goal_sample_rate + waypoint_sample_rate:
            return self.waypoint[np.random.randint(0, len(self.waypoint) - 1)]
        else:
            return Node((np.random.uniform(self.range_1[0] + delta, self.range_1[1] - delta),
                         np.random.uniform(self.range_2[0] + delta, self.range_2[1] - delta),
                         np.random.uniform(self.range_3[0] + delta, self.range_3[1] - delta),
                         np.random.uniform(self.range_4[0] + delta, self.range_4[1] - delta),
                         np.random.uniform(self.range_5[0] + delta, self.range_5[1] - delta)))

    @staticmethod
    def nearest_neighbor(node_list, n):
        #return node_list[int(np.argmin([math.hypot(nd.pos[0] - n.pos[0], nd.pos[1] - n.pos[1] ,nd.pos[2] - n.pos[2])
                                        #for nd in node_list]))]
        return node_list[int(np.argmin([np.linalg.norm(np.array(nd.pos) - np.array(n.pos))
                                        for nd in node_list]))]

    def new_state(self, node_start, node_end):

        #print(node_start.pos)

        dist, direction = self.get_distance_and_direction(node_start, node_end)

        dist = min(self.step_len, dist)
        node_new = Node(node_start.pos+dist*direction)
        node_new.parent = node_start

        return node_new

    def extract_path(self, node_end):
        path = [(self.s_goal.pos[0], self.s_goal.pos[1] , self.s_goal.pos[2],self.s_goal.pos[3],self.s_goal.pos[4])]
        node_now = node_end

        while node_now.parent is not None:
            node_now = node_now.parent
            path.append((node_now.pos[0], node_now.pos[1] , node_now.pos[2],node_now.pos[3],node_now.pos[4]))

        return path

    def extract_waypoint(self, node_end):
        waypoint = [self.s_goal]
        node_now = node_end

        while node_now.parent is not None:
            node_now = node_now.parent
            waypoint.append(node_now)

        return waypoint

    @staticmethod
    def get_distance_and_direction(node_start, node_end):
        direction=np.array(node_end.pos) - np.array(node_start.pos)
        dist = np.linalg.norm(direction)
        if(dist==0):
            pass

        else:

            direction=direction/dist

        return dist,direction

    

    def plot_grid(self, name):

        
        plt.plot(self.s_start.pos[0], self.s_start.pos[1], "bs", linewidth=3)
        plt.plot(self.s_goal.pos[0], self.s_goal.pos[1], "gs", linewidth=3)

        plt.title(name)
        plt.axis("equal")

    def plot_visited(self, animation=True):
        if animation:
            count = 0
            for node in self.vertex:
                count += 1
                if node.parent:
                    plt.plot([node.parent.pos[0], node.pos[0]], [node.parent.pos[1], node.pos[1]], "-g")
                    plt.gcf().canvas.mpl_connect('key_release_event',
                                                 lambda event:
                                                 [exit(0) if event.key == 'escape' else None])
                    if count % 10 == 0:
                        #plt.pause(0.001)
                        plt.pause(0.01)
        else:
            for node in self.vertex:
                if node.parent:
                    plt.plot([node.parent.x, node.x], [node.parent.y, node.y], "-g")

    def plot_vertex_old(self):
        for node in self.vertex_old:
            if node.parent:
                plt.plot([node.parent.x, node.x], [node.parent.y, node.y], "-g")

    def plot_vertex_new(self):
        count = 0

        for node in self.vertex_new:
            count += 1
            if node.parent:
                plt.plot([node.parent.x, node.x], [node.parent.y, node.y], color='darkorange')
                #plt.gcf().canvas.mpl_connect('key_release_event',
                                            # lambda event:
                                            # [exit(0) if event.key == 'escape' else None])
                #if count % 10 == 0:
                    #plt.pause(0.001)

    @staticmethod
    def plot_path(path, color='red'):
        plt.plot([x[0] for x in path], [x[1] for x in path], linewidth=2, color=color)
        plt.pause(0.01)

def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)


def distance_between_2_points(a, b):

        return np.linalg.norm(np.array(a) - np.array(b))




def joy_data(data):
    global x,start_button
    x=data.buttons[1]
    start_button=data.buttons[9]
    back=data.buttons[6]


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)



    

        



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


def create_obstacles_array_dynamic(occupied_cells,joint_state_data):
    global pub_obstacles
    obstacles=MarkerArray()
    obstacles_array=[]
    j_pos=joint_state_data.position
    joint0_point=forward_kinematics(0,[j_pos[0]])
    joint1_point=forward_kinematics(1,[j_pos[0],j_pos[1]])
    joint01_point=((joint0_point[0]+joint1_point[0])/2,(joint0_point[1]+joint1_point[1])/2,(joint0_point[2]+joint1_point[2])/2)
    joint2_point=forward_kinematics(2,[j_pos[0],j_pos[1],j_pos[2]])
    joint3_point=forward_kinematics(3,[j_pos[0],j_pos[1],j_pos[2],j_pos[3]])
    joint4_point=forward_kinematics(4,[j_pos[0],j_pos[1],j_pos[2],j_pos[3],j_pos[4]])
    joint_points_array=[joint0_point,joint01_point,joint1_point,joint2_point,joint3_point,joint4_point]
    id=0
    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            point_tuple=(point.x,point.y,point.z)
            dis_obstacle_from_manipulator=distance_between_2_points(joint0_point,point_tuple)
            skip=False
            if(point.z>0.025):
                for joint_point in joint_points_array:
                    dis_obstacle_from_manipulator=distance_between_2_points(joint_point,point_tuple)
                    if(dis_obstacle_from_manipulator<0.15):
                        skip=True
                        break
                        
                if(skip):
                    continue
                obstacle=create_obstacle_marker(point,id)
                obstacles.markers.append(obstacle)
                obstacles_array.append(point)
                id+=1
          
    pub_obstacles.publish(obstacles)
    return obstacles_array




def create_obstacle_marker(position,i):
    obstacle=Marker()
    obstacle.header.stamp=rospy.Time.now()
    obstacle.header.frame_id='world'
    obstacle.ns='obstacles'
    obstacle.id=i
    obstacle.type=1
    obstacle.pose.position=position
    obstacle.scale.x , obstacle.scale.y , obstacle.scale.z = 0.1 ,0.1 ,0.1
    obstacle.color.r , obstacle.color.a = 1,0.9

    return obstacle





def navigation(start_pose,goal_pose,set_joints_msg,pub_set_joints):
    global occupied_cells,joint_state_data
    print " start navigating"
    rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
    clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
    clear_octomap()
    #DynamicRrt(s_start, s_goal, step_len, goal_sample_rate, waypoint_sample_rate, iter_max,obstacles_array)
    obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
    #obstacles_array=create_obstacles_array(occupied_cells)
    drrt = DynamicRrt(start_pose, goal_pose, 0.2, 0.2, 0.2, 5000,obstacles_array)
    path=drrt.planning()
    #print(goal_pose)
    path_len=len(path)


    i=0
    while i<path_len:
        pose=path[len(path)-i-1]
        #print(pose)
        joints_state_array=[pose[0],pose[1],pose[2],pose[3],pose[4],0]
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(0.2)
        rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
        clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
        clear_octomap()
        obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
        #obstacles_array=create_obstacles_array(occupied_cells)
        drrt.obstacles_array=obstacles_array
        drrt.InvalidateNodes()
        #print(path_len,' ',i)

        if drrt.is_path_invalid():        
            print("Path is Replanning ...")
            #drrt.s_start.parent=Node(pose)
            drrt.s_start=Node(pose)
            path, waypoint = drrt.replanning()
            path_len=len(path)
            print('')
            i=0
            plt.cla()
            #drrt.plot_grid("Dynamic_RRT")
            #drrt.plot_visited(animation=True)
            #drrt.plot_vertex_old()
            #drrt.plot_path(drrt.path, color='blue')
            #drrt.plot_vertex_new()
            drrt.vertex_new = []
            #drrt.plot_path(path)
            drrt.path = path
            drrt.waypoint = waypoint

        i+=1

    





def main():
    global x,start_button
    global joint_state_data
    global occupied_cells
    global pub_obstacles

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    pub_obstacles = rospy.Publisher('visualize_obstacles',MarkerArray, queue_size=1)
    rate = rospy.Rate(10) # 10hz


    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        #obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)

        #print(len(obstacles_array))

        if(x==1):
            set_mode(pub_set_mode)

        if(start_button==1):
            print('start')
            
            start=(j_pos[0],j_pos[1],j_pos[2],j_pos[3],j_pos[4])
            
            #start=(-1,-0.5)
            #obstacles_array=create_obstacles_array(occupied_cells)
            #print(len(obstacles_array))

            #obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
            #print(len(obstacles_array))

            navigation(start,(3,1.5,-1.5,1,1),set_joints_msg,pub_set_joints)


        rate.sleep()




if __name__ == '__main__':
    try:
       main()
    except rospy.ROSInterruptException:
        pass