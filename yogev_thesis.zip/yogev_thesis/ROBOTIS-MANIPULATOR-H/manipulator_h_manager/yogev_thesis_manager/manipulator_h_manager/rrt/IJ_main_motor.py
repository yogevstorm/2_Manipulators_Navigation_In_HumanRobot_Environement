#!/usr/bin/env python3

import rospy  # Import the Python library for ROS
from time import time, sleep
from dynamixel_workbench_msgs.srv import DynamixelCommand, DynamixelCommandRequest
from sensor_msgs.msg import JointState
import numpy as np
import math


class IJ_main_motor():

    def __init__(self):
        # rospy.init_node('ROS_jig', anonymous=True)
        self.rate = rospy.Rate(100)
        rospy.wait_for_service('/dynamixel_workbench/dynamixel_command')
        self.vel_cmd = DynamixelCommandRequest()
        self.vel_cmd.id = 1
        self.vel_cmd.addr_name = "Goal_Position"
        # self.vel_cmd.value
        self.move = rospy.ServiceProxy('/dynamixel_workbench/dynamixel_command', DynamixelCommand)
        # self.ang2tic = 4096 / 360  # for MX106
        self.rad2tic = 502834 / (2 * math.pi)
        self.curr_pos = 0

    def move_IJ(self, i):
        self.vel_cmd.value = int(i * self.rad2tic)
        self.move(self.vel_cmd)
        # print('y ' + str(int(i / self.ang2tic)))
        # print('cmd_vel_value: ' + self.curr_pos.__str__() + '   sent value: ' + self.vel_cmd.value.__str__())

    def read_pos(self):
        rospy.Subscriber("dynamixel_workbench/joint_states", JointState, self.callback)

    def callback(self, data):
        # self.curr_pos = (data.position[0]/0.001281056767921)+math.pi/0.001281056767921
        # self.curr_pos = (data.position[0] * 180 / math.pi + math.pi) + 180
        self.curr_pos = data.position[0]  # + math.pi
        # print(self.vel_cmd.value.__str__(),end="\n")
        # pos =self.curr_pos
        # value =self.vel_cmd.value/self.ang2tic
        # print("current position: " + pos.__str__() + 'cmd_vel_value: ' + (value).__str__()+ " error: " +(value - pos).__str__())
        # self.rate.sleep()


if __name__ == '__main__':
    jig = IJ_main_motor()

    # for i in np.arange(0.00000000001, math.pi, 0.01):
    i = math.pi/2
    jig.move_IJ(i)
    jig.read_pos()
    sleep(1)
    print(jig.curr_pos)

