#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import heapq
from visualization_msgs.msg import MarkerArray
import time
#from random import random
from collections import deque
from matplotlib import collections  as mc
import random
import os
import sys
import math
import copy
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import env, plotting, utils
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from std_srvs.srv import Empty


global joint_state_data

global occupied_cells

global x,start_button

joint_state_data=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)
x,start_button=0,0

class Node:
    def __init__(self, n):
        self.x = n[0]
        self.y = n[1]
        self.parent = None
        self.flag = "VALID"


class Edge:
    def __init__(self, n_p, n_c):
        self.parent = n_p
        self.child = n_c
        self.flag = "VALID"


class DynamicRrt:
    def __init__(self, s_start, s_goal, step_size, GoalProb, WayPointProb, maxiter,obstacles_array):
    
        self.x0, self.xt = tuple(s_start), tuple(s_goal)
        self.qrobot = self.x0
        self.current = tuple(s_start)
        self.stepsize = step_size
        self.maxiter = maxiter
        self.GoalProb = 0.05  # probability biased to the goal
        self.WayPointProb = 0.02  # probability falls back on to the way points
        self.done = False
        self.invalid = False
        self.V = []  # vertices
        self.Parent = {}  # parent child relation
        self.Edge = set()  # edge relation (node, parent node) tuple
        self.Path = []
        self.flag = {}  # flag dictionary
        self.ind = 0
        self.i = 0
        self.env = env.Env()
        self.plotting = plotting.Plotting(s_start, s_goal)
        self.utils = utils.Utils()
        self.fig, self.ax = plt.subplots()

        #self.x_range = self.env.x_range
        #self.y_range = self.env.y_range
        self.x_range = (-3.14,3.14)
        self.y_range = (-1.57,1.57)
      
        self.collision_dist=0.13
        self.obstacles_array=obstacles_array





    def initRRT(self):
        self.V.append(self.x0)
        self.flag[self.x0] = 'Valid'




    def GrowRRT(self):
        print('growing...')
        qnew = self.x0
        distance_threshold = self.stepsize
        self.ind = 0
        while self.ind <= self.maxiter:
            qtarget = self.ChooseTarget()
            qnearest = self.Nearest(qtarget)
            qnew = self.Extend(qnearest, qtarget)
            if (qnew!=qnearest) and not self.is_collision(qnew,self.obstacles_array):
                self.AddNode(qnearest, qnew)
                dist, _ = self.get_distance_and_angle(qnew, self.xt)
                if dist < distance_threshold:
                    self.AddNode(qnearest, self.xt)
                    self.flag[self.xt] = 'Valid'
                    break
                self.i += 1
            self.ind += 1
            # self.visualization()

    
    def ChooseTarget(self):
        # return the goal, or randomly choose a state in the waypoints based on probs
        p = np.random.uniform()
        if len(self.V) == 1:
            i = 0
        else:
            i = np.random.randint(0, high=len(self.V) - 1)
        if 0 < p < self.GoalProb:
            return self.xt
        elif self.GoalProb < p < self.GoalProb + self.WayPointProb:
            return self.V[i]
        elif self.GoalProb + self.WayPointProb < p < 1:
            return tuple(self.generate_random_node())

    def generate_random_node(self):
        rx=(random.randint(-314, 314)/100.0)
        ry=(random.randint(-157, 157)/100.0)
      
        return (rx,ry)


    def Nearest(self,n):
        node_list=self.V
        return node_list[int(np.argmin([math.hypot(nd[0] - n[0], nd[1] - n[1])
                                        for nd in node_list]))]

   


    
    def Extend(self, node_start, node_end):
        dist, theta = self.get_distance_and_angle(node_start, node_end)

        dist = min(self.stepsize, dist)
        node_new = (node_start[0] + dist * math.cos(theta),
                         node_start[1] + dist * math.sin(theta))

        return node_new



    def is_collision(self,node,obstacles_array):
        joint1_point=forward_kinematics(1,[node[0],node[1]])
        for obs in obstacles_array:
            obs_point=[obs.x,obs.y,obs.z]
            if(distance_between_2_points(obs_point,joint1_point)<self.collision_dist):
                return True
        return False


    def AddNode(self, nearest, extended):
        self.V.append(extended)
        self.Parent[extended] = nearest
        self.Edge.add((extended, nearest))
        self.flag[extended] = 'Valid'



    def get_distance_and_angle(self,node_start, node_end):
        dx = node_end[0] - node_start[0]
        dy = node_end[1] - node_start[1]
        return math.hypot(dx, dy), math.atan2(dy, dx)



    def extract_path(self):
        path = [(self.xt[0], self.xt[1])]
        x = self.xt
        i=0
        while x != self.x0:
            x2 = self.Parent[x]
            x = x2
            path.append((x[0], x[1]))
            
            if i > self.maxiter:
                print('Path is not found')
                return 
            i+= 1

        return path



    def plot_grid(self, name):

        
        plt.plot(self.x0[0], self.x0[1], "bs", linewidth=3)
        plt.plot(self.xt[0], self.xt[1], "gs", linewidth=3)

        plt.title(name)
        plt.axis("equal")

    def plot_visited(self, animation=True):
        if animation:
            count = 0
            for node in self.V:
                count += 1
                if(node!=self.x0):
                    
                #if self.Parent[node]:
                    plt.plot([self.Parent[node][0], node[0]], [self.Parent[node][1], node[1]], "-g")
                    #plt.gcf().canvas.mpl_connect('key_release_event',
                                        #        lambda event:
                                                # [exit(0) if event.key == 'escape' else None])
                    if count % 10 == 0:
                        plt.pause(0.001)
                        #plt.pause(0.5)
        else:
            for node in self.V:
                if self.Parent[node]:
                    plt.plot([self.Parent[node][0], node[0]], [self.Parent[node][1], node[1]], "-g")

    def plot_vertex_old(self):
        for node in self.vertex_old:
            if node.parent:
                plt.plot([node.parent.x, node.x], [node.parent.y, node.y], "-g")

    def plot_path(path, color='red'):
        plt.plot([x[0] for x in path], [x[1] for x in path], linewidth=2, color=color)
        plt.pause(0.01)


    def plot_vertex_new(self):
        count = 0

        for node in self.vertex_new:
            count += 1
            if node.parent:
                plt.plot([node.parent.x, node.x], [node.parent.y, node.y], color='darkorange')
                #plt.gcf().canvas.mpl_connect('key_release_event',
                                            # lambda event:
                                            # [exit(0) if event.key == 'escape' else None])
                #if count % 10 == 0:
                    #plt.pause(0.001)

    @staticmethod
    def plot_path(path, color='red'):
        plt.plot([x[0] for x in path], [x[1] for x in path], linewidth=2, color=color)
        plt.pause(0.01)

def from_transition_matrix_to_pose(T):
    return (T[0][3],T[1][3],T[2][3])



def forward_kinematics(joint_ID,joints_state_array):
    #global joint_state_data
    #global start_button
    start_button=0
    #j_pos=joint_state_data.position
    j_pos=joints_state_array
    d1=0.159
    a1=0.2659
    a2=0.03
    a3=0.134
    d3=0.258
    joint2_offset=-1.57+0.113
    joint3_offset=-0.113
    joint4_offset=1.57

    T_01=[[math.cos(j_pos[0]),0,-math.sin(j_pos[0]),0],[math.sin(j_pos[0]),0,math.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]]
    

    if(joint_ID==0):
        return from_transition_matrix_to_pose(T_01)

    T_12=[[math.cos(j_pos[1]+joint2_offset),-math.sin(j_pos[1]+joint2_offset),0,a1*math.cos(j_pos[1]+joint2_offset)],[math.sin(j_pos[1]+joint2_offset),math.cos(j_pos[1]+joint2_offset),0,a1*math.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]]
    
    if(joint_ID==1):

        T_02=np.linalg.multi_dot([T_01,T_12])
        return from_transition_matrix_to_pose(T_02)

    T_23=[[math.cos(j_pos[2]+joint3_offset),0,-math.sin(j_pos[2]+joint3_offset),a2*math.cos(j_pos[2]+joint3_offset)],[math.sin(j_pos[2]+joint3_offset),0,math.cos(j_pos[2]+joint3_offset),a2*math.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

    if(joint_ID==2):

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
        return from_transition_matrix_to_pose(T_03)

    T_34=[[math.cos(j_pos[3]),0,math.sin(j_pos[3]),0],[math.sin(j_pos[3]),0,-math.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

    if(joint_ID==3):

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        return from_transition_matrix_to_pose(T_04)

    T_45=[[math.cos(j_pos[4]+joint4_offset),0,-math.sin(j_pos[4]+joint4_offset),a3*math.cos(j_pos[4]+joint4_offset)],[math.sin(j_pos[4]+joint4_offset),0,math.cos(j_pos[4]+joint4_offset),a3*math.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
    if(joint_ID==4):

        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
        return from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def distance_between_2_poses(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)


def distance_between_2_points(a, b):

        return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)




def joy_data(data):
    global x,start_button
    x=data.buttons[1]
    start_button=data.buttons[9]
    back=data.buttons[6]


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print "set_mode"


def set_joints_state(set_joints_msg,joints_state_array,pub_set_joints):
    set_joints_msg.value=joints_state_array
    pub_set_joints.publish(set_joints_msg)



    

        



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


def create_obstacles_array_dynamic(occupied_cells,joint_state_data):
    global pub_obstacles
    obstacles=MarkerArray()
    obstacles_array=[]
    j_pos=joint_state_data.position
    joint0_point=forward_kinematics(0,[j_pos[0]])
    joint1_point=forward_kinematics(1,[j_pos[0],j_pos[1]])
    joint01_point=((joint0_point[0]+joint1_point[0])/2,(joint0_point[1]+joint1_point[1])/2,(joint0_point[2]+joint1_point[2])/2)
    joint_points_array=[joint0_point,joint01_point,joint1_point]
    id=0
    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            point_tuple=(point.x,point.y,point.z)
            dis_obstacle_from_manipulator=distance_between_2_points(joint0_point,point_tuple)
            skip=False
            if(point.z>0.025):
                for joint_point in joint_points_array:
                    dis_obstacle_from_manipulator=distance_between_2_points(joint_point,point_tuple)
                    if(dis_obstacle_from_manipulator<0.15):
                        skip=True
                        break
                        
                if(skip):
                    continue
                obstacle=create_obstacle_marker(point,id)
                obstacles.markers.append(obstacle)
                obstacles_array.append(point)
                id+=1
          
    pub_obstacles.publish(obstacles)
    return obstacles_array


def visualization(drrt,path):
    drrt.plot_grid("Dynamic_RRT")
    drrt.plot_visited()
    drrt.plot_path(path)
    drrt.path = path
    plt.show()


def create_obstacle_marker(position,i):
    obstacle=Marker()
    obstacle.header.stamp=rospy.Time.now()
    obstacle.header.frame_id='world'
    obstacle.ns='obstacles'
    obstacle.id=i
    obstacle.type=1
    obstacle.pose.position=position
    obstacle.scale.x , obstacle.scale.y , obstacle.scale.z = 0.1 ,0.1 ,0.1
    obstacle.color.r , obstacle.color.a = 1,0.9

    return obstacle





def navigation(start_pose,goal_pose,set_joints_msg,pub_set_joints):
    global occupied_cells,joint_state_data
    print " start navigating"
    rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
    clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
    clear_octomap()
    obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
    #( s_start, s_goal, step_size, GoalProb, WayPointProb, maxiter,obstacles_array)
    drrt=DynamicRrt(start_pose,goal_pose,0.2,0.01,0.01,10000,obstacles_array)
    # qstart = qgoal
    drrt.x0 = tuple(goal_pose)
    # qgoal = qrobot
    drrt.xt = tuple(start_pose)
    drrt.initRRT()
    drrt.GrowRRT()
    drrt.done = True
    path=drrt.extract_path()
    drrt.path=path
    visualization(drrt,path)

    path_len=len(path)
    #i=0
    #while i<path_len:
    for pose in path:
        #pose=path[len(path)-i-1]
        print(pose)
        joints_state_array=[pose[0],pose[1],-1.55,0,0,0]
        set_joints_state(set_joints_msg,joints_state_array,pub_set_joints)
        time.sleep(0.5)
        rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
        clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
        clear_octomap()
        obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
        #obstacles_array=create_obstacles_array(occupied_cells)


    





def main():
    global x,start_button
    global joint_state_data
    global occupied_cells
    global pub_obstacles

    

    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    pub_obstacles = rospy.Publisher('visualize_obstacles',MarkerArray, queue_size=1)
    rate = rospy.Rate(10) # 10hz


    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        set_joints_msg=JointPose()

        set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        #obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)

        #print(len(obstacles_array))

        if(x==1):
            set_mode(pub_set_mode)

        if(start_button==1):
            print('start')
            
            start=(j_pos[0],j_pos[1])
            
            #start=(-1,-0.5)
            #obstacles_array=create_obstacles_array(occupied_cells)
            #print(len(obstacles_array))

            #obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data)
            #print(len(obstacles_array))

            navigation(start,(3,1.5),set_joints_msg,pub_set_joints)


        rate.sleep()




if __name__ == '__main__':
    try:
       main()
    except rospy.ROSInterruptException:
        pass