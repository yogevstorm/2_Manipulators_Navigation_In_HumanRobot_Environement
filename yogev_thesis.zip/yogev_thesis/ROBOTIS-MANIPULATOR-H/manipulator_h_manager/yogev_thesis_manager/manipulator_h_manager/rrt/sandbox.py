import numpy as np
from numpy import cos, sin
center = np.array([0.227185, -0.889608, 0.155151])*1000
point_short = np.array([0.356143, -0.889378, 0.144725])*1000
point_long = np.array([0.246724, -0.893739, 0.436731])*1000

v_x = point_long - center
v_y = point_short - center

print(v_x)
print(v_y)
print(np.dot(v_x, v_y))

theta_x = np.arctan2(v_x[0], v_x[2])
theta_y = np.arctan2(v_y[0], v_y[2])

print(np.round(np.rad2deg(theta_x), 2))
print(np.round(np.rad2deg(theta_y - np.pi*0.5), 2))
print(np.rad2deg((theta_x + theta_y - np.pi*0.5)*0.5))
print(np.round(np.rad2deg(theta_y - theta_x), 2))

theta_z = np.deg2rad(4.3)
transform_world_to_optitrack = np.array([[cos(theta_z), -sin(theta_z), 0, 287.89],
                                         [sin(theta_z), cos(theta_z), 0, 304.05],
                                         [0, 0, 1, -914.87],
                                         [0, 0, 0, 1]])

v_center = np.array([[287.89, 304.05, -914.87, 1]]).T
print(np.dot(np.linalg.inv(transform_world_to_optitrack), v_center))
