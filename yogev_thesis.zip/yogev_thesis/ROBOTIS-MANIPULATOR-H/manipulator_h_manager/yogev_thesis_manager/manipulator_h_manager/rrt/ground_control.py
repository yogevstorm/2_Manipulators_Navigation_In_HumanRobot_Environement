#!/usr/bin/env python3
import math
from arms_control import ROS_god, kinmatics
from time import time, sleep
from IJ_main_motor import IJ_main_motor
import numpy as np
from trajectory_factory import TrajectoryFactory
from scipy.spatial import distance
from gripper import Gripper
from arm_kinematic import ArmKinematic
from csv import writer
from datetime import datetime

def max_delta_angles_error(wanted, existent):
    return np.max(abs(np.array(wanted) - np.array(existent)))


def max_delta_tool_error(wanted, existent):
    wanted_tool = np.append(kinmatics.forward(wanted)[0], wanted[-1])
    existent_tool = np.append(kinmatics.forward(existent)[0], existent[-1])
    return np.max(abs(np.array(wanted_tool) - np.array(existent_tool)))


def euclidean_dist_delta_angles_error(wanted, existent):
    return distance.euclidean(wanted, existent)


def euclidean_dist_delta_tool_error(wanted, existent):
    wanted_tool = np.append(kinmatics.forward(wanted)[0], wanted[-1])
    existent_tool = np.append(kinmatics.forward(existent)[0], existent[-1])
    return distance.euclidean(wanted_tool, existent_tool)


class ground_control:

    def __init__(self, matrix, resolution=0.005, with_jig=True, with_gripper=True):
        self._matrix = matrix

        self.error_func = max_delta_angles_error
        self.step_size = resolution

        self.arms = ROS_god()
        self.right_arms_epsilon = resolution
        
        self.left_arms_epsilon = resolution

        self.with_gripper = with_gripper
        self.with_jig = with_jig
        if self.with_jig:
            self.jig = IJ_main_motor()
            self.jig_epsilon = resolution * 6
        if with_gripper:
            self.gripper = Gripper()

    def set_error_func(self, function):
        self.error_func = function

    def set_arms_epsilon(self, epsilon):
        self.right_arms_epsilon = epsilon
        self.left_arms_epsilon = epsilon

    def is_arrived(self, wanted, existent, name):
        if name == 'right':
            error = self.error_func(wanted, existent)
            if error > self.right_arms_epsilon:
                self.right_arms_epsilon *= 1.01
                return False
            self.right_arms_epsilon *= 0.99
            return True
        if name == 'left':
            error = self.error_func(wanted, existent)
            if error > self.left_arms_epsilon:
                self.left_arms_epsilon *= 1.01
                return False
            self.left_arms_epsilon *= 0.99
            return True
        if name == 'jig':
            if not self.with_jig:
                return True
            error = abs(wanted - existent)
            if error > self.jig_epsilon:
                self.jig_epsilon *= 1.01
                return False
            self.jig_epsilon *= 0.99
            return True

    def run(self):
        #sleep(2)  # don't delete
        sleep(0.05)
        self.arms.read_arm_pos()
        if self.with_jig:
            self.jig.read_pos()
        sleep(0.05)  # don't delete
        # current = np.append(self.arms.present_right, [0])
        # current = np.append(current, self.arms.present_left)
        # current = np.append(current, [0])
        current = np.append(self.arms.present_right, self.arms.present_left)
        if self.with_gripper:
            current = np.append(current, [0])
            current = np.append(current, [-1])
        if self.with_jig:
            current_jig = self.jig.curr_pos
            current = np.append(current, current_jig)

        self._matrix = np.append(current.reshape(1, len(current)), self._matrix[:, range(len(current))], axis=0)

        diff_matrix = np.diff(self._matrix, axis=0)

        for index in range(len(self._matrix) - 1):
            # pos = self._matrix[index]
            # r_arm_pos = list(pos[0:6])
            # r_gripper_state = pos[6:7]
            # l_arm_pos = list(pos[7:13])
            # l_gripper_state = pos[13:14]

            pos = self._matrix[index]
            r_arm_pos = list(pos[0:6])
            l_arm_pos = list(pos[6:12])
            if self.with_gripper:
                r_gripper_state = pos[12:13]
                l_gripper_state = pos[13:14]
            if self.with_jig:
                jig_pos = pos[-1]
            max_step = max(np.max(diff_matrix[index]), np.min(diff_matrix[index]), key=abs)
            mid_points = max(abs(int(max_step / self.step_size)), 1)

            # if index == round(2 * len(self._matrix) / 3):
            #     input("Please press enter!")

            if self.with_gripper:
                self.gripper.update_state(self.gripper.r_gripper_states[r_gripper_state[0]],
                                          self.gripper.l_gripper_states[l_gripper_state[0]])

            for s in range(mid_points):
                # pos1 = r_arm_pos + (s + 1) * diff_matrix[index, 0:6] / mid_points
                # pos2 = l_arm_pos + (s + 1) * diff_matrix[index, 7:13] / mid_points
                pos1 = r_arm_pos + (s + 1) * diff_matrix[index, 0:6] / mid_points
                pos2 = l_arm_pos + (s + 1) * diff_matrix[index, 6:12] / mid_points

                self.arms.send_to_arm(np.array(pos1), np.array(pos2))
                pos3 = True
                curr_jig_pose = True
                if self.with_jig:
                    pos3 = jig_pos + (s + 1) * diff_matrix[index, -1] / mid_points
                    self.jig.move_IJ(pos3)
                    curr_jig_pose = self.jig.curr_pos
                while not (
                        self.is_arrived(pos1, self.arms.present_right, 'right') and
                        self.is_arrived(pos2, self.arms.present_left, 'left') and
                        self.is_arrived(pos3, curr_jig_pose, 'jig')
                ):
                    self.arms.rate.sleep()


def append_list_as_row(file_name, list_of_elem):
    # Open file in append mode
    with open(file_name, 'a+', newline='') as write_obj:
        # Create a writer object from csv module
        csv_writer = writer(write_obj)
        # Add contents of list as last row in the csv file
        csv_writer.writerow(list_of_elem)


def get_current_datetime():
    return datetime.now().strftime("%m-%d-%Y_%H-%M-%S")


def record_trajectory():
    # Record arms trajectory
    arms = ROS_god()
    arms.read_arm_pos()
    # jig = IJ_main_motor()
    # jig.read_pos()
    # jig.move_IJ(0)

    to_exit = 0
    trajectory = np.zeros([1, 15])

    step_index = 0
    filename = "trajectories/insert_trajectory_" + get_current_datetime() + ".csv"
    while to_exit is not '1':
        print("Press enter to record arms positions")
        to_exit = input()
        step = np.hstack((arms.present_right, arms.present_left, 0.5, -1, 0))
        # step = np.hstack((arms.present_right, arms.present_left, 0.5, -1, jig.curr_pos))

        # Append step to csv file.
        append_list_as_row(filename, step)
        print(np.round(step, 2))
        print('step delta: {}'.format(np.sum(np.abs(trajectory[-1, 0:13] - step[0:13]))))
        trajectory = np.vstack((trajectory, step))

        print("Press enter to move the jig")
        to_exit = input()
        # jig.move_IJ(-step_index * np.deg2rad(1))
        step_index = step_index + 1


def get_trajectory_from_record():
    my_data = np.genfromtxt('trajectories/kc_insert_trajectory_04-25-2021_14-46-10-half_path.csv', delimiter=',')
    return my_data


if __name__ == '__main__':
    # LDO madgim
    pos_matrix=TrajectoryFactory.get_LDO_trajectory()
    g_control = ground_control(pos_matrix, resolution=0.01, with_jig=False, with_gripper=False)
    #sleep(1)
    g_control.run()

    # Insert gasket madgim
    # insert_arm_fk_trajectory, forward_kinematic_trajectory_arm_guid, \
    # gripper_command_of_the_insert_arm, gripper_command_of_the_guid_arm, jig = TrajectoryFactory.get_insert_gasket_kc_fk_trajectory()
    # pos_matrix = np.hstack((insert_arm_fk_trajectory, forward_kinematic_trajectory_arm_guid, gripper_command_of_the_insert_arm, gripper_command_of_the_guid_arm, jig))
    # g_control = ground_control(pos_matrix, resolution=0.01, with_jig=True, with_gripper=True)
    # sleep(1)
    # g_control.run()






