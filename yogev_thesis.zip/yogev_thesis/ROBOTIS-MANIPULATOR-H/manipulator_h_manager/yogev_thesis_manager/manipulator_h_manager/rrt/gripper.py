#!/usr/bin/env python3

try:
    import rospy
    from manipulator_h_base_module_msgs.msg import JointPose
except:
    pass


class Gripper:
    GRIP_STATE = 1
    CAGE_STATE = 0.5
    OPEN_STATE = 0
    INSERT_STATE = -1

    def __init__(self):
        # rospy.init_node('ROS', anonymous=True)
        self.r_gripper_states = {self.GRIP_STATE: [3, -2.1], self.CAGE_STATE: [3, -2.15], self.OPEN_STATE: [3, -2.6]
            , self.INSERT_STATE: [-0.4, -2.4]}
        self.l_gripper_states = {self.GRIP_STATE: [3, -1.7], self.CAGE_STATE: [3, -1.8], self.OPEN_STATE: [3, -2.2]
            , self.INSERT_STATE: [-0.4, -2.4]}
        self.pub1 = rospy.Publisher('/gripper_right/robotis/gripper/joint_pose_msg', JointPose, queue_size=0)
        self.pub2 = rospy.Publisher('/gripper_left/robotis/gripper/joint_pose_msg', JointPose, queue_size=0)
        self.rate = rospy.Rate(50)

        self.kp1 = JointPose()
        self.kp2 = JointPose()

        self.kp1.name = ['joint1', 'joint2']
        self.kp1.value = [0, 0]

        self.kp2.name = ['joint1', 'joint2']
        self.kp2.value = [0, 0]

        self.present_1 = [0, 0]
        self.present_2 = [0, 0]

    def update_state(self, state1, state2):
        self.kp1.value = state1
        self.kp2.value = state2
        self.pub1.publish(self.kp1)
        self.pub2.publish(self.kp2)
        self.rate.sleep()
