#!/usr/bin/env python3
import numpy as np
from arm_kinematic import ArmKinematic
from arm_kinematic import ArmCannotReachPosition

class TrajectoryConvertor:
    """ This class responsible to convert trajectory in terms of position and orientation of the robotic arm (inverse
    kinematic - IK) to trajectory in terms of motors angles (forward kinematic - fk). """

    @staticmethod
    def convert_trajectory_to_forward_kinematic(inverse_kinematic_trajectory):
        for ii in range(8):
            try:
                forward_kinematic_trajectory = TrajectoryConvertor.convert_trajectory_to_forward_kinematic_by_initial_solution_index(inverse_kinematic_trajectory, ii)
                print("Found solution using initial_solution_index {}.".format(ii))
                return forward_kinematic_trajectory
            except Exception as error:
                print("No valid solution using initial_solution_index {}, error: {}".format(ii, error))
        raise Exception('No valid solution is found! Try different path...')


    @staticmethod
    def convert_trajectory_to_forward_kinematic_by_initial_solution_index(inverse_kinematic_trajectory, initial_solution_index=0):
        forward_kinematic_trajectory = np.array([[0, 0, 0, 0, 0, 0]])
        try:
            previous_step = TrajectoryConvertor.convert_the_first_step_to_forward_kinematic(inverse_kinematic_trajectory[0], initial_solution_index)
        except (NoValidForwardKinematicStepIsFound, MotorsAnglesNotInRange, ArmCannotReachPosition) as error:
            raise Exception(TrajectoryConvertor.format_error_msg(error, 0, inverse_kinematic_trajectory[0]))
        forward_kinematic_trajectory = np.append(forward_kinematic_trajectory, previous_step, axis=0)
        for i in range(len(inverse_kinematic_trajectory) - 1):
            trajectory_step = inverse_kinematic_trajectory[i + 1]
            try:
                forward_kinematic_step_configs = TrajectoryConvertor.convert_step_to_forward_kinematic(trajectory_step, previous_step)
            except (NoValidForwardKinematicStepIsFound, MotorsAnglesNotInRange, ArmCannotReachPosition) as error:
                raise Exception(TrajectoryConvertor.format_error_msg(error, i, trajectory_step))
            # Select from the 8 possible forward kinematic solutions the solution which  is the closest to the previous solution.
            next_forward_trajectory_step = TrajectoryConvertor.select_the_next_forward_trajectory_step(forward_kinematic_step_configs, previous_step)
            forward_kinematic_trajectory = np.append(forward_kinematic_trajectory, next_forward_trajectory_step, axis=0)
            previous_step = next_forward_trajectory_step
        return forward_kinematic_trajectory[1:]

    @staticmethod
    def convert_the_first_step_to_forward_kinematic(trajectory_step, initial_solution_index):
        forward_kinematic_step_config = TrajectoryConvertor.get_forward_kinematic_step(trajectory_step[0:3], trajectory_step[3:6], initial_solution_index)
        if not np.all(ArmKinematic.is_motors_angles_in_range(forward_kinematic_step_config)):
            raise MotorsAnglesNotInRange('Motors angles not in range')
        return forward_kinematic_step_config

    @staticmethod
    def convert_step_to_forward_kinematic(trajectory_step, previous_step):
        forward_kinematic_step_configs = np.array([[0, 0, 0, 0, 0, 0]])
        for i in range(8):
            forward_kinematic_step_config = TrajectoryConvertor.get_forward_kinematic_step(trajectory_step[0:3], trajectory_step[3:6], i, previous_step[0, 5], previous_step[0, 1])
            # Ignore step that are out of range or the difference from the previous step is bigger from 10 deg.
            if not np.all(ArmKinematic.is_motors_angles_in_range(forward_kinematic_step_config)):
                continue
            if TrajectoryConvertor.abs_diff_angles(forward_kinematic_step_config, previous_step).max(axis=1) > np.deg2rad(10):
                continue
            forward_kinematic_step_configs = np.append(forward_kinematic_step_configs, forward_kinematic_step_config, axis=0)

        if forward_kinematic_step_configs.shape[0] == 1:
            raise NoValidForwardKinematicStepIsFound('No valid forward kinematic step is found for trajectory_step')
        # Return matrix with out the first row.
        return forward_kinematic_step_configs[1:]

    @staticmethod
    def get_forward_kinematic_step(position, orientation, index_solution, t6=0, t1=0):
        forward_kinematic_step = ArmKinematic.inverse(position, orientation, index_solution, t6, t1)
        return TrajectoryConvertor.convert_angle_abs_value_to_less_than_pi(forward_kinematic_step)

    @staticmethod
    def select_the_next_forward_trajectory_step(forward_kinematic_step_configs, previous_step):
        configs_diff = TrajectoryConvertor.abs_diff_angles(forward_kinematic_step_configs, previous_step)
        diff_summery = configs_diff.sum(axis=1)
        smallest_step_config = np.array([forward_kinematic_step_configs[diff_summery.argmin()]])
        return smallest_step_config

    @staticmethod
    def abs_diff_angles(angle_matrix, angle_row_vector):
        # Work only with angles value between 0-180 or -180-0,
        # The Arm's motors cannot move from 179 deg to 181 in the short way (The motor will spin 358 deg in this case).
        angle_diff = np.abs(angle_matrix - angle_row_vector)
        return angle_diff

    @staticmethod
    def convert_angles_to_positive_values(angles):
        angles[angles < 0] = angles[angles < 0] + np.pi * 2
        return angles

    @staticmethod
    def convert_angle_abs_value_to_less_than_pi(angles):
        if not np.all(angles <= np.pi*3) or not np.all(angles >= -np.pi*3):
            raise Exception('Angles value should be between -540%540 deg!')
        angles[angles > np.pi] = -2*np.pi + angles[angles > np.pi]  # Convert 270 deg to -90 deg.
        angles[angles < -np.pi] = 2*np.pi + angles[angles < -np.pi]  # Convert -270 to 90 deg.
        return angles

    @staticmethod
    def format_positions_and_orientation(positions, orientation, transform_matrix):
        # Format data to [x, y, z, roll, pitch, yaw]
        positions_arm = ArmKinematic.transform_points_world_to_arm(positions, transform_matrix)
        return np.concatenate((positions_arm, orientation), axis=1)

    @staticmethod
    def format_error_msg(error_msg, step_index,  position_and_orientation):
        position = np.round(position_and_orientation[0:3], 2)
        orientation = np.round(np.rad2deg(position_and_orientation[3:6]), 2)
        return '{}, step index: {}, position: {}, orientation, {}'.format(error_msg, step_index, position, orientation)


class NoValidForwardKinematicStepIsFound(Exception):
    """Raised when no valid forward kinematic step is found for trajectory step"""
    pass


class MotorsAnglesNotInRange(Exception):
    """Raised when motors angles not in range for Arm"""
    pass


