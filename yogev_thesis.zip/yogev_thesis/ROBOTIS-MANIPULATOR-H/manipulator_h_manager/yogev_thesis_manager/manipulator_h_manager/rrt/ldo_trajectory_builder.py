#!/usr/bin/env python3
import numpy as np

class LDO_trajectpry:

    def __init__(self):

        self.LDO_len = 460
        # simulate value of LDO position
        self.LDO_sim_pos = np.loadtxt("LDO_sim_pos.txt", dtype=float)
        self.shift_y = -300
        self.shift_z = 30
        self.shift_x = 50
        # define the interval time to go for each point
        self.num_time_step = 700
        self.t_final = 30
        self.t_switch_left = np.array([0, 10, 20, 30])
        self.t_switch_right = np.array([0, 10, 20, 30])
        self.t = np.linspace(0, self.t_final, self.num_time_step)
        self.dt = self.t_final / (self.num_time_step - 1)

        # define the position and orientations matrices
        self.p_left = np.zeros([len(self.t), 3])
        self.p_right = np.zeros([len(self.t), 3])
        self.roll_pitch_yaw_left = np.zeros([len(self.t), 3])
        self.roll_pitch_yaw_right = np.zeros([len(self.t), 3])

        # define the path points for left hand
        self.path_left = np.array([[-190, 170, 300], [-140, 170, 300], [-140, 170, 300], [-140, 250, 250]])
        # define the path orientations for left hand
        self.path_roll_pitch_yaw_left = np.array([[np.pi, 0, 0], [np.pi, 0, np.pi/6], [np.pi, 0, 0], [np.pi, 0, np.pi/6]])

        # define the path points for right hand
        self.path_right = np.array([[190, 170, 300], [130, 200, 200], [130, 100, 340], [130, 100, 340]])
        # define the path orientations for right hand
        self.path_roll_pitch_yaw_right = np.array([[-np.pi, 0, 0], [-np.pi, np.pi/2, 0], [-np.pi, np.pi/4, 0],
                                                   [-np.pi, np.pi/4, 0]])

        # calculate translation and angle velocity for left hand
        self.V_left = np.zeros([len(self.t_switch_left) - 1, 3])
        self.omega_left = np.zeros([len(self.t_switch_left) - 1, 3])
        for i in range(len(self.t_switch_left) - 1):
            self.V_left[i, :] = (self.path_left[i + 1, :] - self.path_left[i, :]) / \
                                (self.t_switch_left[i + 1] - self.t_switch_left[i])
            self.omega_left[i, :] = (self.path_roll_pitch_yaw_left[i + 1, :] - self.path_roll_pitch_yaw_left[i, :]) / \
                                (self.t_switch_left[i + 1] - self.t_switch_left[i])

        # calculate translation and angle velocity for left hand
        self.V_right = np.zeros([len(self.t_switch_right) - 1, 3])
        self.omega_right = np.zeros([len(self.t_switch_right) - 1, 3])
        for i in range(len(self.t_switch_right) - 1):
            self.V_right[i, :] = (self.path_right[i + 1, :] - self.path_right[i, :]) / \
                                (self.t_switch_right[i + 1] - self.t_switch_right[i])
            self.omega_right[i, :] = (self.path_roll_pitch_yaw_right[i + 1, :] - self.path_roll_pitch_yaw_right[i, :])\
                                    / (self.t_switch_right[i + 1] - self.t_switch_right[i])

########################################################################################################################

    def ldo_trajectory(self):
        index_left = 0
        index_right = 0
        for t in range(len(self.t)):
            # check if left hand rich to switch point
            if self.t[t] > self.t_switch_left[index_left + 1] and index_left < len(self.t_switch_left) - 1:
                index_left += 1
            # check if right hand rich to switch point
            if self.t[t] > self.t_switch_right[index_right + 1] and index_right < len(self.t_switch_right) - 1:
                index_right += 1

            # calculate the pos and ori for left hand
            self.p_left[t, :] = self.path_left[index_left, :] + self.V_left[index_left, :] * \
                                (self.t[t] - self.t_switch_left[index_left])

            self.roll_pitch_yaw_left[t, :] = self.path_roll_pitch_yaw_left[index_left, :]\
                                             + self.omega_left[index_left, :] * (self.t[t] - self.t_switch_left[index_left])

            # calculate the pos and ori for right hand
            self.p_right[t, :] = self.path_right[index_right, :] + self.V_right[index_right, :] * \
                                (self.t[t] - self.t_switch_right[index_right])

            self.roll_pitch_yaw_right[t, :] = self.path_roll_pitch_yaw_right[index_right, :] \
                                             + self.omega_right[index_right, :] * (self.t[t] - self.t_switch_right[index_right])

        self.p_left[:, 0] += self.shift_x
        self.p_right[:, 0] += self.shift_x
        self.p_left[:, 1] += self.shift_y
        self.p_right[:, 1] += self.shift_y
        self.p_left[:, 2] += self.shift_z
        self.p_right[:, 2] += self.shift_z
########################################################################################################################

    def get_p_left(self):
        return self.path_left

    def get_p_right(self):
        return self.path_right

    def get_roll_pitch_yaw_left(self):
        return self.roll_pitch_yaw_left

    def get_roll_pitch_yaw_right(self):
        return self.roll_pitch_yaw_right
