#!/usr/bin/env python3
import csv
import math
import pickle
from datetime import datetime
from time import *

from klampt import vis
from klampt.model import trajectory
from arms_control import ROS_god, kinmatics
import rospy  # Import the Python library for ROS
from time import time, sleep
from dynamixel_workbench_msgs.srv import DynamixelCommand, DynamixelCommandRequest
from IJ_main_motor import IJ_main_motor
import numpy as np
from trajectory_factory import TrajectoryFactory
from scipy.spatial import distance
import gripper



def max_delta_angles_error(wanted, existent):
    return np.max(abs(np.array(wanted) - np.array(existent)))


def max_delta_tool_error(wanted, existent):
    wanted_tool = np.append(kinmatics.forward(wanted)[0], wanted[-1])
    existent_tool = np.append(kinmatics.forward(existent)[0], existent[-1])
    return np.max(abs(np.array(wanted_tool) - np.array(existent_tool)))


def euclidean_dist_delta_angles_error(wanted, existent):
    return distance.euclidean(wanted, existent)


def euclidean_dist_delta_tool_error(wanted, existent):
    wanted_tool = np.append(kinmatics.forward(wanted)[0], wanted[-1])
    existent_tool = np.append(kinmatics.forward(existent)[0], existent[-1])
    return distance.euclidean(wanted_tool, existent_tool)


class ground_control:

    def __init__(self, matrix):
        self.arms = ROS_god()
        self.jig = IJ_main_motor()
        self.gripper = gripper.Gripper()
        self._matrix = matrix
        self.error_func = None
        self.right_arms_epsilon = None
        self.left_arms_epsilon = None
        self.jig_epsilon = np.deg2rad(3)
        self.arms.read_arm_pos()
        self.max_error = 0
        self.total_errors = 0
        self.isArrived_right_calls = 0
        self.isArrived_left_calls = 0
        self.mid_points_den = 0.01
        self.arms.read_arm_pos
        self.sum_right_epsilon = None
        self.sum_left_epsilon = None

    def set_error_func(self, function):
        self.error_func = function

    def set_arms_epsilon(self, epsilon):
        self.right_arms_epsilon = epsilon
        self.left_arms_epsilon = epsilon
        self.sum_right_epsilon = epsilon
        self.sum_left_epsilon = epsilon

    def set_mid_points_den(self):
        self.mid_points_den *= 1.1

    def is_arrived(self, wanted, existent, name):
        if name == 'right':
            error = self.error_func(wanted, existent)
            # print(self.right_arms_epsilon.__str__())
            if error > self.max_error:
                self.max_error = error
            self.total_errors += error
            self.isArrived_right_calls += 1
            if error > self.right_arms_epsilon:
                self.right_arms_epsilon *= 1.01
                self.sum_right_epsilon += self.right_arms_epsilon
                # csv.writer(exc).writerow([str(self.right_arms_epsilon), str(self.isArrived_right_calls)])
                return False
            self.right_arms_epsilon *= 0.99
            self.sum_right_epsilon += self.right_arms_epsilon
            # csv.writer(exc).writerow([str(self.right_arms_epsilon), str(self.isArrived_right_calls)])
            return True
        if name == 'left':
            error = self.error_func(wanted, existent)
            # print(self.left_arms_epsilon.__str__())
            if error > self.max_error:
                self.max_error = error
            self.total_errors += error
            self.isArrived_left_calls += 1
            if error > self.left_arms_epsilon:
                self.left_arms_epsilon *= 1.01
                self.sum_left_epsilon += self.left_arms_epsilon
                return False
            self.left_arms_epsilon *= 0.99
            self.sum_left_epsilon += self.left_arms_epsilon
            return True

    def run(self):
        max_epsilon_to_write = 0
        max_iter_duration = 0
        iteration_counter = 0
        self.max_error = 0
        self.sum_left_epsilon = 0
        self.sum_right_epsilon = 0
        self.isArrived_left_calls = 0
        self.isArrived_right_calls = 0
        self.total_errors = 0
        self.max_error = 0
        stacked_counter = 0
        average_stacked_times = 0
        start_time = time()
        self.arms.read_arm_pos()
        self.jig.read_pos()
        current = np.append(self.arms.present_right, [0])
        current = np.append(current, self.arms.present_left)
        current = np.append(current, [0])
        current_jig = self.jig.curr_pos
        current = np.append(current, current_jig)
        self._matrix = np.append(current.reshape(1, 15), self._matrix, axis=0)
        diff_matrix = np.diff(self._matrix, axis=0)
        for index in range(len(self._matrix) - 1):
            iter_start_time = time()
            pos = self._matrix[index]
            pos11 = list(pos[0:6])
            gripper_state_1 = pos[6:7]
            pos21 = list(pos[7:13])
            gripper_state_2 = pos[13:14]
            pos33 = pos[14]
            maximum = max(np.max(diff_matrix[index]), np.min(diff_matrix[index]), key=abs)
            mid_points = max(abs(int(maximum / self.mid_points_den)), 1)  # 0.005

            self.gripper.update_state(self.gripper.gripper_states[gripper_state_1[0]], self.gripper.gripper_states[gripper_state_2[0]])

            for s in range(mid_points):
                iteration_counter += 1
                pos1 = pos11 + (s + 1) * diff_matrix[index, 0:6] / mid_points
                pos2 = pos21 + (s + 1) * diff_matrix[index, 7:13] / mid_points
                pos3 = pos33 + (s + 1) * diff_matrix[index, 14] / mid_points
                self.jig.move_IJ(pos3)
                stuck_time_start = time()
                self.arms.send_to_arm(np.array(pos1), np.array(pos2))
                flag = False
                while not (
                        self.is_arrived(pos1, self.arms.present_right, 'right') and  # right
                        self.is_arrived(pos2, self.arms.present_left, 'left')  # left
                        and abs(pos3 - self.jig.curr_pos) < self.jig_epsilon
                ):
                    print(self.jig_epsilon)
                    if abs(pos3 - self.jig.curr_pos) > self.jig_epsilon:
                        self.jig_epsilon = 1.01*self.jig_epsilon
                    else:
                        self.jig_epsilon = 0.99 * self.jig_epsilon
                    flag = True
                    curr_iter_duration = time() - iter_start_time
                    max_iter_duration = max(max_iter_duration, curr_iter_duration)
                    max_epsilon_to_write = max(max_epsilon_to_write, self.right_arms_epsilon, self.left_arms_epsilon)
                    stack_time = time() - stuck_time_start
                    # if stack_time > 5:
                    #     break
                    self.arms.rate.sleep()

                if flag:
                    stacked_counter += 1
                    average_stacked_times = (average_stacked_times + stack_time)/stacked_counter
                if not flag:
                    curr_iter_duration = time() - iter_start_time
                    max_iter_duration = max(max_iter_duration, curr_iter_duration)
                    max_epsilon_to_write = max(max_epsilon_to_write, self.right_arms_epsilon, self.left_arms_epsilon)
        total_duration = time() - start_time
        average_iter_duration = total_duration / iteration_counter
        average_error = self.total_errors / (self.isArrived_right_calls + self.isArrived_left_calls)
        average_right_epsilon = self.sum_right_epsilon/self.isArrived_right_calls
        average_left_epsilon = self.sum_left_epsilon/self.isArrived_left_calls
        # file = open('error_report.txt', 'a')
        file.write('Max Epsilon: ' + str(max_epsilon_to_write) + '\n')
        file.write('Average Epsilon: ' + str(average_right_epsilon) + '\n')
        file.write('Mid_points_den: ' + str(self.mid_points_den) + '\n')
        file.write('Total duration: ' + str(total_duration) + '\n')
        file.write('Max iteration duration: ' + str(max_iter_duration) + '\n')
        file.write('Average iteration duration: ' + str(average_iter_duration) + '\n')
        file.write('Max error: ' + str(self.max_error) + '\n')
        file.write('Average error: ' + str(average_error) + '\n\n\n')
        # file.close()
        info = np.array([[average_right_epsilon, average_left_epsilon, max_epsilon_to_write,
                          self.mid_points_den, total_duration,
                          max_iter_duration, average_iter_duration, self.max_error, average_error, average_stacked_times]])
        return info


if __name__ == '__main__':
    # pos_matrix = np.zeros(shape=(100, 15))
    # for i in range(0, 100):
    #     pos_matrix[i] = np.array(
    #         [0.2+i/150, 0, -i / 200 - 0.5, 0, i / 100, 0, 0.2-i/150, 0, i / 100 - 0.5, 0, i / 100, 0,
    #          (i / 180) * math.pi])
    #
    # pos_matrix = np.append(pos_matrix, np.flip(pos_matrix, axis=0), axis=0)
    # for i in range(0, 100):
    #     pos_matrix = np.append(pos_matrix, np.array( [[0.2 - i / 100, 0, 0, 0, i / 100, 0, 0, 0.2, 0, i / 100, 0, -i / 100, 0, 0, 0]]), axis=0)

    # gr = gripper.Gripper()
    # for k in gr.gripper_states.keys():
    #     gr.update_state(gr.gripper_states[k], gr.gripper_states[k])
    #     sleep(1)
    date = datetime.today().__str__()
    func_dict = {0: [max_delta_angles_error, np.deg2rad(1), "max_delta_angles_error_matrix.pkl"],
                 1: [max_delta_tool_error, 1, "max_delta_tool_error_matrix.pkl"],
                 2: [euclidean_dist_delta_angles_error, math.sqrt(6) / 2,
                     "euclidean_dist_delta_angles_error_matrix.pkl"],
                 3: [euclidean_dist_delta_tool_error, math.sqrt(3), "euclidean_dist_delta_tool_error_matrix.pkl"]
                 }
    pos_matrix = TrajectoryFactory.get_insert_gasket_fk_trajectory_as_matrix()
    g_control = ground_control(pos_matrix)
    file = open('error_report.txt', 'a')
    for func in func_dict.values():
        # g_control.mid_points_den = 0.1
        g_control.set_error_func(func[0])
        file.write(func[2][:-11] + ':\n\n')
        error_matrix = np.zeros((1, 10))
        a_epsilon = func[1]
        g_control.set_arms_epsilon(a_epsilon)
        for i in range(4):

            for j in range(3):
                sleep(1)
                #exc = open('matrices/epsilon_output.csv' + str(i)+str(j) + func[2], 'w', newline='')
                #csv.writer(exc).writerow(["curr_eps", "curr_iter"])
                # g_control.set_arms_epsilon(a_epsilon)
                error_matrix = np.append(error_matrix, g_control.run(), axis=0)
                # a_epsilon += 0.05
                #if j % 4 == 0:
                #    pickle.dump(error_matrix, open('matrices/'+date+func[2], 'wb'))
                #exc.close()
            #pickle.dump(error_matrix[1:], open('matrices/'+date+func[2], 'wb'))
            g_control.set_mid_points_den()
    file.close()

    # arms= ROS_god()
    
    # arms.read_arm_pos() 
    # jig= IJ_main_motor()
    # for i in (range(410)):
    #     print(0.2+i)
    #     pos1=np.array([0.2,0,0,0,0,i/100])
    #     pos2=np.array([0.2,0,0,0,0,-i/100])
    #     arms.send_to_arm(pos1,pos2)
    #     jig.move_IJ(i*10)
    #     print("\t\t",np.round(np.array(arms.present_right),3),"_\t\t",np.round(np.array(arms.present_left),3))
    #     time.sleep(1)
