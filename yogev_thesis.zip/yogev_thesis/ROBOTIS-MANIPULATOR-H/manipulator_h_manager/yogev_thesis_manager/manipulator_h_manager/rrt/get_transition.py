import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import time

class ShiftOrigin:
    def __init__(self, Direction='Left'):

        self.my_length = 200
        if Direction == 'Left':
            self.title = Direction
            self.Origin_gripper = np.array([[0], [250], [450]])  # Gripper origin
            self.gripper_x = np.array([[-200], [250], [450]])
            self.gripper_y = np.array([[0], [450], [450]])
            self.gripper_z = np.array([[0], [250], [650]])
            self.Origin_opti = np.array([[4.48746], [-229.15579], [-485.50446]])
            self.opti_x = np.array([[-191.22195], [-232.3221], [-480.821]])
            self.opti_y = np.array([[6.2627], [-426.593], [-488.30565]])
            self.opti_z = np.array([[0.3963], [-230.240], [-684.58710]])

        else:
            self.title = 'Right'
            self.Origin_gripper = np.array([[0], [250], [450]])  # Gripper origin
            self.gripper_x = np.array([[-200], [250], [450]])
            self.gripper_y = np.array([[0], [450], [450]])
            self.gripper_z = np.array([[0], [250], [650]])
            self.Origin_opti = np.array([[603.6508], [264.67304], [-492.95483]])
            self.opti_x = np.array([[798.7788], [280.9024], [-487.4848]])
            self.opti_y = np.array([[603.1157], [462.0411], [-500.36685]])
            self.opti_z = np.array([[603.33425], [261.0917], [-689.88305]])

        self.grippe_x_norm = self.normelize_vector_creator(self.gripper_x, self.Origin_gripper)
        self.grippe_y_norm = self.normelize_vector_creator(self.gripper_y, self.Origin_gripper)
        self.grippe_z_norm = self.normelize_vector_creator(self.gripper_z, self.Origin_gripper)
        self.gripper = [self.gripper_x, self.gripper_y, self.gripper_z]

        self.opti = [self.opti_x, self.opti_y, self.opti_z]

        self.opti_gripper_x = np.array(
            [[float(np.dot(np.transpose(self.opti_x - self.Origin_opti), self.grippe_x_norm))],
             [float(np.dot(np.transpose(self.opti_x - self.Origin_opti), self.grippe_y_norm))],
             [float(np.dot(np.transpose(self.opti_x - self.Origin_opti), self.grippe_z_norm))]])
        self.opti_gripper_y = np.array(
            [[float(np.dot(np.transpose(self.opti_y - self.Origin_opti), self.grippe_x_norm))],
             [float(np.dot(np.transpose(self.opti_y - self.Origin_opti), self.grippe_y_norm))],
             [float(np.dot(np.transpose(self.opti_y - self.Origin_opti), self.grippe_z_norm))]])
        self.opti_gripper_z = np.array(
            [[float(np.dot(np.transpose(self.opti_z - self.Origin_opti), self.grippe_x_norm))],
             [float(np.dot(np.transpose(self.opti_z - self.Origin_opti), self.grippe_y_norm))],
             [float(np.dot(np.transpose(self.opti_z - self.Origin_opti), self.grippe_z_norm))]])

        self.opti_x_norm = self.opti_gripper_x / np.linalg.norm(self.opti_gripper_x)
        self.opti_y_norm = self.opti_gripper_y / np.linalg.norm(self.opti_gripper_y)
        self.opti_z_norm = self.opti_gripper_z / np.linalg.norm(self.opti_gripper_z)

        self.Rotataion_matrix = np.hstack((self.opti_x_norm, self.opti_y_norm, self.opti_z_norm, np.array([[0], [0], [0]])))
        self.Rotataion_matrix = np.vstack((self.Rotataion_matrix, np.array([[0, 0, 0, 1]])))

    @staticmethod
    def normelize_vector_creator(point, origon):  # create normlize vector from point and origon
        norm_vec = (point - origon) / np.linalg.norm(point - origon)
        return norm_vec

    def stand_deviation(self):
        x_dis = (self.gripper_x - self.Origin_gripper) - (self.opti_x - self.Origin_opti)
        y_dis = (self.gripper_y - self.Origin_gripper) - (self.opti_y - self.Origin_opti)
        z_dis = (self.gripper_z - self.Origin_gripper) - (self.opti_z - self.Origin_opti)
        a = np.array([x_dis, y_dis, z_dis])
        a = np.std(a)
        print(a)

    def plot_gen(self):

        fig = plt.figure(1)
        ax = plt.axes(projection='3d')
        plt.axes
        plt.grid()
        """ Limits """
        ax.set_title(self.title)
        ax.set_xlim([-700, 700])
        ax.set_ylim([-700, 700])
        ax.set_zlim([-700, 700])
        ax.set_xlabel('$X$')
        ax.set_ylabel('$Y$')
        ax.set_zlabel('$Z$')
        # ax.set_xlim([-50, 50])
        # ax.set_ylim([200, 300])
        # ax.set_zlim([400, 500])
        return ax, fig

    def plot_circle(self, point, ax, my_color=['k']):
        """ Plotting vectors """
        ax.scatter(point[0], point[1], point[2], s=self.my_length / 3, color=my_color)

    def get_transform_matrix(self, show=False):
        point = self.Origin_opti
        Rotation = self.Rotataion_matrix
        temp_point = self.transform_point(point, Rotation)
        temp_x = self.transform_point(self.opti_x, Rotation)
        temp_y = self.transform_point(self.opti_y, Rotation)
        temp_z = self.transform_point(self.opti_z, Rotation)
        temp_cord = [temp_x, temp_y, temp_z]
        if show:
            ax, fig = test.plot_gen()
            self.plot_axis(ax, self.Origin_gripper, self.gripper, ['k', 'r', 'b'])  # plot the arm axis
            self.plot_axis(ax, self.Origin_opti, self.opti, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
            self.plot_axis(ax, temp_point, temp_cord, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
            plt.show()
        distance = self.Origin_gripper - temp_point
        transition_matrix = np.array([[1, 0, 0, float(distance[0])],
                                      [0, 1, 0, float(distance[1])],
                                      [0, 0, 1, float(distance[2])],
                                      [0, 0, 0, 1]])
        temp_point = self.transform_point(temp_point, transition_matrix)
        temp_x = self.transform_point(temp_x, transition_matrix)
        temp_y = self.transform_point(temp_y, transition_matrix)
        temp_z = self.transform_point(temp_z, transition_matrix)
        temp_cord = [temp_x, temp_y, temp_z]

        if show:
            ax, fig = test.plot_gen()
            self.plot_axis(ax, self.Origin_gripper, self.gripper, ['k', 'r', 'b'])  # plot the arm axis
            self.plot_axis(ax, self.Origin_opti, self.opti, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
            self.plot_axis(ax, temp_point, temp_cord, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
            plt.show()
        transimtion_matrix = np.dot(transition_matrix, Rotation)
        return transimtion_matrix

    def show_transform(self):
        point = self.Origin_opti
        ax, fig = test.plot_gen()
        transimtion_matrix = self.get_transform_matrix()
        temp_point = self.transform_point(point, transimtion_matrix)
        temp_x = self.transform_point(self.opti_x, transimtion_matrix)
        temp_y = self.transform_point(self.opti_y, transimtion_matrix)
        temp_z = self.transform_point(self.opti_z, transimtion_matrix)
        temp_cord = [temp_x, temp_y, temp_z]
        self.plot_axis(ax, self.Origin_gripper, self.gripper, ['k', 'r', 'b'])  # plot the arm axis
        self.plot_axis(ax, self.Origin_opti, self.opti, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
        self.plot_axis(ax, temp_point, temp_cord, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
        plt.show()

    def plot_vector(self, Origin, point, ax, my_color=['k']):
        """ Plotting vectors """
        point = self.normelize_vector_creator(point, Origin)
        ax.quiver(Origin[0], Origin[1], Origin[2], point[0], point[1], point[2], color=my_color, length=self.my_length)

    def plot_axis(self, ax, Origin, array, color_map):
        for point, my_color in zip(array, color_map):
            self.plot_vector(Origin, point, ax, my_color)
        self.plot_circle(Origin, ax, color_map[1])

    def transform_point(self, p_0, trasformation_matrix):
        p_1 = np.dot(trasformation_matrix, np.vstack((p_0, [1]))).astype(float)
        return p_1[:3]

    def transform_list(self, list, trasformation_matrix):
        for point in list:
            point = self.transform_point(point, trasformation_matrix)
        return list

    def live_plot(self):
        grid = 20
        a = self.get_transform_matrix()
        a = a - np.eye(4)
        point = self.Origin_opti
        for i in range(1, grid + 1):
            plt.clf()
            ax, fig = self.plot_gen()
            transimtion_matrix = np.eye(4) + a * (i / grid)
            temp_point = self.transform_point(point, transimtion_matrix)
            temp_x = self.transform_point(self.opti_x, transimtion_matrix)
            temp_y = self.transform_point(self.opti_y, transimtion_matrix)
            temp_z = self.transform_point(self.opti_z, transimtion_matrix)
            temp_cord = [temp_x, temp_y, temp_z]
            self.plot_axis(ax, self.Origin_gripper, self.gripper, ['k', 'r', 'b'])  # plot the arm axis
            self.plot_axis(ax, self.Origin_opti, self.opti, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
            self.plot_axis(ax, temp_point, temp_cord, ['k', 'salmon', 'cyan'])  # plot the opti_track axis
            plt.draw()
            plt.pause(0.1)
        plt.show()


if __name__ == "__main__":
    np.set_printoptions(suppress=True)

    test = ShiftOrigin('Left')
    transform_matrix = test.get_transform_matrix(show=False)
    print(np.round(transform_matrix, 3))
    # print(transform_matrix)
    print('-------------------------------------')
    # test.live_plot()
    test = ShiftOrigin('Right')
    transform_matrix = test.get_transform_matrix(show=False)
    print(np.round(transform_matrix, 3))
    # print(transform_matrix)
    # test.live_plot()
