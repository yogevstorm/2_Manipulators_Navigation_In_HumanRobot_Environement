#!/usr/bin/env python3
import numpy as np
from Inserting_gasket.micro_action import micro_act
import matplotlib.pyplot as plt


class MicroActionFactory:

    def __init__(self):
        # define the geometric of the box
        jig_pos = np.array([100, 0, 0])
        theta_box_0 = np.pi/4  # the angle of box in the start
        box_pos = np.array([100, 50, 0])
        # build translation matrices
        A_0_jig = np.array([[1, 0, 0, jig_pos[0]],
                            [0, 1, 0, jig_pos[1]],
                            [0, 0, 1, jig_pos[2]],
                            [0, 0, 0, 1]])

        A_jig_box = np.array([[np.cos(theta_box_0), -np.sin(theta_box_0), 0, box_pos[0]],
                              [np.sin(theta_box_0), np.cos(theta_box_0), 0, box_pos[1]],
                              [0, 0, 1, box_pos[2]],
                              [0, 0, 0, 1]])

        A_0_box = A_0_jig.dot(A_jig_box)

        r = 32.305  # radios of the corneas
        box_length = 519.845
        box_width = 338.695
        length_r_to_r = 453.58
        width_r_to_r = 272.49
        L = 250  # distance between grippers
        z_LH = 0  # high of left griper
        z_RH = 10  # high of right griper
        p_LH_0 = np.array([0, -box_width / 2, z_LH])  # position of the first insulation
        dt = 0.05
        v = 10  # velocity

        # define the path matrix by key points, where key point is a place when theta Change.
        # argument 1 is x coordinate, argument f2 is y coordinate, argument 3 is z coordinate...
        # argument 4 is the radios of the corneas and argument 5 is the angle of the corneas
        p0 = np.array([p_LH_0[0], p_LH_0[1], p_LH_0[2], 0, 0])  # the angle of tangent line
        p1 = np.array([length_r_to_r / 2, -box_width / 2, z_LH, r, np.pi / 2])
        p2 = np.array([box_length / 2, -width_r_to_r / 2, z_LH, 0, 0])
        p3 = np.array([box_length / 2, width_r_to_r / 2, z_LH, r, np.pi / 2])
        p4 = np.array([length_r_to_r / 2, box_width / 2, z_LH, 0, 0])
        p5 = np.array([-length_r_to_r / 2, box_width / 2, z_LH, r, np.pi / 2])
        p6 = np.array([-box_length / 2, width_r_to_r / 2, z_LH, 0, 0])
        p7 = np.array([-box_length / 2, -width_r_to_r / 2, z_LH, r, np.pi / 2])
        p8 = np.array([-length_r_to_r / 2, -box_width / 2, z_LH, 0, 0])

        # build the path matrix
        path = np.array([p0, p1, p2, p3, p4, p5, p6, p7, p8, p0])
        ################################################################################################################
        self.mic = micro_act(r, L, z_LH, z_RH, p_LH_0, theta_box_0, dt, v, path, A_0_box, jig_pos)
        ################################################################################################################
        k = 0
        i = 0
        while k != len(path[:]) - 1:
            if path[k][4] == 0:
                k, i = self.mic.linear_movement(k, i)
            if path[k][4] != 0:
                k, i = self.mic.arc_movement(k, i)

    def get_micro_action(self):

        return self.mic


if __name__ == "__main__":
    micr = MicroActionFactory()
    np.savetxt('PLP.csv', micr.mic.P_LH_P, delimiter=',')
    np.savetxt('PRP.csv', micr.mic.P_RH_P, delimiter=',')
    plt.plot(micr.mic.P_LH_P[:, 0], micr.mic.P_LH_P[:, 1])
    plt.plot(micr.mic.P_RH_P[:, 0], micr.mic.P_RH_P[:, 1])
    plt.show()
