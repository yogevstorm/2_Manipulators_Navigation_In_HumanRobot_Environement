#!/usr/bin/env python3
import numpy as np


class micro_act:

    def __init__(self, r, L, z_LH, z_RH, p_LH_0, theta_box_0, dt, v, path, A_0_box, jig_pos):
        self.L = L
        self.z_LH = z_LH
        self.z_RH = z_RH
        self.p_LH_0 = p_LH_0
        self.theta_box_0 = theta_box_0
        self.dt = dt
        self.v = v
        self.r = r
        self.theta = np.array([0])
        self.dx = v * dt
        self.path = path
        self.A_0_box = A_0_box
        self.jig_pos = jig_pos
        self.t = np.array([0])
        self.d_phi = v * dt / r
        # define quartering coordinate
        self.P_LH_Q = np.array([p_LH_0])
        self.P_RH_Q = np.array([[p_LH_0[0] + L * np.cos(self.theta[0]), p_LH_0[1] + L * np.sin(self.theta[0]), z_RH]])
        # define polar coordinate
        p_L_world = self.A_0_box.dot(np.array([self.P_LH_Q[0][0], self.P_LH_Q[0][1], self.P_LH_Q[0][2], 1]))
        p_R_world = self.A_0_box.dot(np.array([self.P_RH_Q[0][0], self.P_RH_Q[0][1], self.P_RH_Q[0][2], 1]))
        # calculate angles relative to jig
        self.theta_lh = np.array([np.arctan2(p_L_world[1] - self.jig_pos[1], p_L_world[0] - self.jig_pos[0])])
        self.theta_rh = np.array([np.arctan2(p_R_world[1] - self.jig_pos[1], p_R_world[0] - self.jig_pos[0])])
        # calculate distance relative to jig
        self.R_lh = np.array([((p_L_world[0] - self.jig_pos[0]) ** 2 + (p_L_world[1] - self.jig_pos[1]) ** 2) ** 0.5])
        self.R_rh = np.array([((p_R_world[0] - self.jig_pos[0]) ** 2 + (p_R_world[1] - self.jig_pos[1]) ** 2) ** 0.5])
        # define the relative system
        self.theta_jig = np.array([-(self.theta_lh[0] + np.pi / 2)])
        self.theta_R_rel = np.array([self.theta_rh[0] + self.theta_jig[0]])
        # define new position
        self.P_LH_P = np.array([[self.jig_pos[0], self.jig_pos[1] - self.R_lh[0], self.z_LH]])
        self.P_RH_P = np.array([[self.jig_pos[0] + self.R_rh[0] * np.cos(self.theta_R_rel[0]), self.jig_pos[1] + self.R_rh[0] * np.sin(self.theta_R_rel[0]), self.z_RH]])
        self.roll_pich_yaw_pol = np.array([[0, 0, np.arctan2(self.P_RH_P[0][1] - self.P_LH_P[0][1], self.P_RH_P[0][0] - self.P_LH_P[0][0])]])

    ####################################################################################################################
    # this function describe movement above the line
    def linear_movement(self, k, i):
        while ((self.P_LH_Q[i][0] - self.path[k + 1][0]) ** 2 + (self.P_LH_Q[i][1] - self.path[k + 1][1]) ** 2) ** 0.5 > self.dx:
            i += 1
            self.t = np.append(self.t, self.t[i - 1] + self.dt)
            self.theta = np.append(self.theta, self.theta[i - 1])
            # position
            self.P_LH_Q = np.append(self.P_LH_Q, [self.P_LH_Q[i - 1][:] + self.v * self.dt * np.array([np.cos(self.theta[i]), np.sin(self.theta[i]), 0])], axis=0)
            self.P_RH_Q = np.append(self.P_RH_Q, [self.P_LH_Q[i - 1][:] + self.L * np.array([np.cos(self.theta[i]), np.sin(self.theta[i]), (self.z_RH - self.z_LH) / self.L])], axis=0)
            # get new pos
            self.get_world_coordinate()
        # cheek if the griper get to the end of the line
        if ((self.P_LH_Q[i][0] - self.path[k + 1][0]) ** 2 + (self.P_LH_Q[i][1] - self.path[k + 1][1]) ** 2) ** 0.5 <= self.dx:

            i += 1
            self.t = np.append(self.t, self.t[i - 1] + self.dt)
            self.theta = np.append(self.theta, self.theta[i - 1])
            # position
            self.P_LH_Q = np.append(self.P_LH_Q, [self.P_LH_Q[i - 1][:] + self.v * self.dt * np.array([np.cos(self.theta[i]), np.sin(self.theta[i]), 0])], axis=0)
            self.P_RH_Q = np.append(self.P_RH_Q, [self.P_LH_Q[i - 1][:] + self.L * np.array([np.cos(self.theta[i]), np.sin(self.theta[i]), (self.z_RH - self.z_LH) / self.L])], axis=0)
            # get new pos
            self.get_world_coordinate()
        return k + 1, i

    ####################################################################################################################
    # this function describe movement above semi circle
    def arc_movement(self, k, i):
        phi = 0
        phi_f = np.abs(self.path[k][4])
        theta_temp = self.theta[i]
        while phi < phi_f:
            i += 1
            self.t = np.append(self.t, self.t[i - 1] + self.dt)
            phi = phi + self.d_phi
            if self.path[k][4] > 0:
                self.theta = np.append(self.theta, [self.theta[i - 1] + self.d_phi])
            else:
                self.theta = np.append(self.theta, [self.theta[i - 1] - self.d_phi])
            # position
            self.P_LH_Q = np.append(self.P_LH_Q, [self.P_LH_Q[i - 1][:] + self.v * self.dt * np.array([np.cos(self.theta[i]), np.sin(self.theta[i]), 0])], axis=0)
            self.P_RH_Q = np.append(self.P_RH_Q, [self.P_LH_Q[i - 1][:] + self.L * np.array([np.cos(self.theta[i]), np.sin(self.theta[i]), (self.z_RH - self.z_LH) / self.L])], axis=0)
            # get new pos
            self.get_world_coordinate()
        # cheek if the griper get to the end of the arc
        if phi != phi_f:
            self.theta[i] = self.path[k][4] + theta_temp
            self.P_LH_Q[i][:] = [self.path[k + 1][0], self.path[k + 1][1], self.z_LH]
            self.P_RH_Q[i][:] = [self.P_LH_Q[i][0] + self.L * np.cos(self.theta[i]), self.P_LH_Q[i][1] + self.L * np.sin(self.theta[i]), self.z_RH]
            # get new pos
            self.P_LH_P = np.delete(self.P_LH_P, (-1), axis=0)
            self.P_RH_P = np.delete(self.P_RH_P, (-1), axis=0)
            self.theta_lh = np.delete(self.theta_lh, (-1), axis=0)
            self.theta_rh = np.delete(self.theta_rh, (-1), axis=0)
            self.R_lh = np.delete(self.R_lh, (-1), axis=0)
            self.R_rh = np.delete(self.R_rh, (-1), axis=0)
            self.theta_jig = np.delete(self.theta_jig, (-1), axis=0)
            self.theta_R_rel = np.delete(self.theta_R_rel, (-1), axis=0)
            self.roll_pich_yaw_pol = np.delete(self.roll_pich_yaw_pol, (-1), axis=0)

            self.get_world_coordinate()

        return k + 1, i

    ####################################################################################################################
    def get_world_coordinate(self):
        # define the gripper coordinate in the world
        p_L_world = self.A_0_box.dot(np.array([self.P_LH_Q[-1][0], self.P_LH_Q[-1][1], self.P_LH_Q[-1][2], 1]))
        p_R_world = self.A_0_box.dot(np.array([self.P_RH_Q[-1][0], self.P_RH_Q[-1][1], self.P_RH_Q[-1][2], 1]))
        # calculate angles relative to jig
        self.theta_lh = np.append(self.theta_lh, [np.arctan2(p_L_world[1] - self.jig_pos[1], p_L_world[0] - self.jig_pos[0])])
        self.theta_rh = np.append(self.theta_rh, [np.arctan2(p_R_world[1] - self.jig_pos[1], p_R_world[0] - self.jig_pos[0])])
        # calculate distance relative to jig
        self.R_lh = np.append(self.R_lh, [((p_L_world[0] - self.jig_pos[0]) ** 2 + (p_L_world[1] - self.jig_pos[1]) ** 2) ** 0.5])
        self.R_rh = np.append(self.R_rh, [((p_R_world[0] - self.jig_pos[0]) ** 2 + (p_R_world[1] - self.jig_pos[1]) ** 2) ** 0.5])
        # define the relative system
        self.theta_jig = np.append(self.theta_jig, [-(self.theta_lh[-1] + np.pi / 2)])
        self.theta_R_rel = np.append(self.theta_R_rel, [self.theta_rh[-1] + self.theta_jig[-1]])
        # define new position
        self.P_LH_P = np.append(self.P_LH_P, [[self.jig_pos[0], self.jig_pos[1] - self.R_lh[-1], self.z_LH]], axis=0)
        self.P_RH_P = np.append(self.P_RH_P, [[self.jig_pos[0] + self.R_rh[-1] * np.cos(self.theta_R_rel[-1]), self.jig_pos[1] + self.R_rh[-1] * np.sin(self.theta_R_rel[-1]), self.z_RH]], axis=0)
        # roll_pich_yaw_calculation
        self.roll_pich_yaw_pol = np.append(self.roll_pich_yaw_pol, [[0, 0, np.arctan2(self.P_RH_P[-1][1] - self.P_LH_P[-1][1], self.P_RH_P[-1][0] - self.P_LH_P[-1][0])]], axis=0)