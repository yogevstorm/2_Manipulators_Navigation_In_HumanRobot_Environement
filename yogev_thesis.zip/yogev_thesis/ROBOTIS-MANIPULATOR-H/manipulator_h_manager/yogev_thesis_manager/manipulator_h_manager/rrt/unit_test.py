#!/usr/bin/env python3
import numpy as np
from arm_kinematic import ArmKinematic
from trajectory_convertor import TrajectoryConvertor


def test_is_motors_angles_in_range():
    motors_angles = np.array(np.deg2rad([90, -100, -45, 60, 90, 0]))
    res = ArmKinematic.is_motors_angles_in_range(motors_angles)
    if np.all(res):
        print("test_is_motors_angles_in_range failed!")
    else:
        print("test_is_motors_angles_in_range succeed!")


def test_convert_angle_abs_value_to_less_than_pi():
    motors_angles = np.array(np.deg2rad([90, -100, -270, 60, 270, 0]))
    res = np.rad2deg(TrajectoryConvertor.convert_angle_abs_value_to_less_than_pi(motors_angles))
    if np.all(np.array([90, -100, 90, 60, -90, 0]) - res < 0.1):
        print("test_convert_angle_abs_value_to_less_than_pi succeed!")
    else:
        print("test_convert_angle_abs_value_to_less_than_pi failed!")


if __name__ == "__main__":
    test_is_motors_angles_in_range()
    test_convert_angle_abs_value_to_less_than_pi()