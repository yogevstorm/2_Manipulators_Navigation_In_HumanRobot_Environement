#!/usr/bin/env python3
import numpy as np
import ground_control as gc
from time import sleep

if __name__ == '__main__':
    # LDO madgim
    g_control = gc.ground_control(np.array([[-1.57,0,0,0.05,0.05,0.05,-1.57,0.05,0.05,0.05,0.05,0.05,0,0,0]]), resolution=0.01, with_jig=False, with_gripper=False)
    sleep(1)
    g_control.run()
