#!/usr/bin/env python3.6
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from sensor_msgs.msg import PointCloud
from std_msgs.msg import String
from std_msgs.msg import Int8
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
import heapq
from visualization_msgs.msg import MarkerArray
import time
from geometry_msgs.msg import Point
from yolo.msg import array_of_arrays
import random
import math
import copy
import numpy as np
#import cupy as np
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from std_srvs.srv import Empty
from std_msgs.msg import Float32MultiArray
from robot_markers.msg import path_msg
from robotis_controller_msgs.msg import SyncWriteItem
from std_msgs.msg import MultiArrayDimension
from scipy.spatial import distance
import ground_control as gc
import matplotlib.pyplot as plt
#np.random.seed(1)

############ main algorithm class ########################



#####################################################################
############### Kinematics Class ####################################
#####################################################################
        
class Kinematics(object):

    def __init__(self):

        self.arm1_init_point = (0.3,0.0,1.2)

        self.arm2_init_point = (-0.3,0.0,1.2)

        self.arm1_init_orientation=(3.14,0.0,3.14) # yaw pitch roll

        self.arm2_init_orientation=(0,0.0,3.14) # yaw pitch roll

        #self.arm2_init_orientation=(3.14,0.0,0) # yaw pitch roll

   
    def from_transition_matrix_to_pose(self,T):


        return (T[0][3],T[1][3],T[2][3])


  
    def forward_kinematics(self,arm_ID,joints_state_array):
        j_pos=joints_state_array
        d1=0.159
        a1=0.2659
        a2=0.03
        a3=0.134
        d3=0.258
        a4=0.03

        a5=0.08
        d4=0.12
        joint2_offset=-1.57+0.113
        joint3_offset=-0.113
        joint4_offset=1.57
        joint5_offset=0
        y1=self.arm1_init_orientation[0]
        p1=self.arm1_init_orientation[1]
        r1=self.arm1_init_orientation[2]

        y2=self.arm2_init_orientation[0]
        p2=self.arm2_init_orientation[1]
        r2=self.arm2_init_orientation[2]

      
        if(arm_ID==2):

            T_00=[[np.cos(y2)*np.cos(p2),np.cos(y2)*np.sin(p2)*np.sin(r2)-np.sin(y2)*np.cos(r2),np.cos(y2)*np.sin(p2)*np.sin(r2)+np.sin(y2)*np.sin(r2),self.arm2_init_point[0]],[np.sin(y2)*np.cos(p2),np.sin(y2)*np.sin(p2)*np.sin(r2)+np.cos(y2)*np.cos(r2),np.sin(y2)*np.sin(p2)*np.cos(r2)-np.cos(y2)*np.sin(r2),self.arm2_init_point[1]],[-np.sin(p2),np.cos(p2)*np.sin(r2),np.cos(p2)*np.cos(r2),self.arm2_init_point[2]],[0,0,0,1]]

            pointm1=self.arm2_init_point

        else:

            pointm1=self.arm1_init_point

            T_00=[[np.cos(y1)*np.cos(p1),np.cos(y1)*np.sin(p1)*np.sin(r1)-np.sin(y1)*np.cos(r1),np.cos(y1)*np.sin(p1)*np.sin(r1)+np.sin(y1)*np.sin(r1),self.arm1_init_point[0]],[np.sin(y1)*np.cos(p1),np.sin(y1)*np.sin(p1)*np.sin(r1)+np.cos(y1)*np.cos(r1),np.sin(y1)*np.sin(p1)*np.cos(r1)-np.cos(y1)*np.sin(r1),self.arm1_init_point[1]],[-np.sin(p1),np.cos(p1)*np.sin(r1),np.cos(p1)*np.cos(r1),self.arm1_init_point[2]],[0,0,0,1]]
           
        T_01=np.array([[np.cos(j_pos[0]),0,-np.sin(j_pos[0]),0],[np.sin(j_pos[0]),0,np.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]])
    
        T_01=np.linalg.multi_dot([T_00,T_01])

        #T_01_l_1=[[1,0,0,np.cos(j_pos[0])*a5],[0,1,0,0],[0,0,1,np.sin(j_pos[0])*a5],[0,0,0,1]]

        T_01_l_1=[[1,0,0,0],[0,1,0,0],[0,0,1,a5],[0,0,0,1]]

        T_01_l_2=[[1,0,0,0],[0,1,0,0],[0,0,1,-a5],[0,0,0,1]]

        point0=self.from_transition_matrix_to_pose(T_01)

        T_01_l=np.linalg.multi_dot([T_01,T_01_l_1])

        point7=self.from_transition_matrix_to_pose(T_01_l)

        T_01_l=np.linalg.multi_dot([T_01,T_01_l_2])

        point8=self.from_transition_matrix_to_pose(T_01_l)

        T_12=np.array([[np.cos(j_pos[1]+joint2_offset),-np.sin(j_pos[1]+joint2_offset),0,a1*np.cos(j_pos[1]+joint2_offset)],[np.sin(j_pos[1]+joint2_offset),np.cos(j_pos[1]+joint2_offset),0,a1*np.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]])

        T_02=np.linalg.multi_dot([T_01,T_12])
         
        point1=self.from_transition_matrix_to_pose(T_02)

        T_23=[[np.cos(j_pos[2]+joint3_offset),0,-np.sin(j_pos[2]+joint3_offset),a2*np.cos(j_pos[2]+joint3_offset)],[np.sin(j_pos[2]+joint3_offset),0,np.cos(j_pos[2]+joint3_offset),a2*np.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

        T_03=np.linalg.multi_dot([T_01,T_12,T_23])
           
        point2=self.from_transition_matrix_to_pose(T_03)

        T_34=[[np.cos(j_pos[3]),0,np.sin(j_pos[3]),0],[np.sin(j_pos[3]),0,-np.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

        T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        
        point3=self.from_transition_matrix_to_pose(T_04)

        T_45=[[np.cos(j_pos[4]+joint4_offset),0,-np.sin(j_pos[4]+joint4_offset),a3*np.cos(j_pos[4]+joint4_offset)],[np.sin(j_pos[4]+joint4_offset),0,np.cos(j_pos[4]+joint4_offset),a3*np.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
        T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
           
        point4=self.from_transition_matrix_to_pose(T_05)

        T_56_l_1=[[1,0,0,d4],[0,1,0,0],[0,0,1,0],[0,0,0,1]]

        T_56_l_2=[[1,0,0,0],[0,1,0,np.cos(j_pos[5])*a4],[0,0,1,np.sin(j_pos[5])*a4],[0,0,0,1]]

        T_56_l=np.linalg.multi_dot([T_56_l_1,T_56_l_2])

        T_56_r_1=[[1,0,0,d4],[0,1,0,0],[0,0,1,0],[0,0,0,1]]

        T_56_r_2=[[1,0,0,0],[0,1,0,np.cos(j_pos[5]+3.14)*a4],[0,0,1,np.sin(j_pos[5]+3.14)*a4],[0,0,0,1]]

        T_56_r=np.linalg.multi_dot([T_56_r_1,T_56_r_2])

        T_06_l=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45,T_56_l])

        point5=self.from_transition_matrix_to_pose(T_06_l)

        T_06_r=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45,T_56_r])

        point6=self.from_transition_matrix_to_pose(T_06_r)

        return [pointm1,point0,point1,point2,point3,point4,point5,point6,point7,point8]




    def inverse_kinematics(self,arm_id,pos, ori, i=0, t6=0, t1=0):

        pos_array=[pos[0],pos[1],pos[2]]

        if(arm_id==1):

            pos_array[0]=pos_array[0]-self.arm1_init_point[0]

            pos_array[1]=pos_array[1]-self.arm1_init_point[1]

            pos_array[2]=pos_array[2]-self.arm1_init_point[2]

            

            R_x = np.array([[1 , 0 , 0] , [0 , np.cos(self.arm1_init_orientation[2]) ,-np.sin(self.arm1_init_orientation[2]) ] , [0 , np.sin(self.arm1_init_orientation[2]) , np.cos(self.arm1_init_orientation[2])]])

            R_y = np.array([[np.cos(self.arm1_init_orientation[1]) , 0 , np.sin(self.arm1_init_orientation[1])] , [0 , 1, 0 ] , [-np.sin(self.arm1_init_orientation[1]) , 0 , np.cos(self.arm1_init_orientation[1])]])

            R_z = np.array([[np.cos(self.arm1_init_orientation[0]) , -np.sin(self.arm1_init_orientation[0]) , 0] , [np.sin(self.arm1_init_orientation[0]) , np.cos(self.arm1_init_orientation[0]) , 0] , [0 , 0 , 1]])

        else:

            pos_array[0]=pos_array[0]-self.arm2_init_point[0]

            pos_array[1]=pos_array[1]-self.arm2_init_point[1]

            pos_array[2]=pos_array[2]-self.arm2_init_point[2]

            R_x = np.array([[1 , 0 , 0] , [0 , np.cos(self.arm2_init_orientation[2]) ,-np.sin(self.arm2_init_orientation[2]) ] , [0 , np.sin(self.arm2_init_orientation[2]) , np.cos(self.arm2_init_orientation[2])]])

            R_y = np.array([[np.cos(self.arm2_init_orientation[1]) , 0 , np.sin(self.arm2_init_orientation[1])] , [0 , 1, 0 ] , [-np.sin(self.arm2_init_orientation[1]) , 0 , np.cos(self.arm2_init_orientation[1])]])

            R_z = np.array([[np.cos(self.arm2_init_orientation[0]) , -np.sin(self.arm2_init_orientation[0]) , 0] , [np.sin(self.arm2_init_orientation[0]) , np.cos(self.arm2_init_orientation[0]) , 0] , [0 , 0 , 1]])

        R=np.linalg.multi_dot([R_z,R_y,R_x])

        pos_array=np.dot(R,pos_array)


        ori=np.dot(R,ori)


        gripper_length = 178.61 + 50
        gripper_length = 50

        #gripper_length = 0

        gripper_LDO_length = 12 + 25

        fas = [1.4576, 1.3419,np.pi]

        l_i = [0.159, 0.2656991, 0.2597383, 0.123 +0.011+ gripper_length/1000.0]

        s = np.array(
            [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1]])

        R06 = np.array([[-np.sin(ori[1]), -np.sin(ori[2]) * np.cos(ori[1]), np.cos(ori[1]) * np.cos(ori[2]), 0],
                        [np.sin(ori[0]) * np.cos(ori[1]),
                         -np.sin(ori[0]) * np.sin(ori[1]) * np.sin(ori[2]) + np.cos(ori[0]) * np.cos(ori[2]),
                         np.sin(ori[0]) * np.sin(ori[1]) * np.cos(ori[2]) + np.sin(ori[2]) * np.cos(ori[0]), 0],
                        [-np.cos(ori[0]) * np.cos(ori[1]),
                         np.sin(ori[0]) * np.cos(ori[2]) + np.sin(ori[1]) * np.sin(ori[2]) * np.cos(ori[0]),
                         np.sin(ori[0]) * np.sin(ori[2]) - np.sin(ori[1]) * np.cos(ori[0]) * np.cos(ori[2]), 0], [0, 0, 0, 1]])

        pc = np.array([[pos_array[0] - (l_i[3]) * np.cos(ori[1]) * np.cos(ori[2])],
                       [pos_array[1] - (l_i[3]) * (
                               (np.sin(ori[0])) * np.sin(ori[1]) * np.cos(ori[2]) + np.sin(ori[2]) * np.cos(ori[0]))],
                       [pos_array[2] - (l_i[3]) * (
                               (np.sin(ori[0])) * np.sin(ori[2]) - np.sin(ori[1]) * np.cos(ori[0]) * np.cos(ori[2]))]])

        R06 = R06[:3, :3]

        gova = pc[2, 0] - l_i[0]

        yeter = s[i, 0] * (pc[0, 0] ** 2 + pc[1, 0] ** 2) ** 0.5

        D = ((yeter ** 2 + gova ** 2 - l_i[1] ** 2 - l_i[2] ** 2) / (2 * l_i[1] * l_i[2]))

        if pc[0, 0] == 0 and pc[1, 0] == 0:

            t1 = t1
        else:

            t1 = np.arctan2(pc[1, 0] / (yeter), pc[0, 0] / (yeter))

        if D > 1:

            raise ArmCannotReachPosition('Arm cannot reach position')

        t3 = np.arctan2(s[i, 1] * (1 - D ** 2) ** 0.5, D)

        t2 = -(np.arctan2(gova, yeter) - np.arctan2(l_i[2] * np.sin(-t3), l_i[1] + l_i[2] * np.cos(-t3)))

        t3 = t3 - fas[1]

        t2 = t2 + fas[0]

        R03 = np.array([[-np.sin(t2 + t3) * np.cos(t1), -np.sin(t1), np.cos(t1) * np.cos(t2 + t3)],
                        [-np.sin(t1) * np.sin(t2 + t3), np.cos(t1), np.sin(t1) * np.cos(t2 + t3)],
                        [-np.cos(t2 + t3), 0, -np.sin(t2 + t3)]])

        # http://aranne5.bgu.ac.il/Free_publications/mavo-lerobotica.pdf
        R36 = np.dot(R03.T, R06)

        st5 = -s[i, 2] * (R36[0, 2] ** 2 + R36[1, 2] ** 2) ** 0.5

        if abs(st5) < 1e-4:

            t5 = 0

            t6 = t6

            t4 = np.arctan2(R36[1, 0], R36[0, 0]) + t6

        else:

            t5 = np.arctan2(st5, R36[2, 2])

            t4 = np.arctan2(R36[1, 2] / st5, R36[0, 2] / st5)

            t6 = np.arctan2(R36[2, 1] / st5, -R36[2, 0] / st5)
        
        

        theta_values = np.array([[t1, t2, t3, t4, t5, t6]])
        
        if np.isnan(np.sum(theta_values)):

            raise ArmCannotReachPosition('Arm cannot reach position')

        return theta_values


class ArmCannotReachPosition(Exception):
    """Raised when the arm cannot reach the position target"""
    pass



def constrain(pose):

        if(abs(pose[0])>3.14):

                pose[0]=3.14*np.sign(pose[0])

        if(abs(pose[1])>1.55):

                pose[1]=1.55*np.sign(pose[1])

        if(abs(pose[2])>1.55):

                pose[2]=1.55*np.sign(pose[2])

        if(abs(pose[3])>1.55):

                pose[3]=1.55*np.sign(pose[3])

        if(abs(pose[4])>1.55):

                pose[4]=1.55*np.sign(pose[4])

        if(abs(pose[5])>1.55):

                pose[5]=1.55*np.sign(pose[5])
        
        if(abs(pose[6])>1.55):

                pose[6]=1.55*np.sign(pose[6])

        if(abs(pose[7])>3.14):

                pose[7]=3.14*np.sign(pose[7])

        if(abs(pose[8])>1.55):

                pose[8]=1.55*np.sign(pose[8])

        if(abs(pose[9])>1.55):

                pose[9]=1.55*np.sign(pose[9])

        if(abs(pose[10])>1.55):

                pose[10]=1.55*np.sign(pose[10])
        
        if(abs(pose[11])>1.55):

                pose[11]=1.55*np.sign(pose[11])

        if(abs(pose[12])>1.55):

                pose[12]=1.55*np.sign(pose[12])

        if(abs(pose[13])>1):

                pose[13]=1*np.sign(pose[13])

        return pose



def set_joints_state(pose):


    pose_for_joints=np.array([[pose[0],pose[1],pose[2],pose[3],pose[4],pose[5],pose[7],pose[8],pose[9],pose[10],pose[11],pose[12],0,0,0]])

    g_control = gc.ground_control(pose_for_joints, resolution=0.01, with_jig=False, with_gripper=False)

    g_control.run()





def Transformation_Matrix(pos,ori,init_point):

    point_return=Point()

    R_x = np.array([[1 , 0 , 0] , [0 , np.cos(ori[0]) ,-np.sin(ori[0]) ] , [0 , np.sin(ori[0]) , np.cos(ori[0])]])

    R_y = np.array([[np.cos(ori[1]) , 0 , np.sin(ori[1])] , [0 , 1, 0 ] , [-np.sin(ori[1]) , 0 , np.cos(ori[1])]])

    R_z = np.array([[np.cos(ori[2]) , -np.sin(ori[2]) , 0] , [np.sin(ori[2]) , np.cos(ori[2]) , 0] , [0 , 0 , 1]])

    R=np.linalg.multi_dot([R_z,R_y,R_x])

    p_new=np.dot(R,pos)

    point_new=(p_new[0]+init_point[0],p_new[1]+init_point[1],p_new[2]+init_point[2])

    point_return = point_new[0] , point_new[1] , point_new[2]

    return point_return
       

      




######################################
########## main function #############
######################################


def main():

    rospy.init_node('pickommerece', anonymous=True)

    rate = rospy.Rate(10)

    cat_pose_in_camera_world = (-0.06,0.0,0.448)

    orientation_transform=(-1.57,0,-3.14) # orientation from robot world to camera world

    init_point=(0.0,0.34,0.53)  # distance in robot world to camera world

    cat_pose_in_robot_world = Transformation_Matrix(cat_pose_in_camera_world,orientation_transform,init_point)

    #cat_pose_in_robot_world = (0.05,0,0.4)

    print(cat_pose_in_robot_world)

    kinematics=Kinematics()

    inv_arm1=kinematics.inverse_kinematics(1,cat_pose_in_robot_world, [-1.57,0,-1.57], 0)[0]

    goal_arm1=[inv_arm1[0],inv_arm1[1],inv_arm1[2],inv_arm1[3],inv_arm1[4],inv_arm1[5],0.5]

    goal_arm2=[-1.57,0,0,0,0,0,0]

    point_to_publish=np.array([goal_arm1[0],goal_arm1[1],goal_arm1[2],goal_arm1[3],goal_arm1[4],goal_arm1[5],goal_arm1[6],
                
        goal_arm2[0],goal_arm2[1],goal_arm2[2],goal_arm2[3],goal_arm2[4],goal_arm2[5],goal_arm2[6]])

    set_joints_state(point_to_publish)




    



    





if __name__ == '__main__':
    try:
       main()
    except rospy.ROSInterruptException:
        pass