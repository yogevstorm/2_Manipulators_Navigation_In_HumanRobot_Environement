#!/usr/bin/env python
# license removed for brevity
import rospy
from sensor_msgs.msg import JointState
from manipulator_h_base_module_msgs.msg import JointPose
from sensor_msgs.msg import Joy
from std_msgs.msg import String
import heapq
from visualization_msgs.msg import MarkerArray
import time
#from random import random
from collections import deque

import random
import os
import sys
import math
import copy
import numpy as np

from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from std_srvs.srv import Empty


global joint_state_data,joint_state_data_arm2

global occupied_cells

global x,start_button

joint_state_data=JointState()
joint_state_data_arm2=JointState()
occupied_cells=MarkerArray()
joint_state_data.position=np.zeros(6)
joint_state_data_arm2.position=np.zeros(6)
x,start_button=0,0






class Node(object):
    def __init__(self, n):
        self.pos = n
        self.parent = None
        self.flag = "VALID"


class Edge:
    def __init__(self, n_p, n_c):
        self.parent = n_p
        self.child = n_c
        self.flag = "VALID"


class DynamicRrt(object):
    def __init__(self, s_start, s_goal, step_len, goal_sample_rate, waypoint_sample_rate, iter_max,obstacles_array,search_radius,initial_path_improvement,replanning_path_improvement):
        self.s_start = Node(s_start)
        self.s_goal = Node(s_goal)
        self.step_len = step_len
        self.goal_sample_rate = goal_sample_rate
        self.waypoint_sample_rate = waypoint_sample_rate
        self.iter_max = iter_max
        self.vertex = [self.s_start]
        self.vertex_old = []
        self.vertex_new = []
        self.edges = []
        self.search_radius = search_radius
        self.kinematics=Kinematics()
        self.initial_path_improvement=initial_path_improvement
        self.replanning_path_improvement=replanning_path_improvement



        #self.x_range = self.env.x_range
        #self.y_range = self.env.y_range
        self.range_1 = (-3.14,3.14)
        self.range_2 = (-1.57,1.57)
        self.range_3 = (-1.57,1.57)
        self.range_4 = (-1.57,1.57)
        self.range_5 = (-1.57,1.57)
        self.num_points_in_each_line_for_obstacle_avoidance=1
        self.path = []
        self.waypoints = []
        self.collision_dist=0.14
        self.obstacles_array=obstacles_array




    
    def planning(self):

        if(self.is_collision(self.s_start,self.obstacles_array,self.kinematics)):
            print('close to and obstacle')
            
        iter_max=self.iter_max
        i=0
        found_path=False
        while i<iter_max:
            node_rand = self.generate_random_node(self.goal_sample_rate)
            node_near = self.nearest_neighbor(self.vertex, node_rand)

            node_new = self.new_state(node_near, node_rand)

            if node_new and not self.is_collision(node_new,self.obstacles_array,self.kinematics):
                #dist, _ = self.get_distance_and_direction(node_new, self.s_goal)
                neighbor_index = self.find_near_neighbor(node_new)
                self.vertex.append(node_new)
                
                if(found_path==False):

                    dist, _ = self.get_distance_and_direction(node_new, self.s_goal)

                if neighbor_index:
                    self.choose_parent(node_new, neighbor_index)
                    self.rewire(node_new, neighbor_index)
                    #self.edges.append(Edge(node_near, node_new))

                if dist <= self.step_len:

                    found_path=True
                    dist=10

                    #print("found_path , start improving path")
                    i=iter_max-self.initial_path_improvement
                    #index = self.search_goal_parent()
                    #self.path = self.extract_path(self.vertex[index])
                    #self.waypoints = self.extract_waypoint(self.vertex[index])
        
                    #return self.path

            i+=1
        self.edges = [Edge(node.parent, node) for node in self.vertex[1:len(self.vertex)]]
        index = self.search_goal_parent()
        self.path = self.extract_path(self.vertex[index])
        self.waypoints = self.extract_waypoint(self.vertex[index])
        print("done improving initial path")
        return self.path


    def search_goal_parent(self):
        dist_list = [np.linalg.norm(np.array(n.pos)-np.array(self.s_goal.pos)) for n in self.vertex]
        node_index = [i for i in range(len(dist_list)) if dist_list[i] <= self.step_len]

        if len(node_index) > 0:
            cost_list = [dist_list[i] + self.cost(self.vertex[i]) for i in node_index]
            return node_index[int(np.argmin(cost_list))]

        return len(self.vertex) - 1
    
    


    def rewire(self, node_new, neighbor_index):
        for i in neighbor_index:
            node_neighbor = self.vertex[i]

            if self.cost(node_neighbor) > self.get_new_cost(node_new, node_neighbor):
                node_neighbor.parent = node_new


    def find_near_neighbor(self, node_new):
        n = len(self.vertex) + 1
        r = min(self.search_radius * np.sqrt((np.log(n) / n)), self.step_len)

        dist_table = [np.linalg.norm(np.array(nd.pos)-np.array(node_new.pos)) for nd in self.vertex]
        dist_table_index = [ind for ind in range(len(dist_table)) if dist_table[ind] <= r]

        return dist_table_index


    def choose_parent(self, node_new, neighbor_index):
        cost = [self.get_new_cost(self.vertex[i], node_new) for i in neighbor_index]

        cost_min_index = neighbor_index[int(np.argmin(cost))]
        node_new.parent = self.vertex[cost_min_index]


    def get_new_cost(self, node_start, node_end):
        dist, _ = self.get_distance_and_direction(node_start, node_end)

        return self.cost(node_start) + dist


    def cost(self,node_p):
        node = node_p
        cost = 0.0

        while node.parent:
            cost += np.linalg.norm(np.array(node.pos)-np.array(node.parent.pos))
            node = node.parent

        return cost


    def is_obstacle_in_path(self):
        for node in self.waypoints:
            if self.is_collision(node, self.obstacles_array,self.kinematics):
                return True
        return False


    def InvalidateNodes(self):
        #print(len(self.edges))
        for edge in self.edges:
            if self.is_collision(edge.parent, self.obstacles_array,self.kinematics):
                edge.child.flag = "INVALID"

    
    def is_collision(self,node,obstacles_array,kinematics):

        arm1_near_obstacle=self.is_arm1_near_obstacle(node,obstacles_array,kinematics)

        arm2_near_obstacle=self.is_arm2_near_obstacle(node,obstacles_array,kinematics)

        arm1_near_arm2=self.is_arm1_near_arm2(node,kinematics)

        if((arm1_near_obstacle==True) or (arm2_near_obstacle==True) or (arm1_near_arm2==True)):
            return True

        return False



    def is_arm1_near_obstacle(self,node,obstacles_array,kinematics):
        
        joint0_point=kinematics.forward_kinematics(1,0,[node.pos[0]])
        joint1_point=kinematics.forward_kinematics(1,1,[node.pos[0],node.pos[1]])
        joint2_point=kinematics.forward_kinematics(1,2,[node.pos[0],node.pos[1],node.pos[2]])
        joint3_point=kinematics.forward_kinematics(1,3,[node.pos[0],node.pos[1],node.pos[2],node.pos[3]])
        joint4_point=kinematics.forward_kinematics(1,4,[node.pos[0],node.pos[1],node.pos[2],node.pos[3],node.pos[4]])

        num_points=self.num_points_in_each_line_for_obstacle_avoidance

        joint_points_array=[getEquidistantPoints(joint0_point, joint1_point, num_points),getEquidistantPoints(joint1_point, joint2_point, num_points),getEquidistantPoints(joint2_point, joint3_point, num_points),getEquidistantPoints(joint3_point, joint4_point, num_points)]
        for line in joint_points_array:
            for joint_point in line:
                for obs in obstacles_array:
                    obs_point=[obs.x,obs.y,obs.z]
                    if(distance_between_2_points(obs_point,joint_point)<self.collision_dist):
                        return True


    def is_arm2_near_obstacle(self,node,obstacles_array,kinematics):
        joint0_point_arm2=kinematics.forward_kinematics(2,0,[node.pos[5]])
        joint1_point_arm2=kinematics.forward_kinematics(2,1,[node.pos[5],node.pos[6]])
        joint2_point_arm2=kinematics.forward_kinematics(2,2,[node.pos[5],node.pos[6],node.pos[7]])
        joint3_point_arm2=kinematics.forward_kinematics(2,3,[node.pos[5],node.pos[6],node.pos[7],node.pos[8]])
        joint4_point_arm2=kinematics.forward_kinematics(2,4,[node.pos[5],node.pos[6],node.pos[7],node.pos[8],node.pos[9]])
        joint_points_array_arm2=[joint1_point_arm2,joint2_point_arm2,joint3_point_arm2,joint4_point_arm2]

        num_points=self.num_points_in_each_line_for_obstacle_avoidance

        joint_points_array_arm2=[getEquidistantPoints(joint0_point_arm2, joint1_point_arm2, num_points),getEquidistantPoints(joint1_point_arm2, joint2_point_arm2, num_points),getEquidistantPoints(joint2_point_arm2, joint3_point_arm2, num_points),getEquidistantPoints(joint3_point_arm2, joint4_point_arm2, num_points)]

        for line in joint_points_array_arm2:
            for joint_point in line:
                for obs in obstacles_array:
                    obs_point=[obs.x,obs.y,obs.z]
                    if(distance_between_2_points(obs_point,joint_point)<self.collision_dist):
                        return True


    def is_arm1_near_arm2(self,node,kinematics):
        num_points=self.num_points_in_each_line_for_obstacle_avoidance
        joint0_point=kinematics.forward_kinematics(1,0,[node.pos[0]])
        joint1_point=kinematics.forward_kinematics(1,1,[node.pos[0],node.pos[1]])
        joint2_point=kinematics.forward_kinematics(1,2,[node.pos[0],node.pos[1],node.pos[2]])
        joint3_point=kinematics.forward_kinematics(1,3,[node.pos[0],node.pos[1],node.pos[2],node.pos[3]])
        joint4_point=kinematics.forward_kinematics(1,4,[node.pos[0],node.pos[1],node.pos[2],node.pos[3],node.pos[4]])
        joint_points_array_arm1=[getEquidistantPoints(joint0_point, joint1_point, num_points),getEquidistantPoints(joint1_point, joint2_point, num_points),getEquidistantPoints(joint2_point, joint3_point, num_points),getEquidistantPoints(joint3_point, joint4_point, num_points)]
  

        joint0_point_arm2=kinematics.forward_kinematics(2,0,[node.pos[5]])
        joint1_point_arm2=kinematics.forward_kinematics(2,1,[node.pos[5],node.pos[6]])
        joint2_point_arm2=kinematics.forward_kinematics(2,2,[node.pos[5],node.pos[6],node.pos[7]])
        joint3_point_arm2=kinematics.forward_kinematics(2,3,[node.pos[5],node.pos[6],node.pos[7],node.pos[8]])
        joint4_point_arm2=kinematics.forward_kinematics(2,4,[node.pos[5],node.pos[6],node.pos[7],node.pos[8],node.pos[9]])
        joint_points_array_arm2=[joint1_point_arm2,joint2_point_arm2,joint3_point_arm2,joint4_point_arm2]

        

        joint_points_array_arm2=[getEquidistantPoints(joint0_point_arm2, joint1_point_arm2, num_points),getEquidistantPoints(joint1_point_arm2, joint2_point_arm2, num_points),getEquidistantPoints(joint2_point_arm2, joint3_point_arm2, num_points),getEquidistantPoints(joint3_point_arm2, joint4_point_arm2, num_points)]


        for line_arm1 in joint_points_array_arm1:
            for joint_point_arm1 in line_arm1:
                for line_arm2 in joint_points_array_arm2:
                    for joint_point_arm2 in line_arm2:
                        if(distance_between_2_points(joint_point_arm1,joint_point_arm2)<self.collision_dist):
                            return True
        

            


    def is_path_invalid(self):
        for node in self.waypoints:
            if node.flag == "INVALID":
                return True

        return False





    def replanning(self,start_node):
        global occupied_cells,joint_state_data,joint_state_data_arm2
        self.TrimRRT()
        i=0
        iter_max=self.iter_max
        found_path=False
        while i<iter_max:
        #for i in range(self.iter_max):
            node_rand = self.generate_random_node_replanning(self.goal_sample_rate, self.waypoint_sample_rate)
            #node_rand = self.generate_random_node2()
            node_near = self.nearest_neighbor(self.vertex, node_rand)
            node_new = self.new_state(node_near, node_rand)

            if(i==iter_max-1 and found_path==False):
                rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
                clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
                clear_octomap()
                time.sleep(0.2)
                self.obstacles_array=obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data.position,joint_state_data_arm2.position,self.kinematics)
                print("didnt find available path")
                self.vertex = [self.s_start]
                self.edges=[]
                #self.replanning()
                i=0

            

            if node_new and not self.is_collision(node_new,self.obstacles_array,self.kinematics):                
                neighbor_index = self.find_near_neighbor(node_new)

                if(found_path==False):
                
                    dist, _ = self.get_distance_and_direction(node_new, self.s_goal)

                self.vertex.append(node_new)
                

                if neighbor_index:
                    self.choose_parent(node_new, neighbor_index)

                    self.rewire(node_new, neighbor_index)
                    
                    #self.edges.append(Edge(node_near, node_new))

                if dist <= self.step_len:

                    found_path=True

                    dist=10

                    i=iter_max-self.replanning_path_improvement

                  


            

            i+=1
        self.edges = [Edge(node.parent, node) for node in self.vertex[1:len(self.vertex)]]
       
        index = self.search_goal_parent()
        self.path = self.extract_path_replanning(self.vertex[index],start_node)
        self.waypoints = self.extract_waypoint(self.vertex[index])


        print("done improving replanned path")
        
        return self.path,self.waypoints

    def TrimRRT(self):
        for i in range(1, len(self.vertex)):
            node = self.vertex[i]
            node_p = node.parent
            #if(node_p==self.s_start):
                #node_p.flag="VALID"

            if node_p.flag == "INVALID":
                node.flag = "INVALID"

        self.vertex = [node for node in self.vertex if node.flag == "VALID"]
        self.vertex_old = copy.deepcopy(self.vertex)
        self.edges = [Edge(node.parent, node) for node in self.vertex[1:len(self.vertex)]]

    def generate_random_node(self, goal_sample_rate):
        #delta = self.utils.delta
        delta=0.1

        if np.random.random() > goal_sample_rate:
            return Node((np.random.uniform(self.range_1[0] + delta, self.range_1[1] - delta),
                         np.random.uniform(self.range_2[0] + delta, self.range_2[1] - delta),
                         np.random.uniform(self.range_3[0] + delta, self.range_3[1] - delta),
                         np.random.uniform(self.range_4[0] + delta, self.range_4[1] - delta),
                         np.random.uniform(self.range_5[0] + delta, self.range_5[1] - delta),
                         np.random.uniform(self.range_1[0] + delta, self.range_1[1] - delta),
                         np.random.uniform(self.range_2[0] + delta, self.range_2[1] - delta),
                         np.random.uniform(self.range_3[0] + delta, self.range_3[1] - delta),
                         np.random.uniform(self.range_4[0] + delta, self.range_4[1] - delta),
                         np.random.uniform(self.range_5[0] + delta, self.range_5[1] - delta)))

        return self.s_goal


    def generate_random_node2(self):
        rx=(random.randint(-314, 314)/100.0)
        ry=(random.randint(-157, 157)/100.0)
      
        return Node((rx,ry))

    def generate_random_node_replanning(self, goal_sample_rate, waypoint_sample_rate):
        #delta = self.utils.delta
        delta=0.1
        p = np.random.random()
        if p < goal_sample_rate:
            return self.s_goal
        elif goal_sample_rate < p < goal_sample_rate + waypoint_sample_rate:
            return self.waypoints[np.random.randint(0, len(self.waypoints) - 1)]
        else:
            return Node((np.random.uniform(self.range_1[0] + delta, self.range_1[1] - delta),
                         np.random.uniform(self.range_2[0] + delta, self.range_2[1] - delta),
                         np.random.uniform(self.range_3[0] + delta, self.range_3[1] - delta),
                         np.random.uniform(self.range_4[0] + delta, self.range_4[1] - delta),
                         np.random.uniform(self.range_5[0] + delta, self.range_5[1] - delta),
                         np.random.uniform(self.range_1[0] + delta, self.range_1[1] - delta),
                         np.random.uniform(self.range_2[0] + delta, self.range_2[1] - delta),
                         np.random.uniform(self.range_3[0] + delta, self.range_3[1] - delta),
                         np.random.uniform(self.range_4[0] + delta, self.range_4[1] - delta),
                         np.random.uniform(self.range_5[0] + delta, self.range_5[1] - delta)))

    #@staticmethod
    def nearest_neighbor(self,node_list, n):
        #return node_list[int(np.argmin([np.hypot(nd.pos[0] - n.pos[0], nd.pos[1] - n.pos[1] ,nd.pos[2] - n.pos[2])
                                        #for nd in node_list]))]
        return node_list[int(np.argmin([np.linalg.norm(np.array(nd.pos) - np.array(n.pos))
                                        for nd in node_list]))]

    def new_state(self, node_start, node_end):

        #print(node_start.pos)

        dist, direction = self.get_distance_and_direction(node_start, node_end)

        dist = min(self.step_len, dist)
        node_new = Node(node_start.pos+dist*direction)
        node_new.parent = node_start

        return node_new

    def extract_path(self, node_end):
        path = [(self.s_goal.pos[0], self.s_goal.pos[1] , self.s_goal.pos[2],self.s_goal.pos[3],self.s_goal.pos[4],self.s_goal.pos[5],self.s_goal.pos[6],self.s_goal.pos[7],self.s_goal.pos[8],self.s_goal.pos[9])]
        node_now = node_end

        while node_now.parent is not None:

            node_now = node_now.parent
            path.append((node_now.pos[0], node_now.pos[1] , node_now.pos[2],node_now.pos[3],node_now.pos[4],node_now.pos[5],node_now.pos[6],node_now.pos[7],node_now.pos[8],node_now.pos[9]))

        return path


    def extract_path_replanning(self, node_end,node_start):
        path = [(self.s_goal.pos[0], self.s_goal.pos[1] , self.s_goal.pos[2],self.s_goal.pos[3],self.s_goal.pos[4],self.s_goal.pos[5],self.s_goal.pos[6],self.s_goal.pos[7],self.s_goal.pos[8],self.s_goal.pos[9])]
        node_now = node_start
        node_start_ancestors=[node_now]
        #path_nodes=[self.s_goal]

        while node_now.parent is not None:
            node_now = node_now.parent
            node_start_ancestors.append(node_now)
            #print(" ancestor ",node_now.pos)

        node_cur=node_end

        #print(node_start_ancestors)

        while node_cur.parent is not None:
            node_cur = node_cur.parent
            if(node_cur==node_start):

                #print("doneee")

                path.append((node_cur.pos[0], node_cur.pos[1] , node_cur.pos[2],node_cur.pos[3],node_cur.pos[4],node_cur.pos[5],node_cur.pos[6],node_cur.pos[7],node_cur.pos[8],node_cur.pos[9]))
                #print(" path ",path)
                return path

            #print(" is node_now in node_start_ancestors ",node_cur in node_start_ancestors)

            if((node_cur in node_start_ancestors)==False):
                #print(" hiiii  ")
                #print("  append to path  ",node_now.pos[0], node_now.pos[1] , node_now.pos[2],node_now.pos[3],node_now.pos[4],node_now.pos[5],node_now.pos[6],node_now.pos[7],node_now.pos[8],node_now.pos[9])
                path.append((node_cur.pos[0], node_cur.pos[1] , node_cur.pos[2],node_cur.pos[3],node_cur.pos[4],node_cur.pos[5],node_cur.pos[6],node_cur.pos[7],node_cur.pos[8],node_cur.pos[9]))

            if(node_cur in node_start_ancestors):
                #print("truee ",node_now in node_start_ancestors)
                common_ancestor=node_start_ancestors.index(node_cur)
                print(" common ancestor  ",node_start_ancestors[common_ancestor].pos)

                #print("   path till now ",path)

                for i in range(0,common_ancestor):
                    path.append(node_start_ancestors[common_ancestor-i].pos)
                
                #print("  path   ",path)

                return path
        

    def extract_waypoint(self, node_end):
        waypoints = [self.s_goal]
        node_now = node_end

        while node_now.parent is not None:
            node_now = node_now.parent
            waypoints.append(node_now)

        return waypoints

    #@staticmethod
    def get_distance_and_direction(self,node_start, node_end):
        direction=np.array(node_end.pos) - np.array(node_start.pos)
        dist = np.linalg.norm(direction)
        if(dist==0):
            pass

        else:

            direction=direction/dist

        return dist,direction

    

    def plot_grid(self, name):

        
        plt.plot(self.s_start.pos[0], self.s_start.pos[1], "bs", linewidth=3)
        plt.plot(self.s_goal.pos[0], self.s_goal.pos[1], "gs", linewidth=3)

        plt.title(name)
        plt.axis("equal")

    def plot_visited(self, animation=True):
        if animation:
            count = 0
            for node in self.vertex:
                count += 1
                if node.parent:
                    plt.plot([node.parent.pos[0], node.pos[0]], [node.parent.pos[1], node.pos[1]], "-g")
                    plt.gcf().canvas.mpl_connect('key_release_event',
                                                 lambda event:
                                                 [exit(0) if event.key == 'escape' else None])
                    if count % 10 == 0:
                        #plt.pause(0.001)
                        plt.pause(0.01)
        else:
            for node in self.vertex:
                if node.parent:
                    plt.plot([node.parent.x, node.x], [node.parent.y, node.y], "-g")

    def plot_vertex_old(self):
        for node in self.vertex_old:
            if node.parent:
                plt.plot([node.parent.x, node.x], [node.parent.y, node.y], "-g")

    def plot_vertex_new(self):
        count = 0

        for node in self.vertex_new:
            count += 1
            if node.parent:
                plt.plot([node.parent.x, node.x], [node.parent.y, node.y], color='darkorange')
            




class Kinematics(object):

    def __init__(self):

        self.arm1_init_point = (0.35,0.0,0.0)

        self.arm2_init_point = (-0.35,0.0,0.0)

        self.arm1_init_orientation=(3.14,0.0,0.0) # yaw pitch roll

        self.arm2_init_orientation=(0.0,0.0,0.0) # yaw pitch roll

   
    def from_transition_matrix_to_pose(self,T):


        return (T[0][3],T[1][3],T[2][3])



  
    def forward_kinematics(self,arm_ID,joint_ID,joints_state_array):
        j_pos=joints_state_array
        d1=0.159
        a1=0.2659
        a2=0.03
        a3=0.134
        d3=0.258
        joint2_offset=-1.57+0.113
        joint3_offset=-0.113
        joint4_offset=1.57
        y1=self.arm1_init_orientation[0]
        p1=self.arm1_init_orientation[1]
        r1=self.arm1_init_orientation[2]

        y2=self.arm2_init_orientation[0]
        p2=self.arm2_init_orientation[1]
        r2=self.arm2_init_orientation[2]

      
        if(arm_ID==2):

            T_00=[[np.cos(y2)*np.cos(p2),np.cos(y2)*np.sin(p2)*np.sin(r2)-np.sin(y2)*np.cos(r2),np.cos(y2)*np.sin(p2)*np.sin(r2)+np.sin(y2)*np.sin(r2),self.arm2_init_point[0]],[np.sin(y2)*np.cos(p2),np.sin(y2)*np.sin(p2)*np.sin(r2)+np.cos(y2)*np.cos(r2),np.sin(y2)*np.sin(p2)*np.cos(r2)-np.cos(y2)*np.sin(r2),self.arm2_init_point[1]],[-np.sin(p2),np.cos(p2)*np.sin(r2),np.cos(p2)*np.cos(r2),self.arm2_init_point[2]],[0,0,0,1]]
        else:

            T_00=[[np.cos(y1)*np.cos(p1),np.cos(y1)*np.sin(p1)*np.sin(r1)-np.sin(y1)*np.cos(r1),np.cos(y1)*np.sin(p1)*np.sin(r1)+np.sin(y1)*np.sin(r1),self.arm1_init_point[0]],[np.sin(y1)*np.cos(p1),np.sin(y1)*np.sin(p1)*np.sin(r1)+np.cos(y1)*np.cos(r1),np.sin(y1)*np.sin(p1)*np.cos(r1)-np.cos(y1)*np.sin(r1),self.arm1_init_point[1]],[-np.sin(p1),np.cos(p1)*np.sin(r1),np.cos(p1)*np.cos(r1),self.arm1_init_point[2]],[0,0,0,1]]
           
        T_01=np.array([[np.cos(j_pos[0]),0,-np.sin(j_pos[0]),0],[np.sin(j_pos[0]),0,np.cos(j_pos[0]),0],[0,-1,0,d1],[0,0,0,1]])
    
        T_01=np.linalg.multi_dot([T_00,T_01])


        if(joint_ID==0):
            return self.from_transition_matrix_to_pose(T_01)

        T_12=np.array([[np.cos(j_pos[1]+joint2_offset),-np.sin(j_pos[1]+joint2_offset),0,a1*np.cos(j_pos[1]+joint2_offset)],[np.sin(j_pos[1]+joint2_offset),np.cos(j_pos[1]+joint2_offset),0,a1*np.sin(j_pos[1]+joint2_offset)],[0,0,1,0],[0,0,0,1]])
    
        if(joint_ID==1):

            T_02=np.linalg.multi_dot([T_01,T_12])
         
            return self.from_transition_matrix_to_pose(T_02)

        T_23=[[np.cos(j_pos[2]+joint3_offset),0,-np.sin(j_pos[2]+joint3_offset),a2*np.cos(j_pos[2]+joint3_offset)],[np.sin(j_pos[2]+joint3_offset),0,np.cos(j_pos[2]+joint3_offset),a2*np.sin(j_pos[2]+joint3_offset)],[0,-1,0,0],[0,0,0,1]]

        if(joint_ID==2):

            T_03=np.linalg.multi_dot([T_01,T_12,T_23])
           
            return self.from_transition_matrix_to_pose(T_03)

        T_34=[[np.cos(j_pos[3]),0,np.sin(j_pos[3]),0],[np.sin(j_pos[3]),0,-np.cos(j_pos[3]),0],[0,1,0,d3],[0,0,0,1]]

        if(joint_ID==3):

            T_04=np.linalg.multi_dot([T_01,T_12,T_23,T_34])
        
            return self.from_transition_matrix_to_pose(T_04)

        T_45=[[np.cos(j_pos[4]+joint4_offset),0,-np.sin(j_pos[4]+joint4_offset),a3*np.cos(j_pos[4]+joint4_offset)],[np.sin(j_pos[4]+joint4_offset),0,np.cos(j_pos[4]+joint4_offset),a3*np.sin(j_pos[4]+joint4_offset)],[0,-1,0,0],[0,0,0,1]]
    
        if(joint_ID==4):

            T_05=np.linalg.multi_dot([T_01,T_12,T_23,T_34,T_45])
           
            return self.from_transition_matrix_to_pose(T_05)



def joint_state(data):
    global joint_state_data
    joint_state_data=data


def joint_state_arm2(data):
    global joint_state_data_arm2
    joint_state_data_arm2=data


def distance_between_2_points(a, b):

        return np.linalg.norm(np.array(a) - np.array(b))




def joy_data(data):
    global x,start_button
    x=data.buttons[1]
    start_button=data.buttons[7]
    back=data.buttons[6]


def set_mode(pub_set_mode):

    pub_set_mode.publish("set_mode")
    print ("set_mode")


def set_joints_state(set_joints_msg,joints_state_array_arm1,joints_state_array_arm2,pub_set_joints_arm1,pub_set_joints_arm2):
    set_joints_msg.value=joints_state_array_arm1
    pub_set_joints_arm1.publish(set_joints_msg)
    set_joints_msg.value=joints_state_array_arm2
    pub_set_joints_arm2.publish(set_joints_msg)



    

        



def occupied_cells_data(data):
    global occupied_cells
    occupied_cells=data




def create_obstacles_array(occupied_cells):
    obstacles_array=[]

    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            if(point.z>0.025):
                obstacles_array.append(point)

    return obstacles_array


def create_obstacles_array_dynamic(occupied_cells,joint_state_data,joint_state_data_arm2,kinematics,publish_joint_markers=False):
    global pub_obstacles
    num_points=2
    min_dis_obstacle_from_manipulator=0.15
    obstacles=MarkerArray()
    obstacles_array=[]
    joint0_point=kinematics.forward_kinematics(1,0,[joint_state_data[0]])
    joint1_point=kinematics.forward_kinematics(1,1,[joint_state_data[0],joint_state_data[1]])
    joint2_point=kinematics.forward_kinematics(1,2,[joint_state_data[0],joint_state_data[1],joint_state_data[2]])
    joint3_point=kinematics.forward_kinematics(1,3,[joint_state_data[0],joint_state_data[1],joint_state_data[2],joint_state_data[3]])
    joint4_point=kinematics.forward_kinematics(1,4,[joint_state_data[0],joint_state_data[1],joint_state_data[2],joint_state_data[3],joint_state_data[4]])


    joint0_point_arm2=kinematics.forward_kinematics(2,0,[joint_state_data_arm2[0]])
    joint1_point_arm2=kinematics.forward_kinematics(2,1,[joint_state_data_arm2[0],joint_state_data_arm2[1]])
    joint2_point_arm2=kinematics.forward_kinematics(2,2,[joint_state_data_arm2[0],joint_state_data_arm2[1],joint_state_data_arm2[2]])
    joint3_point_arm2=kinematics.forward_kinematics(2,3,[joint_state_data_arm2[0],joint_state_data_arm2[1],joint_state_data_arm2[2],joint_state_data_arm2[3]])
    joint4_point_arm2=kinematics.forward_kinematics(2,4,[joint_state_data_arm2[0],joint_state_data_arm2[1],joint_state_data_arm2[2],joint_state_data_arm2[3],joint_state_data_arm2[4]])

    id=0
    joint_points_array=[getEquidistantPoints(joint0_point, joint1_point, num_points),getEquidistantPoints(joint1_point, joint2_point, num_points),getEquidistantPoints(joint2_point, joint3_point, num_points),getEquidistantPoints(joint3_point, joint4_point, num_points),getEquidistantPoints(joint0_point_arm2, joint1_point_arm2, num_points),getEquidistantPoints(joint1_point_arm2, joint2_point_arm2, num_points),getEquidistantPoints(joint2_point_arm2, joint3_point_arm2, num_points),getEquidistantPoints(joint3_point_arm2, joint4_point_arm2, num_points)]
    #print(' arm 1   ',joint4_point,'  arm2  ',joint4_point_arm2)
    for marker_size in occupied_cells.markers:
        for point in marker_size.points:
            point_tuple=(point.x,point.y,point.z)
            #dis_obstacle_from_manipulator=distance_between_2_points(joint0_point,point_tuple)
            skip=False
            if(point.z>0.025):
                for line in joint_points_array:
                    for joint_point in line:
                        dis_obstacle_from_manipulator=distance_between_2_points(joint_point,point_tuple)
                        if(dis_obstacle_from_manipulator<min_dis_obstacle_from_manipulator):
                            skip=True
                            break
                        
                if(skip):
                    continue
                obstacle=create_obstacle_marker(point,id)
                obstacles.markers.append(obstacle)
                obstacles_array.append(point)
                id+=1
    
    if(publish_joint_markers):
        for line in joint_points_array:
            for joint_point in line:
                obstacle=create_joint_marker(joint_point,id)
                obstacles.markers.append(obstacle)
                id+=1
    
              
          
    pub_obstacles.publish(obstacles)
    return obstacles_array



def getEquidistantPoints(p1, p2, points):
    return zip(np.linspace(p1[0], p2[0], points+1),
               np.linspace(p1[1], p2[1], points+1),
               np.linspace(p1[2], p2[2], points+1))




def create_obstacle_marker(position,i):
    obstacle=Marker()
    obstacle.header.stamp=rospy.Time.now()
    obstacle.header.frame_id='world'
    obstacle.ns='obstacles'
    obstacle.id=i
    obstacle.type=1
    obstacle.lifetime=rospy.Duration(3)
    obstacle.pose.position=position
    obstacle.scale.x , obstacle.scale.y , obstacle.scale.z = 0.05 ,0.05 ,0.05
    obstacle.color.r , obstacle.color.a = 1,0.9

    return obstacle


def create_joint_marker(position,i):
    obstacle=Marker()
    obstacle.header.stamp=rospy.Time.now()
    obstacle.header.frame_id='world'
    obstacle.ns='joints'
    obstacle.id=i
    obstacle.type=1
    obstacle.lifetime=rospy.Duration(3)
    obstacle.pose.position.x ,obstacle.pose.position.y,obstacle.pose.position.z =position[0],position[1],position[2]
    obstacle.scale.x , obstacle.scale.y , obstacle.scale.z = 0.05 ,0.05 ,0.05
    obstacle.color.b , obstacle.color.a = 1,0.9

    return obstacle





def navigation(start_pose_arm1,goal_pose_arm1,start_pose_arm2,goal_pose_arm2,set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2):
    global occupied_cells,joint_state_data,joint_state_data_arm2

    kinematics=Kinematics()
    print (" start navigating")
    
  
    rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
    clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
    clear_octomap()
    time.sleep(0.3)
    start_pose=(start_pose_arm1[0],start_pose_arm1[1],start_pose_arm1[2],start_pose_arm1[3],start_pose_arm1[4],start_pose_arm2[0],start_pose_arm2[1],start_pose_arm2[2],start_pose_arm2[3],start_pose_arm2[4])
    goal_pose=(goal_pose_arm1[0],goal_pose_arm1[1],goal_pose_arm1[2],goal_pose_arm1[3],goal_pose_arm1[4],goal_pose_arm2[0],goal_pose_arm2[1],goal_pose_arm2[2],goal_pose_arm2[3],goal_pose_arm2[4])
    obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data.position,joint_state_data_arm2.position,kinematics,True)
    drrt = DynamicRrt(start_pose, goal_pose, 0.2, 0.2, 0.2, 5000,obstacles_array,0.4,300,200)
    #path,path_nodes=drrt.planning()
    path=drrt.planning()
    time.sleep(0.3)
    path_len=len(path)

    t=time.time()
    i=0
    while i<path_len:
        pose=path[len(path)-i-1]

        joints_state_array_arm1=[pose[0],pose[1],pose[2],pose[3],pose[4],0]
        joints_state_array_arm2=[pose[5],pose[6],pose[7],pose[8],pose[9],0]

        set_joints_state(set_joints_msg,joints_state_array_arm1,joints_state_array_arm2,pub_set_joints_arm1,pub_set_joints_arm2)
        #time.sleep(0.3)

       #t=time.time()
        rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
        clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
        clear_octomap()
        time.sleep(0.3)
        obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data.position,joint_state_data_arm2.position,kinematics)
        drrt.obstacles_array=obstacles_array
        t1=time.time()
        t=time.time()

        if(drrt.is_obstacle_in_path()):

            drrt.InvalidateNodes()


            #if drrt.is_path_invalid():        
            print("Path is Replanning ...")
            print(len(path)-i-1,"    ",len(drrt.waypoints))
            path, waypoints = drrt.replanning(drrt.waypoints[len(path)-i-1])
            path_len=len(path)
            i=0
            drrt.vertex_new = []
            drrt.path = path
            drrt.waypoints = waypoints

        i+=1

    





def main():
    global x,start_button
    global joint_state_data,joint_state_data_arm2
    global occupied_cells
    global pub_obstacles

    
    
   



    rospy.init_node('forward_kinematics', anonymous=True)
    pub_set_mode = rospy.Publisher('/robotis/base/set_mode_msg', String, queue_size=10)
    pub_set_joints_arm1 = rospy.Publisher('/robotis/base/joint_pose_msg',JointPose, queue_size=10)
    pub_set_joints_arm2 = rospy.Publisher('/robotis/base/joint_pose_msg_arm2',JointPose, queue_size=10)
    rospy.Subscriber("/robotis/present_joint_states", JointState, joint_state)
    rospy.Subscriber("/robotis/present_joint_states_arm2", JointState, joint_state_arm2)
    rospy.Subscriber("/occupied_cells_vis_array", MarkerArray, occupied_cells_data)
    rospy.Subscriber("/joy", Joy, joy_data)
    pub_obstacles = rospy.Publisher('visualize_obstacles',MarkerArray, queue_size=1)
    rate = rospy.Rate(10) # 10hz


    set_joints_msg=JointPose()

    set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']




    while not rospy.is_shutdown():

        j_pos=joint_state_data.position

        j_pos_arm2=joint_state_data_arm2.position

        kinematics=Kinematics()

        #set_joints_msg=JointPose()

        #set_joints_msg.name=['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        if(x==1):
            #set_mode(pub_set_mode)
            print('click')
            pose=(j_pos[0],j_pos[1],j_pos[2],j_pos[3],j_pos[4],j_pos_arm2[0],j_pos_arm2[1],j_pos_arm2[2],j_pos_arm2[3],j_pos_arm2[4])
            
            rospy.wait_for_service('/octomap_server/reset') #this will stop your code until the clear octomap service starts running
            clear_octomap = rospy.ServiceProxy('/octomap_server/reset', Empty)
            clear_octomap()
            time.sleep(0.2)
            obstacles_array=create_obstacles_array_dynamic(occupied_cells,j_pos,j_pos_arm2,kinematics,True)
            
            
            #print(occupied_cells)
            

        if(start_button==1):
            print('start')  
            start_arm1=(j_pos[0],j_pos[1],j_pos[2],j_pos[3],j_pos[4],j_pos[5])
            start_arm2=(j_pos_arm2[0],j_pos_arm2[1],j_pos_arm2[2],j_pos_arm2[3],j_pos_arm2[4],j_pos_arm2[5])
            #navigation(start_arm1,(3,0,0,0,0,0),start_arm2,(3,1.5,-1.5,0,0,0),set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2)
            navigation(start_arm1,(3,0,0,0,0,0),start_arm2,(3,0,0,0,0,0),set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2)
           

        rate.sleep()




if __name__ == '__main__':
    try:
       main()
    except rospy.ROSInterruptException:
        pass