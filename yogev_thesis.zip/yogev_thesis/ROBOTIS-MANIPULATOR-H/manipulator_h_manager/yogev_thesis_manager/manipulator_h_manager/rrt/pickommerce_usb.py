#!/usr/bin/env python3
import rospy
import numpy as np
import ground_control as gc
from time import sleep
from arm_kinematic import ArmKinematic

if __name__ == '__main__':

    rospy.init_node('thesis_algo2', anonymous=True)

    pos_in=[310,0,645]

    pos_out=[220,0,645]

    N_points = 100
    X_out2in = np.array([np.linspace(pos_out[0],pos_in[0],N_points)])
    Y_out2in = np.array([np.zeros(N_points)])
    Z_out2in = np.array([np.ones(N_points)*646])
    
    path_out2ion = np.hstack((X_out2in.T, Y_out2in.T, Z_out2in.T))

    ori=[1.57,0,0]
    inv=ArmKinematic()
    for i in range(N_points):
        print(path_out2ion[i,:])
        inv2=inv.inverse(path_out2ion[i,:], ori,1)
        g_control = gc.ground_control(np.array([[-1.57,1.57,-1.57,0,0,0,inv2[0][0],inv2[0][1],inv2[0][2],inv2[0][3],inv2[0][4],inv2[0][5],0,0,0]]), resolution=0.005, with_jig=False, with_gripper=False)
        g_control.run()
        # sleep(0.001)





    # pos_out=[220,0,650]

    # ori=[1.57,0,0]

    # inv2=inv.inverse(pos_out, ori,1)

    # g_control = gc.ground_control(np.array([[-1.57,1.57,-1.57,0,0,0,inv2[0][0],inv2[0][1],inv2[0][2],inv2[0][3],inv2[0][4],inv2[0][5],0,0,0]]), resolution=0.005, with_jig=False, with_gripper=False)

    # g_control.run()

 
