#!/usr/bin/env python3
import numpy as np
from arm_kinematic import ArmKinematic
from arms_control import ROS_god
from IJ_main_motor import IJ_main_motor
from time import sleep
from csv import writer
from datetime import datetime


def key_released(kobi_input):
    to_exit = True
    move = np.zeros(3)
    rotate = np.zeros(3)
    theta6 = 0
    delta_x = 2
    delta_teta = np.pi / 180
    jig = 0
    # Move on xy plane:
    if kobi_input == 'd':
        move = delta_x * np.array([1, 0, 0])
    elif kobi_input == 'a':
        move = delta_x * np.array([-1, 0, 0])
    elif kobi_input == 'w':
        move = delta_x * np.array([0, 1, 0])
    elif kobi_input == 's':
        move = delta_x * np.array([0, -1, 0])
    elif kobi_input == 'q':
        move = delta_x * np.array([-1, 1, 0])
    elif kobi_input == 'e':
        move = delta_x * np.array([1, 1, 0])
    elif kobi_input == 'z':
        move = delta_x * np.array([-1, -1, 0])
    elif kobi_input == 'c':
        move = delta_x * np.array([1, -1, 0])

    # move on z axis
    elif kobi_input == 'y':
        move = delta_x * np.array([0, 0, 1])
    elif kobi_input == 'h':
        move = delta_x * np.array([0, 0, -1])

    # move on yaw
    elif kobi_input == 'o':
        rotate = np.array([0, 0, delta_teta])
    elif kobi_input == 'l':
        rotate = np.array([0, 0, -delta_teta])
    # move on pitch
    elif kobi_input == 'i':
        rotate = np.array([0, delta_teta, 0])
    elif kobi_input == 'k':
        rotate = np.array([0, -delta_teta, 0])
    # move on roll
    elif kobi_input == 'u':
        rotate = np.array([delta_teta, 0, 0])
    elif kobi_input == 'j':
        rotate = np.array([-delta_teta, 0, 0])
    # Rotate gripper motor
    elif kobi_input == 'n':
        theta6 = delta_teta
    elif kobi_input == 'm':
        theta6 = -delta_teta

    # Rotate jig
    elif kobi_input == '.':
        jig = np.deg2rad(1)
    elif kobi_input == ',':
        jig = -np.deg2rad(1)

    elif kobi_input == '':  # Prevent from exit when pressing enter.
        to_exit = True
    elif kobi_input == 'p':
        move = np.array([0, 0, 0])
    elif kobi_input == '9':
        to_exit = False
    else:
        move, rotate, theta6, jig, to_exit = key_released(input("Try again to run away press 9!!!/n"))

    return move, rotate, theta6, jig, to_exit


def keyboard_control(arms_node, orientation, theta6):
    filename = "trajectories/kc_insert_trajectory_" + get_current_datetime() + ".csv"
    step = np.hstack((arms_node.present_right, theta6))
    append_list_as_row(filename, step)

    motor_angels_arm1 = arms_node.present_right

    print("Press a key (Escape key to exit):")
    new_position = ArmKinematic.forward(arms_node.present_right)[0]
    new_orientation = orientation.astype(float)

    epsilon = np.deg2rad(15)
    to_exit = True

    while to_exit:

        move, rotate, theta6_delta, jig_rotation, to_exit = key_released(input())
        theta6 += theta6_delta
        if not to_exit:
            return new_position, new_orientation, theta6

        new_position += move
        new_orientation += rotate

        # Save the arm position before moving the jig
        if jig_rotation:
            sleep(0.1)
            step = np.hstack((arms_node.present_right, arms_node.present_left, jig.curr_pos, theta6))
            append_list_as_row(filename, step)
            jig.move_IJ(jig.curr_pos + jig_rotation)
            print(f'new_position: {np.round(new_position, 2)} new_orientation: {np.round(new_orientation, 2)} theta6: {np.round(theta6, 2)} jig: {np.round(jig.curr_pos, 2)}')
        else:
            tmp_pos = np.zeros((1, 6))
            for i in range(8):
                tmp_pos = np.vstack((tmp_pos, ArmKinematic.inverse(new_position, new_orientation, i, motor_angels_arm1[3], motor_angels_arm1[5])))
            tmp_pos = tmp_pos[1:]
            tmp_pos[:, 5] += theta6

            close_pos = tmp_pos[np.argmin(np.linalg.norm(tmp_pos - motor_angels_arm1, axis=1))]
            error = np.abs(close_pos[:5] - motor_angels_arm1[:5])
            if np.all(error < epsilon):
                print(f'error (deg): {np.round(np.rad2deg(error), 3)}')
                print(f'new_position: {np.round(new_position, 2)} new_orientation: {np.round(new_orientation, 2)} theta6: {np.round(theta6, 2)} jig: {np.round(jig.curr_pos, 2)}')
                arms_node.send_to_arm1(close_pos)
                motor_angels_arm1 = arms_node.present_right
            else:
                print("cant go to desire position")
                new_position -= move
                new_orientation -= rotate
                theta6 -= theta6_delta


def append_list_as_row(file_name, list_of_elem):
    # Open file in append mode
    with open(file_name, 'a+', newline='') as write_obj:
        # Create a writer object from csv module
        csv_writer = writer(write_obj)
        # Add contents of list as last row in the csv file
        csv_writer.writerow(list_of_elem)


def get_current_datetime():
    return datetime.now().strftime("%m-%d-%Y_%H-%M-%S")


if __name__ == '__main__':
    # init_position_arm_1 = np.array([327.61, -126., 843.])
    init_orientation_arm_1 = np.array([0., -1.57, -0.])
    theta6 = 0

    arms_node = ROS_god()
    while not np.any(arms_node.present_right):
        arms_node.read_arm_pos()

    jig = IJ_main_motor()
    jig.read_pos()

    new_position, new_orientation, theta6 = keyboard_control(arms_node, init_orientation_arm_1, theta6)
    print(f'new_position: {np.round(new_position, 2)} new_orientation: {np.round(new_orientation, 2)} theta6: {np.round(theta6, 2)}')

