#include "ros/ros.h"
#include <ros/console.h>
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "std_srvs/Empty.h"
#include "manipulator_h_base_module_msgs/JointPose.h"
#include "sensor_msgs/JointState.h"
#include "sensor_msgs/Joy.h"
#include "visualization_msgs/MarkerArray.h"
#include "visualization_msgs/Marker.h"
#include <iostream>
#include <math.h> 
#include <cmath>
#include <Eigen/Dense>
#include <array>
#include<unistd.h>
#include <chrono>
#include <stdlib.h>  
#include <vector>
typedef std::chrono::high_resolution_clock Clock;
using namespace std;
using namespace Eigen;
std::stringstream ss;
visualization_msgs::MarkerArray occupied_cells;
sensor_msgs::JointState joint_state_data;
sensor_msgs::JointState joint_state_data_arm2;
manipulator_h_base_module_msgs::JointPose set_joints_msg;

int x=0;
int start_button=0;
double joints_state_array_arm1[]={0.0,0.0,0.0,0.0,0.0};

double joints_state_array_arm2[] = { 0,0,0,0,0};

//double joint_state_data[] = { 0,0,0,0,0,0 };
//double joint_state_data_arm2[] = { 0,0,0,0,0,0 };
 
void joy_data(const sensor_msgs::Joy::ConstPtr& joy)
{
//std::cout<<"axes: ["<< joy.axes[0] <<","<<joy.axes[1] <<","<<joy.axes[2] <<","<<joy.axes[3]<<","<< joy.axes[4]<<","<< joy.axes[5] <<","<<joy.axes[6]<<","<< joy.axes[7] <<"]"<<std::endl;
//std::cout<<"buttons: ["<< joy.buttons[0] <<","<< joy.buttons[1] <<","<<joy.buttons[2] <<","<<joy.buttons[3]<<","<< joy.buttons[4] <<","<<joy.buttons[5] <<","<<joy.buttons[6] <<","<<joy.buttons[7] <<","<<joy.buttons[8] <<","<<joy.buttons[9]<<","<<joy.buttons[10] <<"]"<<std::endl;
start_button=joy->buttons[7];
x=joy->buttons[1];
//std::cout<<"axes: "<<start_button<<std::endl;
}


 
void joint_state(const sensor_msgs::JointState::ConstPtr& joint_state_msg)
{
//std::cout<<"joint_state: "<<joint_state_msg.position[0]<<std::endl;

joint_state_data.position=joint_state_msg->position;

}



void joint_state_arm2(const sensor_msgs::JointState::ConstPtr& joint_state_arm2_msg)
{

joint_state_data_arm2.position=joint_state_arm2_msg->position;

}


void occupied_cells_data(const visualization_msgs::MarkerArray::ConstPtr& occupied_cells_msg)
{
occupied_cells.markers=occupied_cells_msg->markers;

}


void set_joints_state(manipulator_h_base_module_msgs::JointPose set_joints_msg,double joints_state_array_arm1[],double joints_state_array_arm2[],ros::Publisher pub_set_joints_arm1,ros::Publisher pub_set_joints_arm2)
{
  set_joints_msg.value={joints_state_array_arm1[0],joints_state_array_arm1[1],joints_state_array_arm1[2],joints_state_array_arm1[3],joints_state_array_arm1[4]};

  pub_set_joints_arm1.publish(set_joints_msg);

  set_joints_msg.value={joints_state_array_arm2[0],joints_state_array_arm2[1],joints_state_array_arm2[2],joints_state_array_arm2[3],joints_state_array_arm2[4]};

  pub_set_joints_arm2.publish(set_joints_msg);
}

double distance_between_2_points(double point_A[3],double point_B[3]){

  //cout<<point_A[0]<<"    "<<point_B[0]<<endl;

  return sqrt(pow(point_A[0]-point_B[0],2)+pow(point_A[1]-point_B[1],2)+pow(point_A[2]-point_B[2],2));

}


double distance_between_2_nodes(double node_A[10],double node_B[10]){

  return sqrt(pow(node_A[0]-node_B[0],2)+pow(node_A[1]-node_B[1],2)+pow(node_A[2]-node_B[2],2)
              +pow(node_A[3]-node_B[3],2) + pow(node_A[4]-node_B[4],2) + pow(node_A[5]-node_B[5],2)
              +pow(node_A[6]-node_B[6],2)+pow(node_A[7]-node_B[7],2)+pow(node_A[8]-node_B[8],2)
              +pow(node_A[9]-node_B[9],2));

}




visualization_msgs::Marker create_obstacle_marker(double position[3],int i){

  visualization_msgs::Marker obstacle;

  obstacle.header.stamp=ros::Time::now();

  obstacle.header.frame_id="world";

  obstacle.ns="obstacles";

  obstacle.id=i;

  obstacle.type=1;

  obstacle.lifetime=ros::Duration(3);

  obstacle.pose.position.x=position[0]; obstacle.pose.position.y=position[1]; obstacle.pose.position.z=position[2];

  obstacle.scale.x=0.05; obstacle.scale.y=0.05; obstacle.scale.z=0.05;

  obstacle.color.r=1;  obstacle.color.a = 0.9;


  return obstacle;



}



visualization_msgs::Marker create_joint_marker(double position[3],int i){

  visualization_msgs::Marker joint;

  joint.header.stamp=ros::Time::now();

  joint.header.frame_id="world";

  joint.ns="joints";

  joint.id=i;

  joint.type=1;

  joint.lifetime=ros::Duration(3);

  joint.pose.position.x=position[0]; joint.pose.position.y=position[1]; joint.pose.position.z=position[2];

  joint.scale.x=0.05; joint.scale.y=0.05; joint.scale.z=0.05;

  joint.color.b=1;  joint.color.a = 0.9;

  return joint;



}

class Node{

  public:

  Node *parent;

  int flag=1;

  bool is_first_node=false;

  void set_pose(double[10],int);

  double pos[10];

};



void Node::set_pose(double pose[10],int f){

  pos[0]=pose[0]; pos[1]=pose[1]; pos[2]=pose[2]; pos[3]=pose[3]; pos[4]=pose[4];

  pos[5]=pose[5]; pos[6]=pose[6]; pos[7]=pose[7]; pos[8]=pose[8]; pos[9]=pose[9];

  flag=f;  


}


class Edge{

  public:

  Node parent;

  Node child;

  int flag=1;


};










class Kinematics {

  

  double arm1_init_point[3];

  double arm2_init_point[3];

  double arm1_init_orientation[3];

  double arm2_init_orientation[3];

  double joint_pose[3];

  public:

  void set_values (double[3],double[3],double[3],double[3]);

  double *forward_kinematics(int,int,double[5]);


};



void Kinematics::set_values (double init_point_arm1[3],double init_point_arm2[3],double init_orientation_arm1[3],double init_orientation_arm2[3]) {

  arm1_init_point[0]=init_point_arm1[0]; arm1_init_point[1]=init_point_arm1[1]; arm1_init_point[2]=init_point_arm1[2];
  arm2_init_point[0]=init_point_arm2[0]; arm2_init_point[1]=init_point_arm2[1]; arm2_init_point[2]=init_point_arm2[2];
  arm1_init_orientation[0]=init_orientation_arm1[0]; arm1_init_orientation[1]=init_orientation_arm1[1]; arm1_init_orientation[2]=init_orientation_arm1[2];
  arm2_init_orientation[0]=init_orientation_arm2[0]; arm2_init_orientation[1]=init_orientation_arm2[1]; arm2_init_orientation[2]=init_orientation_arm2[2];
  
}


double *Kinematics::forward_kinematics(int arm_ID,int joint_ID,double j_pos[5])
{
  
  double d1=0.159;  double a1=0.2659; double a2=0.03; double a3=0.134; double d3=0.258;

  double joint2_offset=-1.57+0.113; double joint3_offset=-0.113; double joint4_offset=1.57;

  double y1=arm1_init_orientation[0]; double p1=arm1_init_orientation[1] ; double r1=arm1_init_orientation[2];

  double y2=arm2_init_orientation[0]; double p2=arm2_init_orientation[1] ; double r2=arm2_init_orientation[2];



  MatrixXd T_00(4,4); MatrixXd T_01(4,4);  MatrixXd T_12(4,4); MatrixXd T_02(4,4); MatrixXd T_23(4,4); MatrixXd T_03(4,4); 

  MatrixXd T_34(4,4); MatrixXd T_04(4,4);  MatrixXd T_45(4,4); MatrixXd T_05(4,4); 

  

  if(arm_ID==2){

    T_00<<cos(y2)*cos(p2),cos(y2)*sin(p2)*sin(r2)-sin(y2)*cos(r2),cos(y2)*sin(p2)*sin(r2)+sin(y2)*sin(r2),arm2_init_point[0],sin(y2)*cos(p2),sin(y2)*sin(p2)*sin(r2)+cos(y2)*cos(r2),sin(y2)*sin(p2)*cos(r2)-cos(y2)*sin(r2),arm2_init_point[1],-sin(p2),cos(p2)*sin(r2),cos(p2)*cos(r2),arm2_init_point[2],0,0,0,1;
  }

  else{
    T_00<<cos(y1)*cos(p1),cos(y1)*sin(p1)*sin(r1)-sin(y1)*cos(r1),cos(y1)*sin(p1)*sin(r1)+sin(y1)*sin(r1),arm1_init_point[0],sin(y1)*cos(p1),sin(y1)*sin(p1)*sin(r1)+cos(y1)*cos(r1),sin(y1)*sin(p1)*cos(r1)-cos(y1)*sin(r1),arm1_init_point[1],-sin(p1),cos(p1)*sin(r1),cos(p1)*cos(r1),arm1_init_point[2],0,0,0,1;
  }

  T_01<<cos(j_pos[0]),0,-sin(j_pos[0]),0,sin(j_pos[0]),0,cos(j_pos[0]),0,0,-1,0,d1,0,0,0,1;

  T_01=T_00*T_01;

  if(joint_ID==0){

    joint_pose[0]=T_01(0,3); joint_pose[1]=T_01(1,3); joint_pose[2]=T_01(2,3);

    return joint_pose;}

  T_12<<cos(j_pos[1]+joint2_offset),-sin(j_pos[1]+joint2_offset),0,a1*cos(j_pos[1]+joint2_offset),sin(j_pos[1]+joint2_offset),cos(j_pos[1]+joint2_offset),0,a1*sin(j_pos[1]+joint2_offset),0,0,1,0,0,0,0,1;

  if(joint_ID==1){

    T_02=T_01*T_12;

    joint_pose[0]=T_02(0,3); joint_pose[1]=T_02(1,3); joint_pose[2]=T_02(2,3);

    return joint_pose;
  }

  T_23<<cos(j_pos[2]+joint3_offset),0,-sin(j_pos[2]+joint3_offset),a2*cos(j_pos[2]+joint3_offset),sin(j_pos[2]+joint3_offset),0,cos(j_pos[2]+joint3_offset),a2*sin(j_pos[2]+joint3_offset),0,-1,0,0,0,0,0,1;

  if(joint_ID==2){

    T_03=T_01*T_12*T_23;

    joint_pose[0]=T_03(0,3); joint_pose[1]=T_03(1,3); joint_pose[2]=T_03(2,3);

    return joint_pose;

  }

  T_34<<cos(j_pos[3]),0,sin(j_pos[3]),0,sin(j_pos[3]),0,-cos(j_pos[3]),0,0,1,0,d3,0,0,0,1;

  

  if(joint_ID==3){

    T_04=T_01*T_12*T_23*T_34;

    joint_pose[0]=T_04(0,3); joint_pose[1]=T_04(1,3); joint_pose[2]=T_04(2,3);

    return joint_pose;

  }

  T_45<<cos(j_pos[4]+joint4_offset),0,-sin(j_pos[4]+joint4_offset),a3*cos(j_pos[4]+joint4_offset),sin(j_pos[4]+joint4_offset),0,cos(j_pos[4]+joint4_offset),a3*sin(j_pos[4]+joint4_offset),0,-1,0,0,0,0,0,1;


  if(joint_ID==4){

    T_05=T_01*T_12*T_23*T_34*T_45;

    joint_pose[0]=T_05(0,3); joint_pose[1]=T_05(1,3); joint_pose[2]=T_05(2,3);

    return joint_pose;

}

}





vector<double*> create_obstacles_array_dynamic(visualization_msgs::MarkerArray occupied_cells,sensor_msgs::JointState joint_state_data,sensor_msgs::JointState joint_state_data_arm2,Kinematics kinematics,ros::Publisher pub_obstacles,bool publish_joint_markers){

  int num_points=5;  int id=0; int sizes_len=0; int points_amount=0; bool skip=0;

  visualization_msgs::MarkerArray obstacles; static vector<double*> obstacles_array = vector<double*>();double joint0_point[3]; double j_pos[5]; double j_pos_arm2[5];

  double joint1_point[3]; double joint2_point[3]; double joint3_point[3]; double joint4_point[3]; double min_dis_obstacle_from_manipulator=0.15;

  double joint1_point_arm2[3]; double joint2_point_arm2[3]; double joint3_point_arm2[3]; double joint4_point_arm2[3]; double joint0_point_arm2[3]; double joint01_point[3]; double joint23_point[3];

  double *joint_points_array[13]; static double point_array[3]={0,0,0}; double dis_obstacle_from_manipulator=0.0; double joint01_point_arm2[3]; double joint23_point_arm2[3];

  visualization_msgs::Marker obstacle; visualization_msgs::Marker joint; 

  j_pos[0]=joint_state_data.position[0]; j_pos[1]=joint_state_data.position[1]; j_pos[2]=joint_state_data.position[2]; j_pos[3]=joint_state_data.position[3]; j_pos[4]=joint_state_data.position[4];

  j_pos_arm2[0]=joint_state_data_arm2.position[0]; j_pos_arm2[1]=joint_state_data_arm2.position[1]; j_pos_arm2[2]=joint_state_data_arm2.position[2]; j_pos_arm2[3]=joint_state_data_arm2.position[3]; j_pos_arm2[4]=joint_state_data_arm2.position[4];
 
  joint0_point[0]=kinematics.forward_kinematics(1,0,j_pos)[0]; joint0_point[1]=kinematics.forward_kinematics(1,0,j_pos)[1]; joint0_point[2]=kinematics.forward_kinematics(1,0,j_pos)[2];

  joint1_point[0]=kinematics.forward_kinematics(1,1,j_pos)[0]; joint1_point[1]=kinematics.forward_kinematics(1,1,j_pos)[1]; joint1_point[2]=kinematics.forward_kinematics(1,1,j_pos)[2];

  joint2_point[0]=kinematics.forward_kinematics(1,2,j_pos)[0]; joint2_point[1]=kinematics.forward_kinematics(1,2,j_pos)[1]; joint2_point[2]=kinematics.forward_kinematics(1,2,j_pos)[2];

  joint3_point[0]=kinematics.forward_kinematics(1,3,j_pos)[0]; joint3_point[1]=kinematics.forward_kinematics(1,3,j_pos)[1]; joint3_point[2]=kinematics.forward_kinematics(1,3,j_pos)[2];

  joint4_point[0]=kinematics.forward_kinematics(1,4,j_pos)[0]; joint4_point[1]=kinematics.forward_kinematics(1,4,j_pos)[1]; joint4_point[2]=kinematics.forward_kinematics(1,4,j_pos)[2];

  joint0_point_arm2[0]=kinematics.forward_kinematics(2,0,j_pos_arm2)[0]; joint0_point_arm2[1]=kinematics.forward_kinematics(2,0,j_pos_arm2)[1]; joint0_point_arm2[2]=kinematics.forward_kinematics(2,0,j_pos_arm2)[2];

  joint1_point_arm2[0]=kinematics.forward_kinematics(2,1,j_pos_arm2)[0]; joint1_point_arm2[1]=kinematics.forward_kinematics(2,1,j_pos_arm2)[1]; joint1_point_arm2[2]=kinematics.forward_kinematics(2,1,j_pos_arm2)[2];

  joint2_point_arm2[0]=kinematics.forward_kinematics(2,2,j_pos_arm2)[0]; joint2_point_arm2[1]=kinematics.forward_kinematics(2,2,j_pos_arm2)[1]; joint2_point_arm2[2]=kinematics.forward_kinematics(2,2,j_pos_arm2)[2];

  joint3_point_arm2[0]=kinematics.forward_kinematics(2,3,j_pos_arm2)[0]; joint3_point_arm2[1]=kinematics.forward_kinematics(2,3,j_pos_arm2)[1]; joint3_point_arm2[2]=kinematics.forward_kinematics(2,3,j_pos_arm2)[2];

  joint4_point_arm2[0]=kinematics.forward_kinematics(2,4,j_pos_arm2)[0]; joint4_point_arm2[1]=kinematics.forward_kinematics(2,4,j_pos_arm2)[1]; joint4_point_arm2[2]=kinematics.forward_kinematics(2,4,j_pos_arm2)[2];
  
  joint01_point[0]=(joint0_point[0]+joint1_point[0])/2; joint01_point[1]=(joint0_point[1]+joint1_point[1])/2; joint01_point[2]=(joint0_point[2]+joint1_point[2])/2;

  joint23_point[0]=(joint2_point[0]+joint3_point[0])/2; joint23_point[1]=(joint2_point[1]+joint3_point[1])/2; joint23_point[2]=(joint2_point[2]+joint3_point[2])/2;

  joint01_point_arm2[0]=(joint0_point_arm2[0]+joint1_point_arm2[0])/2; joint01_point_arm2[1]=(joint0_point_arm2[1]+joint1_point_arm2[1])/2; joint01_point_arm2[2]=(joint0_point_arm2[2]+joint1_point_arm2[2])/2;

  joint23_point_arm2[0]=(joint2_point_arm2[0]+joint3_point_arm2[0])/2; joint23_point_arm2[1]=(joint2_point_arm2[1]+joint3_point_arm2[1])/2; joint23_point_arm2[2]=(joint2_point_arm2[2]+joint3_point_arm2[2])/2;

  
  joint_points_array[0]=joint0_point; joint_points_array[1]=joint1_point; joint_points_array[2]=joint2_point; joint_points_array[3]=joint3_point; joint_points_array[4]=joint4_point;

  joint_points_array[5]=joint0_point_arm2; joint_points_array[6]=joint1_point_arm2; joint_points_array[7]=joint2_point_arm2; joint_points_array[8]=joint3_point_arm2; joint_points_array[9]=joint4_point_arm2;

  joint_points_array[10]=joint01_point; joint_points_array[11]=joint23_point; joint_points_array[12]=joint01_point_arm2; joint_points_array[13]=joint23_point_arm2;


  if(occupied_cells.markers.empty()==0){

    sizes_len=sizeof(occupied_cells.markers);

    for (int marker_index = 0; marker_index < occupied_cells.markers.size(); marker_index++) {


      points_amount=sizeof(occupied_cells.markers[marker_index].points);



      for (int point_index = 0; point_index < occupied_cells.markers[marker_index].points.size(); point_index++) {
     

        if(occupied_cells.markers[marker_index].points.empty()==0){

        point_array[0]=occupied_cells.markers[marker_index].points[point_index].x; point_array[1]=occupied_cells.markers[marker_index].points[point_index].y; point_array[2]=occupied_cells.markers[marker_index].points[point_index].z;

        
        skip=0;

        //cout<<point_index<<endl;


        if(point_array[2]>0.025){

          
          for (int joint_point = 0; joint_point < sizeof(joint_points_array)/sizeof(joint_points_array[0]); joint_point++){

            

            dis_obstacle_from_manipulator=distance_between_2_points(joint_points_array[joint_point],point_array);

            if(dis_obstacle_from_manipulator<min_dis_obstacle_from_manipulator){

              skip=1;

              break;

            }

            

          }

          if(skip==1){

            continue;

          }

          obstacle=create_obstacle_marker(point_array,id);

          obstacles.markers.push_back(obstacle);

          obstacles_array.push_back(point_array);

          id+=1;

          

        }

        

        }

      }

    }

    
    
  




  if(publish_joint_markers){

    for (int joint_point = 0; joint_point < sizeof(joint_points_array)/sizeof(joint_points_array[0]); joint_point++){

    joint=create_joint_marker(joint_points_array[joint_point],id);

    obstacles.markers.push_back(joint);

    id+=1;}

  }

  pub_obstacles.publish(obstacles);

  cout<<" obstacle array "<<sizeof(obstacles_array)/sizeof(obstacles_array[0])<<endl;

  return obstacles_array;

  }

  return {};
  

}  







class DynamicRrt{

  Node s_start; 

  Node s_goal;

  double step_len;

  double goal_sample_rate;

  double waypoint_sample_rate;

  int iter_max;

  

  //Node vertex[500];

  Kinematics kinematics;

  double vertex_old[500];

  double vertex_new[500];

  //Edge edges[500];

  int range_1[2]={-314,314}; //range1={-3.14,3.14}

  int range_2[2]={-157,157};//range2={-1.57,1.57}

  int range_3[2]={-157,157};//range3={-1.57,1.57}

  int range_4[2]={-157,157};//range4={-1.57,1.57}

  int range_5[2]={-157,157};//range5={-1.57,1.57}

  double collision_dist=0.4;

  double direction_norm_and_dist[11];

  public:

  vector<Node> vertex;

  //vector<double*> path;

  vector<Edge> edges;

  vector<double*> obstacles_array;

  void set_parameters(Node,Node,double,double,double,int);

  Node generate_random_node();

  Node nearest_neighbor(Node);

  double* get_distance_and_direction(Node,Node);

  Node new_state(Node, Node);

  bool is_arm1_near_obstacle(Node);

  bool is_arm2_near_obstacle(Node);

  bool is_arm1_near_arm2(Node);

  bool is_collision(Node);

  vector<double*> extract_path(Node);

  vector<double*> planning();

};


//set_parameters(start_pose, goal_pose, 0.2, 0.2, 0.2, 5000);

void DynamicRrt::set_parameters(Node start,Node goal,double step_l,double goal_sample_r,double waypoint_sample_r,int i_max){

  s_start=start; s_goal=goal; step_len=step_l; goal_sample_rate=goal_sample_r; waypoint_sample_rate=waypoint_sample_r;

  iter_max=i_max;

}


Node DynamicRrt::generate_random_node(){
  int delta=10; //delta=0.1

  if((rand() % 100)/100.0>goal_sample_rate){

  Node node;

  

  double random_points[10]={(rand() % ((range_1[1]+delta)-(range_1[0]-delta)) + range_1[0]-delta)/100.0,
                  (rand() % ((range_2[1]+delta)-(range_2[0]-delta)) + range_2[0]-delta)/100.0,
                  (rand() % ((range_3[1]+delta)-(range_3[0]-delta)) + range_3[0]-delta)/100.0,
                  (rand() % ((range_4[1]+delta)-(range_4[0]-delta)) + range_4[0]-delta)/100.0,
                  (rand() % ((range_5[1]+delta)-(range_5[0]-delta)) + range_5[0]-delta)/100.0,
                  (rand() % ((range_1[1]+delta)-(range_1[0]-delta)) + range_1[0]-delta)/100.0,
                  (rand() % ((range_2[1]+delta)-(range_2[0]-delta)) + range_2[0]-delta)/100.0,
                  (rand() % ((range_3[1]+delta)-(range_3[0]-delta)) + range_3[0]-delta)/100.0,
                  (rand() % ((range_4[1]+delta)-(range_4[0]-delta)) + range_4[0]-delta)/100.0,
                  (rand() % ((range_5[1]+delta)-(range_5[0]-delta)) + range_5[0]-delta)/100.0};

  node.set_pose(random_points,1);

  return node;
  
  }

  return s_goal;}


Node DynamicRrt::nearest_neighbor(Node n){

  double min_dist=100;  double vertex_dist=10.0;  int argmin=0;

  //cout<<"  in function  "<<n.pos[1]<<"   pos rand node "<<vertex.size()<<endl;

  for (int i = 0; i < vertex.size(); i++) {

    vertex_dist=distance_between_2_nodes(vertex[i].pos,n.pos);

    //cout<<" vertex_dist "<<vertex_dist<<" i "<<i<<"  size  "<<vertex.size()<<" min dist "<<min_dist<<endl;

    if(min_dist>vertex_dist){

      min_dist=vertex_dist;

      argmin=i;

      //cout<<min_dist<<"   "<<argmin<<endl;

    }

  }
  
  //cout<<"  argmin "<<argmin<<"  size  "<<vertex.size()<<endl;

  return vertex[argmin];
    
    }







double* DynamicRrt::get_distance_and_direction(Node node_start, Node node_end){

double dist=10.0;  

double direction[10]={node_end.pos[0]-node_start.pos[0],node_end.pos[1]-node_start.pos[1],node_end.pos[2]-node_start.pos[2],node_end.pos[3]-node_start.pos[3],
        node_end.pos[4]-node_start.pos[4],node_end.pos[5]-node_start.pos[5],node_end.pos[6]-node_start.pos[6],node_end.pos[7]-node_start.pos[7],
        node_end.pos[8]-node_start.pos[8],node_end.pos[9]-node_start.pos[9]};

dist=distance_between_2_nodes(node_start.pos,node_end.pos);

//cout<<"  dist "<<dist<<endl;

if(dist==0){
 
}

else{

  direction_norm_and_dist[1]=direction[0]/dist; direction_norm_and_dist[2]=direction[1]/dist; direction_norm_and_dist[3]=direction[2]/dist;

  direction_norm_and_dist[4]=direction[3]/dist; direction_norm_and_dist[5]=direction[4]/dist; direction_norm_and_dist[6]=direction[5]/dist;

  direction_norm_and_dist[7]=direction[6]/dist; direction_norm_and_dist[8]=direction[7]/dist; direction_norm_and_dist[9]=direction[8]/dist;

  direction_norm_and_dist[10]=direction[9]/dist; direction_norm_and_dist[0]=dist;
}


return direction_norm_and_dist;

}



Node DynamicRrt::new_state(Node node_start,Node node_end){

  double dist; double direction[10]; static Node node_new; double node_new_pose[10];

  node_new.parent=new Node;

  dist=get_distance_and_direction(node_start,node_end)[0];

  //cout<<"  dist "<<dist<<endl;

  if(dist>step_len){

    dist=step_len;

  }

  //cout<<"  dist "<<dist<<endl;

  for (int i = 0; i < 10; i++) {

    node_new_pose[i]=node_start.pos[i]+dist*get_distance_and_direction(node_start,node_end)[i+1];}
    

node_new.set_pose(node_new_pose,1);


*node_new.parent=node_start;


return node_new;

}


bool DynamicRrt::is_arm1_near_obstacle(Node node){

  

  double node_pose[5]={node.pos[0],node.pos[1],node.pos[2],node.pos[3],node.pos[4]}; double* joints_point_array[5]; double dis_joint_from_obstacle;

  double joint0_point[3]; double joint1_point[3];  double joint2_point[3]; double joint3_point[3];  double joint4_point[3]; 

  joint0_point[0]=kinematics.forward_kinematics(1,0,node_pose)[0]; joint0_point[1]=kinematics.forward_kinematics(1,0,node_pose)[1]; joint0_point[2]=kinematics.forward_kinematics(1,0,node_pose)[2];

  joint1_point[0]=kinematics.forward_kinematics(1,1,node_pose)[0]; joint1_point[1]=kinematics.forward_kinematics(1,1,node_pose)[1]; joint1_point[2]=kinematics.forward_kinematics(1,1,node_pose)[2];

  joint2_point[0]=kinematics.forward_kinematics(1,2,node_pose)[0]; joint2_point[1]=kinematics.forward_kinematics(1,2,node_pose)[1]; joint2_point[2]=kinematics.forward_kinematics(1,2,node_pose)[2];

  joint3_point[0]=kinematics.forward_kinematics(1,3,node_pose)[0]; joint3_point[1]=kinematics.forward_kinematics(1,3,node_pose)[1]; joint3_point[2]=kinematics.forward_kinematics(1,3,node_pose)[2];

  joint4_point[0]=kinematics.forward_kinematics(1,4,node_pose)[0]; joint4_point[1]=kinematics.forward_kinematics(1,4,node_pose)[1]; joint4_point[2]=kinematics.forward_kinematics(1,4,node_pose)[2];

  joints_point_array[0]=joint0_point; joints_point_array[1]=joint1_point; joints_point_array[2]=joint2_point;

  joints_point_array[3]=joint3_point; joints_point_array[4]=joint4_point; 

  
  if(obstacles_array.size()!=0){

    //cout<<" obstacles array  "<<sizeof(obstacles_array)/sizeof(obstacles_array[0])<<endl;

    for (int joint_point = 0; joint_point < sizeof(joints_point_array)/sizeof(joints_point_array[0]); joint_point++){

      for (int obs = 0; obs < sizeof(obstacles_array)/sizeof(obstacles_array[0]); obs++){

        dis_joint_from_obstacle=distance_between_2_points(joints_point_array[joint_point],obstacles_array[obs]);

        if(dis_joint_from_obstacle<collision_dist){

          return true;

        }

      }

    }
    
  }
  
  
  return false;

}






bool DynamicRrt::is_arm2_near_obstacle(Node node){

  double node_pose_arm2[5]={node.pos[5],node.pos[6],node.pos[7],node.pos[8],node.pos[9]}; double* joints_point_array_arm2[5]; double dis_joint_from_obstacle_arm2;

  double joint0_point_arm2[3]; double joint1_point_arm2[3];  double joint2_point_arm2[3]; double joint3_point_arm2[3];  double joint4_point_arm2[3]; 

  //Kinematics kinematics;

  joint0_point_arm2[0]=kinematics.forward_kinematics(2,0,node_pose_arm2)[0]; joint0_point_arm2[1]=kinematics.forward_kinematics(2,0,node_pose_arm2)[1]; joint0_point_arm2[2]=kinematics.forward_kinematics(2,0,node_pose_arm2)[2];

  joint1_point_arm2[0]=kinematics.forward_kinematics(2,1,node_pose_arm2)[0]; joint1_point_arm2[1]=kinematics.forward_kinematics(2,1,node_pose_arm2)[1]; joint1_point_arm2[2]=kinematics.forward_kinematics(2,1,node_pose_arm2)[2];

  joint2_point_arm2[0]=kinematics.forward_kinematics(2,2,node_pose_arm2)[0]; joint2_point_arm2[1]=kinematics.forward_kinematics(2,2,node_pose_arm2)[1]; joint2_point_arm2[2]=kinematics.forward_kinematics(2,2,node_pose_arm2)[2];

  joint3_point_arm2[0]=kinematics.forward_kinematics(2,3,node_pose_arm2)[0]; joint3_point_arm2[1]=kinematics.forward_kinematics(2,3,node_pose_arm2)[1]; joint3_point_arm2[2]=kinematics.forward_kinematics(2,3,node_pose_arm2)[2];

  joint4_point_arm2[0]=kinematics.forward_kinematics(2,4,node_pose_arm2)[0]; joint4_point_arm2[1]=kinematics.forward_kinematics(2,4,node_pose_arm2)[1]; joint4_point_arm2[2]=kinematics.forward_kinematics(2,4,node_pose_arm2)[2];

  joints_point_array_arm2[0]=joint0_point_arm2; joints_point_array_arm2[1]=joint1_point_arm2; joints_point_array_arm2[2]=joint2_point_arm2;

  joints_point_array_arm2[3]=joint3_point_arm2; joints_point_array_arm2[4]=joint4_point_arm2; 

 
  if(obstacles_array.size()!=0){

    for (int joint_point = 0; joint_point < sizeof(joints_point_array_arm2)/sizeof(joints_point_array_arm2[0]); joint_point++){

      for (int obs = 0; obs < sizeof(obstacles_array)/sizeof(obstacles_array[0]); obs++){


          dis_joint_from_obstacle_arm2=distance_between_2_points(joints_point_array_arm2[joint_point],obstacles_array[obs]);


          if(dis_joint_from_obstacle_arm2<collision_dist){

            return true;

        }

        

        }

        

      }

  }
    

  return false;

}







bool DynamicRrt::is_arm1_near_arm2(Node node){

  double node_pose[5]={node.pos[0],node.pos[1],node.pos[2],node.pos[3],node.pos[4]}; double* joints_point_array[5]; double dis_arm1_from_arm2;

  double joint0_point[3]; double joint1_point[3];  double joint2_point[3]; double joint3_point[3];  double joint4_point[3]; Kinematics kinematics;

  joint0_point[0]=kinematics.forward_kinematics(1,0,node_pose)[0]; joint0_point[1]=kinematics.forward_kinematics(1,0,node_pose)[1]; joint0_point[2]=kinematics.forward_kinematics(1,0,node_pose)[2];

  joint1_point[0]=kinematics.forward_kinematics(1,1,node_pose)[0]; joint1_point[1]=kinematics.forward_kinematics(1,1,node_pose)[1]; joint1_point[2]=kinematics.forward_kinematics(1,1,node_pose)[2];

  joint2_point[0]=kinematics.forward_kinematics(1,2,node_pose)[0]; joint2_point[1]=kinematics.forward_kinematics(1,2,node_pose)[1]; joint2_point[2]=kinematics.forward_kinematics(1,2,node_pose)[2];

  joint3_point[0]=kinematics.forward_kinematics(1,3,node_pose)[0]; joint3_point[1]=kinematics.forward_kinematics(1,3,node_pose)[1]; joint3_point[2]=kinematics.forward_kinematics(1,3,node_pose)[2];

  joint4_point[0]=kinematics.forward_kinematics(1,4,node_pose)[0]; joint4_point[1]=kinematics.forward_kinematics(1,4,node_pose)[1]; joint4_point[2]=kinematics.forward_kinematics(1,4,node_pose)[2];

  joints_point_array[0]=joint0_point; joints_point_array[1]=joint1_point; joints_point_array[2]=joint2_point;

  joints_point_array[3]=joint3_point; joints_point_array[4]=joint4_point; 



  double node_pose_arm2[5]={node.pos[5],node.pos[6],node.pos[7],node.pos[8],node.pos[9]}; double* joints_point_array_arm2[5]; 

  double joint0_point_arm2[3]; double joint1_point_arm2[3];  double joint2_point_arm2[3]; double joint3_point_arm2[3];  double joint4_point_arm2[3]; //double obstacle_point[3];

  joint0_point_arm2[0]=kinematics.forward_kinematics(2,0,node_pose_arm2)[0]; joint0_point_arm2[1]=kinematics.forward_kinematics(2,0,node_pose_arm2)[1]; joint0_point_arm2[2]=kinematics.forward_kinematics(2,0,node_pose_arm2)[2];

  joint1_point_arm2[0]=kinematics.forward_kinematics(2,1,node_pose_arm2)[0]; joint1_point_arm2[1]=kinematics.forward_kinematics(2,1,node_pose_arm2)[1]; joint1_point_arm2[2]=kinematics.forward_kinematics(2,1,node_pose_arm2)[2];

  joint2_point_arm2[0]=kinematics.forward_kinematics(2,2,node_pose_arm2)[0]; joint2_point_arm2[1]=kinematics.forward_kinematics(2,2,node_pose_arm2)[1]; joint2_point_arm2[2]=kinematics.forward_kinematics(2,2,node_pose_arm2)[2];

  joint3_point_arm2[0]=kinematics.forward_kinematics(2,3,node_pose_arm2)[0]; joint3_point_arm2[1]=kinematics.forward_kinematics(2,3,node_pose_arm2)[1]; joint3_point_arm2[2]=kinematics.forward_kinematics(2,3,node_pose_arm2)[2];

  joint4_point_arm2[0]=kinematics.forward_kinematics(2,4,node_pose_arm2)[0]; joint4_point_arm2[1]=kinematics.forward_kinematics(2,4,node_pose_arm2)[1]; joint4_point_arm2[2]=kinematics.forward_kinematics(2,4,node_pose_arm2)[2];

  joints_point_array_arm2[0]=joint0_point_arm2; joints_point_array_arm2[1]=joint1_point_arm2; joints_point_array_arm2[2]=joint2_point_arm2;

  joints_point_array_arm2[3]=joint3_point_arm2; joints_point_array_arm2[4]=joint4_point_arm2; 


  for (int joint_point = 0; joint_point < sizeof(joints_point_array)/sizeof(joints_point_array[0]); joint_point++){

    for (int joint_point_arm2 = 0; joint_point_arm2 < sizeof(joints_point_array_arm2)/sizeof(joints_point_array_arm2[0]); joint_point_arm2++){

      dis_arm1_from_arm2=distance_between_2_points(joints_point_array[joint_point],joints_point_array_arm2[joint_point_arm2]);

      if(dis_arm1_from_arm2<collision_dist){

        return true;

      }

    }

  }

  return false;

}



bool DynamicRrt::is_collision(Node node){

  bool arm1_near_obstacle; bool arm2_near_obstacle; bool arm1_near_arm2;

  arm1_near_obstacle=is_arm1_near_obstacle(node);

  arm2_near_obstacle=is_arm2_near_obstacle(node);

  arm1_near_arm2=is_arm1_near_arm2(node);

  //cout<<arm1_near_obstacle<<"  arm2 "<<arm2_near_obstacle<<"  arm1 and 2 "<<arm1_near_arm2<<endl;

  //cout<<" arm1_near_obstacle "<<arm1_near_obstacle<<" arm2_near_obstacle "<<arm2_near_obstacle<<" arm1_near_arm2 "<<arm1_near_arm2<<endl;

  if((arm1_near_obstacle==true) || (arm2_near_obstacle==true) || (arm1_near_arm2==true)){

    //cout<<"it is true "<<endl;

    return true;

  }

  

  return false;
}






vector<double*> DynamicRrt::extract_path(Node node_end){

  //static vector<double*> path = vector<double*>();

  //static vector<double*>* path=new vector<double*>;
  static vector<double*> path;


  static Node node_now; int i=0;

  path.push_back(s_goal.pos);

  node_now=node_end;

  
  while(node_now.is_first_node==false){

    //cout<<i<<endl;

    //i+=1;

    node_now =*node_now.parent;

    //cout<<node_now.is_first_node<<endl;

    //cout<<" node now  "<<node_now.pos[0]<<" "<<node_now.pos[1]<<" "<<node_now.pos[2]<<" "<<node_now.pos[3]<<" "<<node_now.pos[4]<<endl;

    path.push_back(node_now.pos);

    //i++;

    cout<<node_now.pos<<endl;
  }

  cout<<" after  "<<path[5][0]<<endl;
  return path;

}



vector<double*> DynamicRrt::planning(){

  Node node_rand; Node node_near; Node node_new;Edge new_edge; double dist;vector<double*> path; 

  double min_dist=100.0;

  s_start.is_first_node=true;

  vertex.push_back(s_start);



  for(int i=0;i<iter_max;i++){

    node_rand=generate_random_node();

    node_near=nearest_neighbor(node_rand);

    node_new=new_state(node_near, node_rand);

    //cout<<node_rand.pos[1]<<endl;

    //cout<<"  vertex size  "<<vertex.size()<<endl;

    if(is_collision(node_new)==false){

       //cout<<"no collision"<<endl;

       vertex.push_back(node_new);

       new_edge.parent=node_near; new_edge.child=node_new; new_edge.flag=1;

       edges.push_back(new_edge);

       dist=get_distance_and_direction(node_new,s_goal)[0];

       //cout<<i<<"  min_dist  "<<min_dist<<" dist  "<<dist<<endl;

       if(dist<min_dist){
         min_dist=dist;
       }

       if (dist <= step_len){

        cout<<"finished"<<endl;


        new_state(node_new, s_goal);

        //cout<<node_new.pos[0]<<endl;

        path = extract_path(node_new);

        cout<<path[10][0]<<endl;

        return path;

        

      
       }

    }

  }

  cout<<"didnt find path"<<endl;

}




void navigation(double start_pose_arm1[6],double goal_pose_arm1[6],double start_pose_arm2[6],double goal_pose_arm2[6],manipulator_h_base_module_msgs::JointPose set_joints_msg,ros::Publisher pub_set_joints_arm1,ros::Publisher pub_set_joints_arm2 ,ros::ServiceClient octomap_reset,ros::Publisher pub_obstacles)

{

std_srvs::Empty empty; double start_pose[10];double goal_pose[10];vector<double*> obstacles_array;

Kinematics kinematics; Node start_node; Node ending_node;

cout<<"planning initial route"<<endl;

start_node.pos[0]=start_pose_arm1[0]; start_node.pos[1]=start_pose_arm1[1]; start_node.pos[2]=start_pose_arm1[2]; start_node.pos[3]=start_pose_arm1[3]; start_node.pos[4]=start_pose_arm1[4]; 

start_node.pos[5]=start_pose_arm2[0]; start_node.pos[6]=start_pose_arm2[1]; start_node.pos[7]=start_pose_arm2[2]; start_node.pos[8]=start_pose_arm2[3]; start_node.pos[9]=start_pose_arm2[4]; 

ending_node.pos[0]=goal_pose_arm1[0]; ending_node.pos[1]=goal_pose_arm1[1]; ending_node.pos[2]=goal_pose_arm1[2]; ending_node.pos[3]=goal_pose_arm1[3]; ending_node.pos[4]=goal_pose_arm1[4]; 

ending_node.pos[5]=goal_pose_arm2[0]; ending_node.pos[6]=goal_pose_arm2[1]; ending_node.pos[7]=goal_pose_arm2[2]; ending_node.pos[8]=goal_pose_arm2[3]; ending_node.pos[9]=goal_pose_arm2[4]; 

//octomap_reset.waitForExistence();
    
//octomap_reset.call(empty);

//usleep(200000);

//ros::spinOnce();

//*obstacles_array=0;

obstacles_array=create_obstacles_array_dynamic(occupied_cells,joint_state_data,joint_state_data_arm2,kinematics,pub_obstacles,1);

DynamicRrt drrt;

//cout<<obstacles_array[0]<<endl;



drrt.set_parameters(start_node,ending_node, 0.2, 0.2, 0.2, 5000);

drrt.obstacles_array=obstacles_array;

//cout<<drrt.vertex.size()<<endl;

drrt.planning();

//if(sizeof(obstacles_array[0])/sizeof(obstacles_array[0][0])>1){

//cout<<sizeof(obstacles_array)/sizeof(obstacles_array[0])<<endl;

//if (obstacles_array[0] == 0){

//cout<<"yooo"<<endl;}

//cout<<create_obstacles_array_dynamic(occupied_cells,joint_state_data,joint_state_data_arm2,kinematics,pub_obstacles,1)<<endl;



}








int main(int argc, char **argv)
{

  srand(time(0));

  ros::init(argc, argv, "DRRT");

  ros::NodeHandle n;

  std_srvs::Empty empty;

  ros::Publisher pub_set_joints_arm1 = n.advertise<manipulator_h_base_module_msgs::JointPose>("/robotis/base/joint_pose_msg", 10);

  ros::Publisher pub_set_joints_arm2 = n.advertise<manipulator_h_base_module_msgs::JointPose>("/robotis/base/joint_pose_msg_arm2", 10);

  ros::Publisher pub_obstacles = n.advertise<visualization_msgs::MarkerArray>("visualize_obstacles", 10);

  ros::Subscriber sub_joy = n.subscribe("/joy", 100, &joy_data);

  ros::Subscriber sub_joint_state = n.subscribe("/robotis/present_joint_states", 100, &joint_state);

  ros::Subscriber sub_joint_state_arm2 = n.subscribe("/robotis/present_joint_states_arm2", 100, &joint_state_arm2);

  ros::Subscriber sub_occupied_cells = n.subscribe("/occupied_cells_vis_array", 100, &occupied_cells_data);

  ros::ServiceClient octomap_reset = n.serviceClient<std_srvs::Empty>("/octomap_server/reset", false);



  set_joints_msg.name={"joint1", "joint2", "joint3", "joint4", "joint5", "joint6"};

  ros::Rate loop_rate(10);

  joint_state_data.position={0,0,0,0,0};

  joint_state_data_arm2.position={0,0,0,0,0};


  Kinematics kinematics;

  double arm1_init_point[3]={0.35,0.0,0.0};

  double arm2_init_point[3]={-0.35,0.0,0.0};

  double arm1_init_orientation[3]={3.14,0.0,0.0};

  double arm2_init_orientation[3]={0.0,0.0,0.0};

  kinematics.set_values(arm1_init_point,arm2_init_point,arm1_init_orientation,arm2_init_orientation);

  

  while (ros::ok())
  {


    if(x==1){

    cout<<"obstacles"<<endl;

    octomap_reset.waitForExistence();
    
    octomap_reset.call(empty);

    usleep(200000);

    ros::spinOnce();

    create_obstacles_array_dynamic(occupied_cells,joint_state_data,joint_state_data_arm2,kinematics,pub_obstacles,1);

    }

    if(start_button==1){

    cout<<"start"<<endl;

    double start_arm1[6]={joint_state_data.position[0],joint_state_data.position[1],joint_state_data.position[2],joint_state_data.position[3],joint_state_data.position[4],joint_state_data.position[5]};

    double start_arm2[6]={joint_state_data_arm2.position[0],joint_state_data_arm2.position[1],joint_state_data_arm2.position[2],joint_state_data_arm2.position[3],joint_state_data_arm2.position[4],joint_state_data_arm2.position[5]};

    double goal_pose_arm1[6]={3,0,0,0,0,0}; double goal_pose_arm2[6]={3,0,0,0,0,0};

    navigation(start_arm1,goal_pose_arm1,start_arm2,goal_pose_arm2,set_joints_msg,pub_set_joints_arm1,pub_set_joints_arm2,octomap_reset,pub_obstacles);

    }



    ros::spinOnce();
      

    loop_rate.sleep();

  }
  return 0;


}

