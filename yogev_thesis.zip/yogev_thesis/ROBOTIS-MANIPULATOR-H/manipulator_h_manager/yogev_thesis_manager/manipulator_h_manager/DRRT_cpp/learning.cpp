#include <iostream>
#include <math.h> 
#include <cmath>
//#include <Eigen/Dense>
#include <array>
#include<unistd.h>
#include <chrono>
#include <stdlib.h>  
#include <vector>



typedef std::chrono::high_resolution_clock Clock;
using namespace std;
//using namespace Eigen;
//std::stringstream ss;


class Node{

  public:

  int flag=1;

  bool is_first_node=false;

  void set_pose(double[10],int);

  double pos[10];

  Node* parent;

  //parent=new Node;

};



void Node::set_pose(double pose[10],int f){

  pos[0]=pose[0]; pos[1]=pose[1]; pos[2]=pose[2]; pos[3]=pose[3]; pos[4]=pose[4];

  pos[5]=pose[5]; pos[6]=pose[6]; pos[7]=pose[7]; pos[8]=pose[8]; pos[9]=pose[9];

  flag=f;  


}



void yogev(){

  static vector<double*> path ;int i=0;

  double A[3]={1,2,3}; double B[3]={4,5,6}; double C[3]={7,8,9};

  static vector<double*> D ;

  D.push_back(A); D.push_back(B); D.push_back(C);

  while(i<3){

    path.push_back(D[i]);

    i++;
  }

  cout<<path[1][0]<<endl;



}


int main(int argc, char **argv)
{


  ////////////////////////////////////////////


  yogev();

  /////////////////////////////////////////////////



  
  return 0;


}

