#include <ros/ros.h>
#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>


ros::Publisher pub;

void 
cloud_cb (const sensor_msgs::PointCloud2ConstPtr& input)
{
    // Convert the sensor_msgs/PointCloud2 data to pcl/PointCloud
    pcl::PointCloud<pcl::PointXYZ>::Ptr
        cloud(new pcl::PointCloud<pcl::PointXYZ> ()),
        cloud_filtered(new pcl::PointCloud<pcl::PointXYZ> ());
    pcl::fromROSMsg (*input, *cloud);

    pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
    sor.setInputCloud (cloud);
    sor.setMeanK (10);
    //sor.setMeanK (1);
    sor.setStddevMulThresh (0.01);
    //sor.setStddevMulThresh (1);
    //sor.setStddevMulThresh (3.0);
    sor.filter (*cloud_filtered);

    sensor_msgs::PointCloud2::Ptr
        cloud_filtered2(new sensor_msgs::PointCloud2 ());
    pcl::toROSMsg (*cloud_filtered, *cloud_filtered2);

    // Publish the dataSize 
    pub.publish (cloud_filtered2);
}

int
main (int argc, char** argv)
{
  // Initialize ROS
  ros::init (argc, argv, "statistical_filtered_pcl");
  ros::NodeHandle nh;

  // Create a ROS subscriber for the input point cloud
  ros::Subscriber sub = nh.subscribe ("pointcloud2_after_filter", 1, cloud_cb);



  // Create a ROS publisher for the output point cloud
  pub = nh.advertise<sensor_msgs::PointCloud2> ("/statistical_filtered_pcl", 1);



  // Spin
  ros::spin ();
}