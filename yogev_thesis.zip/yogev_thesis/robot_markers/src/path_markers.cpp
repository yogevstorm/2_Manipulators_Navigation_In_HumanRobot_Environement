#include <map>
#include <string>
#include "geometry_msgs/Pose.h"
#include "robot_markers/builder.h"
#include "ros/ros.h"
#include "urdf/model.h"
#include "visualization_msgs/MarkerArray.h"
#include "std_msgs/Float32MultiArray.h"
#include <string> 
#include "std_msgs/Int8.h"
#include "robot_markers/path_msg.h"

boost::shared_ptr<robot_markers::path_msg const> trajectory;





int main(int argc, char** argv) {

  ros::init(argc, argv, "path_markers_publisher");

  ros::NodeHandle nh;

  ros::Publisher marker_arr_pub =
      nh.advertise<visualization_msgs::MarkerArray>("Algorithm_visualization", 10);

  ros::Duration(0.5).sleep();

  urdf::Model model;

  model.initParam("robot_description");

  robot_markers::Builder builder(model);

  builder.Init();

  visualization_msgs::MarkerArray robot;

  visualization_msgs::MarkerArray robot2;

  //visualization_msgs::Marker::DELETEALL;

  ros::Rate loop_rate(20);
  
  

  while (ros::ok())
  {
   
    trajectory=ros::topic::waitForMessage<robot_markers::path_msg>("trajectory_state",nh);

    geometry_msgs::Pose pose;

    int path_len=trajectory->waypoint[0].data[28];

    visualization_msgs::Marker::DELETEALL;

    builder.SetLifetime(ros::Duration(5*path_len));

    for (int i = 0; i < path_len; i++)
    {

      std::string robot_name_arm1 = "robot_arm1";

      std::string robot_name_arm2 = "robot_arm2";

      robot_name_arm1+=std::to_string(i);

      builder.SetNamespace(robot_name_arm1);

      builder.SetFrameId("map");

      builder.SetColor(0, 1, 0, 0.15);

      std::map<std::string, double> joint_positions;

      joint_positions["joint1"] = trajectory->waypoint[i].data[0];

      joint_positions["joint2"] = trajectory->waypoint[i].data[1];

      joint_positions["joint3"] = trajectory->waypoint[i].data[2];

      joint_positions["joint4"] = trajectory->waypoint[i].data[3];

      joint_positions["joint5"] = trajectory->waypoint[i].data[4];

      joint_positions["joint6"] = trajectory->waypoint[i].data[5];

      joint_positions["rh_p12_rn_a"] = trajectory->waypoint[i].data[26];

      joint_positions["rh_r2"] = trajectory->waypoint[i].data[26];

      joint_positions["rh_l1"] = trajectory->waypoint[i].data[26];

      joint_positions["rh_l2"] = trajectory->waypoint[i].data[26];


      builder.SetJointPositions(joint_positions);

      pose.position.x = trajectory->waypoint[i].data[6];

      pose.position.y = trajectory->waypoint[i].data[7];

      pose.position.z = trajectory->waypoint[i].data[8];

      pose.orientation.x = trajectory->waypoint[i].data[9];

      pose.orientation.y = trajectory->waypoint[i].data[10];

      pose.orientation.z = trajectory->waypoint[i].data[11];

      pose.orientation.w = trajectory->waypoint[i].data[12];

      builder.SetPose(pose);

      builder.Build(&robot);

      marker_arr_pub.publish(robot);

      robot.markers.clear();



      robot_name_arm2+=std::to_string(i);

      builder.SetNamespace(robot_name_arm2);

      builder.SetFrameId("map");

      builder.SetColor(0, 1, 1, 0.15);

      joint_positions["joint1"] = trajectory->waypoint[i].data[13];

      joint_positions["joint2"] = trajectory->waypoint[i].data[14];

      joint_positions["joint3"] = trajectory->waypoint[i].data[15];

      joint_positions["joint4"] = trajectory->waypoint[i].data[16];

      joint_positions["joint5"] = trajectory->waypoint[i].data[17];

      joint_positions["joint6"] = trajectory->waypoint[i].data[18];

      joint_positions["rh_p12_rn_a"] = trajectory->waypoint[i].data[27];

      joint_positions["rh_r2"] = trajectory->waypoint[i].data[27];

      joint_positions["rh_l1"] = trajectory->waypoint[i].data[27];

      joint_positions["rh_l2"] = trajectory->waypoint[i].data[27];

      builder.SetJointPositions(joint_positions);

      pose.position.x = trajectory->waypoint[i].data[19];

      pose.position.y = trajectory->waypoint[i].data[20];

      pose.position.z = trajectory->waypoint[i].data[21];

      pose.orientation.x = trajectory->waypoint[i].data[22];

      pose.orientation.y = trajectory->waypoint[i].data[23];

      pose.orientation.z = trajectory->waypoint[i].data[24];

      pose.orientation.w = trajectory->waypoint[i].data[25];

      builder.SetPose(pose);

      builder.Build(&robot2);

      marker_arr_pub.publish(robot2);

      robot2.markers.clear();



    }

    ros::spinOnce();

    loop_rate.sleep();
  }

  

  return 0;
}

